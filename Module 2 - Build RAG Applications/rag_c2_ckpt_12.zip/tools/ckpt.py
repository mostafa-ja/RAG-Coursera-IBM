# usage: python3 tools/ckpt.py NN "header note" STEP_ID "done text" "next steps text"
# Updates CHECKPOINT.md (header, marks '- [ ] STEP_ID' as done, replaces section 5) and writes checkpoints/rag_c2_ckpt_NN.zip
import sys,re,subprocess,os
nn,hdr,sid,done,nxt=sys.argv[1:6]
p='CHECKPOINT.md'; t=open(p,encoding='utf-8').read()
t=re.sub(r'^Checkpoint: .*$',lambda m:f'Checkpoint: {nn}  ({hdr})',t,count=1,flags=re.M)
t,n=re.subn(r'^- \[ \] '+re.escape(sid)+r'\b.*$',lambda m:f'- [x] {sid} (ckpt {nn}): {done}',t,count=1,flags=re.M)
if not n: print('WARNING: step line not found:',sid)
t=re.sub(r'## 5\. Next steps \(exact\)\n.*?(?=\n## 6\.)',lambda m:'## 5. Next steps (exact)\n'+nxt+'\n',t,count=1,flags=re.S)
open(p,'w',encoding='utf-8').write(t)
os.makedirs('checkpoints',exist_ok=True)
for f in os.listdir('checkpoints'): os.remove('checkpoints/'+f)
z=f'checkpoints/rag_c2_ckpt_{nn}.zip'
subprocess.run(['zip','-q','-r',z,'CHECKPOINT.md','notes','tools','work','original'],check=True)
print('saved',z,os.path.getsize(z))
