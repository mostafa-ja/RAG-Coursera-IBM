# usage: python3 tools/insert.py FILE SECTION_ID SNIPPET_FILE [MARKER]
# Inserts snippet just before the first MARKER (default '<div class="take">') found after id="SECTION_ID".
# Idempotent: the snippet's first line is a unique comment (e.g. <!--v3:S3-->); if already present, it skips.
import sys,re
f,sid,sn=sys.argv[1:4]; marker=sys.argv[4] if len(sys.argv)>4 else '<div class="take">'
h=open(f,encoding='utf-8').read(); s=open(sn,encoding='utf-8').read().strip()
tag=s.splitlines()[0]
if tag in h: print('SKIP: already inserted',tag); sys.exit(0)
a=h.find('id="%s"'%sid); assert a>0,'section not found'
p=h.find(marker,a); assert p>0,'marker not found'
ids=re.findall(r'href="#([^"]+)"',re.search(r'<nav id="side">(.*?)</nav>',h,re.S).group(1))
nx=[h.find('id="%s"'%j) for j in ids[ids.index(sid)+1:]] if sid in ids else []
nx=[q for q in nx if q>a]
if nx and nx[0]<p: print('WARNING: marker is after next lesson start')
h=h[:p]+s+h[p:]; open(f,'w',encoding='utf-8').write(h)
print('inserted',tag,'at',p,'new size',len(h))
