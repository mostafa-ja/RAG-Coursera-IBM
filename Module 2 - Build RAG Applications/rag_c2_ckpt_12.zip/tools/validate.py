# usage: python3 tools/validate.py FILE  -> tag-nesting problems, duplicate ids, missing href targets
import sys,re
from html.parser import HTMLParser
VOID={'area','base','br','col','embed','hr','img','input','link','meta','source','track','wbr','path','circle','rect','line','polyline','polygon','ellipse','stop','use'}
OPT={'p','li','tr','td','th','thead','tbody','option','dt','dd'}
class P(HTMLParser):
    def __init__(s): super().__init__(); s.st=[]; s.err=[]
    def handle_starttag(s,t,a):
        if t not in VOID: s.st.append((t,s.getpos()))
    def handle_startendtag(s,t,a): pass
    def handle_endtag(s,t):
        if t in VOID: return
        if s.st and s.st[-1][0]==t: s.st.pop(); return
        # pop optional-close tags
        while s.st and s.st[-1][0] in OPT and s.st[-1][0]!=t: s.st.pop()
        if s.st and s.st[-1][0]==t: s.st.pop()
        else: s.err.append((t,s.getpos()))
h=open(sys.argv[1],encoding='utf-8').read(); p=P(); p.feed(h)
ids=re.findall(r'\bid="([^"]+)"',h); dup=sorted(set(i for i in ids if ids.count(i)>1))
miss=sorted(set(x for x in re.findall(r'href="#([^"]+)"',h) if x not in set(ids) and "'" not in x))
left=[t for t,_ in p.st if t not in OPT]
print('nesting errors:',len(p.err),p.err[:5],'| unclosed:',left[:5],'| dup ids:',dup[:10],'| missing hrefs:',miss[:10])
