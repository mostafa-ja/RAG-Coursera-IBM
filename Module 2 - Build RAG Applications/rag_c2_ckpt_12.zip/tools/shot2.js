const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/local/bin/chromium', args:['--no-sandbox'] });
  const page = await b.newPage({ viewport: { width: 1100, height: 1200 } }); const errs=[];
  page.on('pageerror', e => errs.push(e.message));
  await page.goto('file:///data/work/ckpt07/work/RAG_C2_Guide_v3.html', { waitUntil: 'load' }); await page.waitForTimeout(600);
  const d = page.locator('#w1-sim details.deep', { hasText: 'drop weak chunks' }).first();
  await d.evaluate(e => { e.open = true; }); await d.evaluate(e => e.querySelector('.tw').scrollIntoView({block:'center'})); await page.waitForTimeout(300);
  await d.screenshot({ path: '/data/work/shots/5_s9_fixed.png' });
  console.log('errors', JSON.stringify(errs)); await page.close(); await b.close(); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
