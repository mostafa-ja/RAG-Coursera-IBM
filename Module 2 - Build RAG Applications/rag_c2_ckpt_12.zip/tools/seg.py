# usage: python3 tools/seg.py FILE ANCHOR_ID [maxchars]  -> readable text of one nav subsection
import re,sys
from bs4 import BeautifulSoup
f,aid=sys.argv[1],sys.argv[2]; mx=int(sys.argv[3]) if len(sys.argv)>3 else 6000
h=open(f,encoding='utf-8').read()
nav=re.search(r'<nav id="side">(.*?)</nav>',h,re.S).group(1)
ids=re.findall(r'href="#([^"]+)"',nav)
s=h.find('id="%s"'%aid); s=h.rfind('<',0,s)
e=len(h)
for j in ids[ids.index(aid)+1:] if aid in ids else []:
    p=h.find('id="%s"'%j)
    if p>s: e=h.rfind('<',0,p); break
seg=h[s:e]; soup=BeautifulSoup(seg,'lxml')
for t in soup.find_all('svg'): t.replace_with('[SVG:%s]'%(t.get('aria-label') or (t.find('title').text if t.find('title') else '')))
for t in soup.find_all('pre'):
    L=t.get_text().splitlines(); t.replace_with('\n[CODE %d lines] %s\n'%(len(L),' / '.join(x.strip() for x in L[:4])[:220]))
for t in soup.find_all('table'):
    rows=[' | '.join(c.get_text(' ',strip=True)[:40] for c in r.find_all(['td','th'])) for r in t.find_all('tr')]
    t.replace_with('\n[TABLE %d rows]\n  '%len(rows)+'\n  '.join(rows[:6])+'\n')
for t in soup.find_all(['h1','h2','h3','h4']): t.insert_before('\n## '); t.insert_after('\n')
for t in soup.find_all(['div','details','aside','p','li']):
    c=' '.join(t.get('class',[])) if t.name!='p' else ''
    t.insert_before('\n'+('['+t.name+('.'+c if c else '')+'] ' if t.name in('div','details','aside') and c else ('- ' if t.name=='li' else '')))
txt=re.sub(r'\n\s*\n+','\n',soup.get_text())
print('SEG chars html=%d text=%d'%(len(seg),len(txt))); print(txt[:mx])
