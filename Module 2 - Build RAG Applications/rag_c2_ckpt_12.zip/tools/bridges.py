# usage: python3 tools/bridges.py work/RAG_C2_Guide_v3.html notes/03_bridges.md
# S7: appends <div class="apply">..</div> as LAST child of each lesson's div.take (after div.tgrid). Idempotent.
import sys,re
f,m=sys.argv[1:3]; h=open(f,encoding='utf-8').read()
CSS='/*v3:S7*/.apply{margin-top:12px;padding:10px 14px;border:1px dashed var(--ok);background:var(--okS);border-radius:10px;font-size:15px;line-height:1.55}.apply>b:first-child{color:var(--ok)}'
A='.tgrid>.box{margin:0}'
if '/*v3:S7*/' not in h:
    assert h.count(A)>=1; h=h.replace(A,A+CSS,1); print('css added')
rows=[l[2:].split(' | ',1) for l in open(m,encoding='utf-8') if re.match(r'- [\w-]+ \| ',l)]
for lid,txt in rows:
    i=h.find(f'id="{lid}"'); e=h.find('</article>',i); t=h.find('<div class="take">',i)
    if i<0 or t<0 or t>e: print('SKIP no take',lid); continue
    d=0; p=t
    for mm in re.finditer(r'<div\b|</div>',h[t:e]):
        d+= 1 if mm.group(0)=='<div' else -1
        if d==0: p=t+mm.start(); break
    if 'class="apply"' in h[t:p]: print('already',lid); continue
    h=h[:p]+'<div class="apply"><b>🛠 Use it in your project:</b> '+txt.strip()+'</div>'+h[p:]; print('ok',lid)
open(f,'w',encoding='utf-8').write(h)
