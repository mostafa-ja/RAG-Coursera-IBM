# 02 — Improvement plan (FINAL, after Step 2b)  — decisions + reasoning

## What v2 already does well (do NOT redo)
- Uniform lesson template (tldr, goals, plain words, diagram, code, tips, optional <details class="deep">, takeaways why/pit/rem, recall).
- Hero already has "How to use this guide — choose a path" (Core / Apply / Exam / Optional)  -> old D1 DROPPED.
- 0.3 has phases + 8-step trace + KNOBS table + debug order. 1.4 deep look already covers dot vs cosine and
  "Chroma score = distance (lower better), LlamaIndex score = similarity (higher better)".
- P7 explains follow-ups (rewrite -> retrieve -> answer). P9 covers one-change experiments (chunk size, k, chain type).
- 3.3 explains SentenceSplitter is token-based.

## Gaps confirmed by keyword scan (0 hits in v2)
- How splitters really cut (separators, merge to chunk_size, ">chunk_size" warning, overlap made of whole pieces).
- What the LLM actually receives (the filled "stuff" prompt) + how to print it.
- LCEL data flow (dict = parallel step, what each stage receives/returns) — RunnableParallel 0 hits.
- Save & reload an index (persist_directory, storage_context.persist, load_index_from_storage) — 0 hits.
- Lessons rarely link to where the concept is applied (Kit P1–P12, TenderYar C.x).

## Changes (each = 1 step + 1 checkpoint). Reuse existing classes only: details.deep>summary+div.dbody, div.tw>table, pre, div.box tip.
- S3  1.6 (#w1-lab): Deeper look "How a text splitter really cuts your document" (worked example 600/900/500/300 chars ->
      3 chunks 600/900/802; long paragraph warning; Recursive separators; overlap of whole pieces; chars vs tokens;
      how to choose; 3-line inspection code). Insert just before the lesson's <div class="take">.
- S4  1.7 (#w1-lab2): Deeper look "What the LLM actually receives" (filled prompt example; LLM sees only this text;
      3 jobs of the instructions; size = k x chunk; print it with PROMPT.format(...)). Before <div class="take">.
- S5  P5 (#kit-p5): Deeper look "What flows through the LCEL pipe" (stage table receives/returns; dict = parallel;
      keys must match prompt variables; debug by invoking a prefix). Before <div class="take">.
- S6  3.4 (#w3-index): Deeper look "Build once, reload next session" (Chroma persist_directory + reload with
      embedding_function; LlamaIndex persist + load_index_from_storage(embed_model=...); Drive in Colab; rebuild rules;
      duplicate-add pitfall). Before <div class="take">.
- S7  Bridges: div.apply "🛠 Use it in your project" appended inside each core lesson's div.take (after div.tgrid) +
      1 CSS rule. Mapping in notes/03_bridges.md (write it in S7).
- S8  Version: <title> v2->v3; hero: one "What's new in v3" box listing the 4 deep looks + bridges (links).
- S9  Optional if tokens allow: 1.4 small "beyond the course" note on score threshold / MMR. (low priority)
- S10 Validate: HTML parses, all href="#..." targets exist, ids unique, details balanced, headless render screenshot
      of 2 changed spots; final checkpoint + deliver RAG_C2_Guide_v3.html.
## Style rules for new text
- Plain words first, then a worked example, then rules of thumb, then the common mistake. Short sentences. <= ~350 words.
- Same variable names as the guide's code (docsearch, texts, embeddings, PROMPT, rag_prompt, format_docs, retriever).
- Mark anything not in the course as "beyond the course" — keep it optional.
