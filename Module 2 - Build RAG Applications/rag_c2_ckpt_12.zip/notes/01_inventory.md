# 01 — Inventory (findings)

## Guide v2 (533,614 chars; no base64; 14 <section>s; sidebar nav + search + progress + theme + quizzes)
Sections (id: text chars): top(hero) · start 15k (0.1 big picture, 0.2 Colab 2-cell Gemini init, 0.3 RAG in one page: phases & knobs)
· w1 46k (1.1 what RAG · 1.2 process/8 steps · 1.3 encoding · 1.4 similarity/top-K · 1.5 long context · 1.6 lab RetrievalQA · 1.7 lab prompt/memory/chat loop · summary · quizzes)
· w2 40k (2.1 Gradio · 2.2 components · 2.3 LLM behind Gradio · 2.4 qabot.py · 2.5 test/extend · summary · quizzes)
· w3 56k (LlamaIndex: what · Documents/SimpleDirectoryReader · Nodes/splitters · VectorStoreIndex · retriever/synth/query engine · LC vs LI · Icebreaker p1/p2 · summary · quizzes)
· kit 48k (13 practical skills, P1–P12, debugging playbook, mini-projects) · cmp 9k (8 comparison tables)
· proj 28k (TenderYar v0.2 "Ask the package", Persian-aware chunks, eval 15 Qs chunker×k, Gradio app)
· cover 17k (source coverage matrix) · exam · gloss 5.6k · fcards 6.5k · cheat 2.9k · ex 2.9k
Sub-anchors used by nav: #start-map #start-colab #start-core #w1-what #w1-process #w1-encode #w1-sim #w1-long #w1-lab #w1-lab2 #w1-sum #w1-quiz #w2-gradio ...

## Materials (extracted to materials/, text in notes/src_txt/)
- Build RAG Applications.pdf = 16 pages of slide SCREENSHOTS (no text; tesseract not installed). Content seen:
  RAG what/why · RAG process diagram (8 numbered steps: sources→embed→vector store; prompt→embed→retriever→retrieved text+prompt→LLM→response)
  · context encoding (chunks→vectors) · question→vector · vector similarity (dot product, cosine) · top-K (K=3, argsort)
  · response generation · recap · long-context reading (needle-in-haystack, cost, latency) · Gradio (how it works, text io, multiple inputs, file upload)
  · LlamaIndex (overview, use cases, Document class, SimpleDirectoryReader input_files/required_exts/recursive, nodes, SentenceSplitter chunk_size=1024 chunk_overlap=20,
    other splitters (semantic, LangChain wrapper), VectorStoreIndex in-memory + persistent Chroma (PersistentClient, ChromaVectorStore, StorageContext, HuggingFaceEmbedding),
    retriever as_retriever(similarity_top_k), response synthesizer get_response_synthesizer, query engine as_query_engine, recaps) · LC vs LI reading.
- Labs PDFs: Gradio lab (10p), QA bot lab (9p + week2 copy 10p), Icebreaker lab (27p), Reading Gradio (4p), Reading LC vs LI (3p), LlamaIndex cheat sheet (1p)
- Code: week2/gradio-interfaces/*.py, week2/qa-bot/qabot.py, week3/icebreaker/* (config, modules/{data_extraction,data_processing,llm_interface,query_engine}, app.py, main.py)
- Colab notebooks (learner's Gemini versions): C02-M1-L1 (134 cells), C02-M2-L1 (38), C02-M2-L2 (34), C02-M3-L1 (77)
- "C02 — Colab Notebook Review & Exercise Answers" .md (7.3k words) · week3/lecture-notes.md (858 words)
- Learner project: original/C2_TenderYar_v0_2.ipynb (25 cells)

## Persistence
- Notion page with checkpoint zips: https://app.notion.com/p/0adb759acd70491685c0516e78c59733 ("RAG C2 Guide v3 — Checkpoints")
