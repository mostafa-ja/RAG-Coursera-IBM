# CHECKPOINT — Improve "RAG_C2_Guide_v2.html" (IBM RAG & Agentic AI PC, Course 2 / Module 2 "Build RAG Applications")

Checkpoint: 12  (ALL STEPS DONE (S3-S10); final = work/RAG_C2_Guide_v3.html)

## 1. Task (from user)
- Learner self-studies IBM "RAG and Agentic AI" Professional Certificate (Coursera) in **Google Colab** (not IBM lab env).
- Inputs: `Module 2 - Build RAG Applications_part1..4.zip` (unit materials), `RAG_C2_Guide_v2.html`
  (self-contained HTML revision guide), `C2_TenderYar_v0_2.ipynb` (learner's own project notebook).
- Goal: improve the HTML: better structure; deeper + clearer explanations of the IMPORTANT, USEFUL, PRACTICAL
  concepts; easy to read; learner should understand deeply and be able to APPLY to projects.
  NO over-engineering, NO complicating, NO confusing the learner. Keep it self-contained HTML.
- Constraints: free account, limited tokens -> very small steps; checkpoint before modifying files and after
  every meaningful change; each checkpoint independently usable; save findings/decisions/reasoning to files.

## 2. How to resume (new account)
1. Upload the latest `rag_c2_ckpt_NN.zip` (material zips + notebook are NOT needed for S4..S10; text extracts are in notes/src_txt/).
2. Say: "Resume from CHECKPOINT.md inside the zip. Follow 'Next steps' exactly and keep checkpointing."
3. Working file = `work/RAG_C2_Guide_v3.html` (always the latest state). Original notebook = `original/`.
4. Check which steps are already in the HTML: `grep -o '<!--v3:S[0-9]*-->' work/RAG_C2_Guide_v3.html`

## 3. File layout + tools
- CHECKPOINT.md (this file) · notes/01_inventory.md (findings) · notes/02_plan.md (FINAL plan S3..S10 + style rules)
- notes/snippets/Sx_*.html = exact HTML inserted in each step (first line = marker comment <!--v3:Sx-->)
- tools/seg.py FILE ANCHOR [maxchars] -> readable text of one lesson (cheap way to read the 540 KB HTML)
- tools/insert.py FILE SECTION_ID SNIPPET [MARKER] -> inserts snippet before first '<div class="take">' after id=SECTION_ID
  (idempotent: skips if marker already present; warns if marker falls into the next lesson)

## 4. Status
- [x] Step 0-2: workspace, inventory, FINAL plan (checkpoints 01-03, account 1)
- [x] S3 (ckpt 04, account 2): #w1-lab (lesson 1.6) Deeper look "how a text splitter really cuts your document"
      = cut-then-pack, worked example 600/900/500/300 -> 600/900/802, long-paragraph warning, Recursive separators
      + code, overlap = whole pieces (may be 0), chars vs tokens (1 token ~ 4 chars EN; Persian more), 3-line
      inspection code, rules of thumb (beyond course) + links #w3-nodes #kit-p9. Verified: details/div balanced.
      Facts checked against LangChain _merge_splits logic (warning text, overlap popping whole pieces).
- [x] S4 (ckpt 05): #w1-lab2 (1.7) Deeper look 'what the LLM actually receives' = filled stuff prompt (instructions/{context}=k chunks/{question}), LLM sees only this text, debug table (fact missing -> retrieval; present but wrong -> prompt/LLM), 3 jobs of instructions (ground / allow I-don't-know / shape answer), size = k x chunk (k=4 default), print code PROMPT.format(context=..., question=...) with docs joined by blank lines (= stuff default separator), memory -> condense-question rewrite is the {question} (rephrase_question=True) + links #w1-lab #w1-long #kit-p7. Balanced.
- [x] S5 (ckpt 06): #kit-p5 Deeper look 'what flows through the LCEL pipe' = receives/returns table (dict -> retriever|format_docs, RunnablePassthrough -> rag_prompt -> llm -> StrOutputParser), dict = RunnableParallel (each branch gets the invoke input; why invoke({'question':q}) fails), keys must match {context}/{question} (missing-variables error), debug by invoking a prefix ((setup | rag_prompt).invoke(q).to_string(); dict|runnable works via __ror__), change one block at a time. Link #w1-lab2. Balanced.
- [x] S6 (ckpt 07): #w3-index (3.4) Deeper look 'build the index once, reload it next session' = why (Colab reset wipes memory + /content; re-embedding costs time + free quota), LangChain+Chroma pattern on Drive (if os.path.exists -> Chroma(persist_directory, collection_name, embedding_function) else from_documents(..., persist_directory, collection_name, ids=stable)), count check docsearch.get()['ids'], LlamaIndex storage_context.persist + load_index_from_storage(embed_model=), Chroma back end -> VectorStoreIndex.from_vector_store, rebuild-vs-reuse table (index-time vs query-time settings, link #start-core), traps (same embed model; LlamaIndex default OpenAI fallback; duplicates on re-run; langchain_chroma upserts so stable ids overwrite), Drive fallback copytree. Links #proj #start-core #w1-encode. TenderYar finding: Cell 8 uses tenderyar.rag.index.build_index(chunks, embeddings=emb) in-memory Chroma, retriever k=5, PAUSE=4 for rate limits. Balanced.
- [x] S7 (ckpt 09): 20 div.apply '🛠 Use it in your project' boxes (1-2 sentence practical action + links to Kit PN / TenderYar C.x / related lessons) appended as last child of each core lesson's div.take, text = notes/03_bridges.md, applied by tools/bridges.py (idempotent). CSS /*v3:S7*/ .apply (dashed --ok border, --okS bg; works in dark theme) inserted after '.tgrid>.box{margin:0}'. Verified: 20 apply, all articles div-balanced, global div 1301/1301, details 89/89, all real href targets exist (only JS template hrefs unmatched = OK). Check: grep -c 'class="apply"'.
- [x] S8 (ckpt 10): <title> (v2)->(v3); hero: <!--v3:S8--> <div class="box"> 'What's new in v3' (4 deep looks linked #w1-lab #w1-lab2 #kit-p5 #w3-index + the 🛠 bridges) inserted right after the 'How to use this guide' box (<!--v2:S2-->) and before the TenderYar box. Snippet = notes/snippets/S8_whatsnew.html. Verified div 1302/1302, no missing href targets. No other visible 'v2' labels exist (other v2 hits = model names / old markers).
- [x] S9 (ckpt 11): 1.4 #w1-sim: <!--v3:S9--> details.deep 'Deeper look (beyond the course): drop weak chunks, avoid duplicate chunks' inserted before div.take (snippet notes/snippets/S9_retriever_opts.html): table problem->option->code (similarity_score_threshold + score_threshold 0.5 + k 4; mmr k 4 fetch_k 20), pick threshold from data with similarity_search_with_relevance_scores (relevance 0-1 higher=better, NOT the raw Chroma distance of similarity_search_with_score), mistake: too high -> 0 chunks -> keep 'don't know' rule (#w1-lab2), LlamaIndex SimilarityPostprocessor(similarity_cutoff=0.5). Checked: course materials do not cover MMR/threshold (only semantic-chunking thresholds) -> labelled beyond the course. What's-new box updated to '5 new Deeper looks' incl. #w1-sim link. Verified div 1304/1304, details 90/90, no missing hrefs.
- [x] S10 (ckpt 12): Validated v3: tools/validate.py (html.parser nesting check) -> 0 nesting errors, 0 unclosed, 0 duplicate ids, 0 missing href targets (same as v2); Playwright headless render (tools/shot.js, shot2.js) -> 0 JS errors; screenshots OK for What's-new box, .apply box (light + dark), S9 note. Fix after screenshot: S9 code moved out of table into a copyable <pre> (2-col table problem->option), continuation lines shortened. Deliverable = work/RAG_C2_Guide_v3.html (562 KB).

## 5. Next steps (exact)
- Nothing pending. Task complete. If the user asks for more: candidate ideas (NOT started) = (a) small 'debug flow' recap in the cheat sheet linking the deep looks, (b) S9-style notes for LlamaIndex MMR. Always: checkpoint before and after each change with tools/ckpt.py.

## 6. Persistence
- Account 3 (com2's Space): Notion page "RAG C2 Guide v3 — Checkpoints (account 3)" https://app.notion.com/p/04af8f6c1bfe49ad8a3a1f8370fa854e (ckpt 08+, newest on top). Account 3 resumed from ckpt 07.
- Account 1 Notion page (old): https://app.notion.com/p/0adb759acd70491685c0516e78c59733 (ckpt 01-03)
- Account 2: Notion page "RAG C2 Guide v3 — Checkpoints (account 2)" https://app.notion.com/p/122b1dc5cd7843b0a93d7132bbf43947 (ckpt 04+, newest on top; add new zip under the line "Checkpoints (newest first):")
