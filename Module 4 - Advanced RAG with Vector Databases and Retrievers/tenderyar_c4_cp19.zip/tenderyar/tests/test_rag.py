"""v0.2 tests — offline (no API key): loader, RTL repair, splitter, citations, chain shape, eval."""
import pathlib
import pytest
from langchain_core.documents import Document
from tenderyar.rag.loaders import fix_line, rtl_order_score, unshape, load_pdf
from tenderyar.rag.splitter import split_docs, persian_splitter
from tenderyar.rag.eval_qa import cited_pages, judge
from tenderyar.rag.qa import format_docs, build_qa_chain, REFUSAL

ROOT = pathlib.Path(__file__).resolve().parents[1]
PKG = ROOT / "data" / "packages" / "P01.pdf"


def test_cited_pages_persian_and_latin():
    assert cited_pages("مبلغ … [ص ۱۲] و [ص 3]") == {12, 3}
    assert cited_pages("see [p. 7]") == {7}


def test_fix_line_repairs_pymupdf_artefacts():
    assert fix_line(" تضمین شرکت در فرایند ارجاع کار- ۵ ماده") == "ماده ۵ - تضمین شرکت در فرایند ارجاع کار"
    assert fix_line(". اعتبار تضمین باید حداقل سه ماه باشد- بند ج") == "بند ج - اعتبار تضمین باید حداقل سه ماه باشد."
    assert fix_line("ماده ۵ - تضمین") == "ماده ۵ - تضمین"          # clean lines untouched


def test_rtl_score_reversed_sample_low():
    bad = " کیلومتر۱۲ موضوع مناقصه: اجرای خط\n. ریال است۵٬۵۵۰٬۰۰۰٬۰۰۰  مبلغ تضمین- بند الف\n۲۷۰-۱۴۰۵ :شماره مناقصه"
    assert rtl_order_score(bad) < 0.5
    assert rtl_order_score("ماده ۵ - تضمین شرکت\nبند الف - مبلغ ۵,۵۵۰,۰۰۰,۰۰۰ ریال است.") == 1.0
    assert rtl_order_score("مبلغ ۰۰۰٬۰۰۰٬۰۵۵٬۵ ریال") == 0.0     # pypdf-style reversed number


def test_unshape_presentation_forms():
    assert unshape("ﺗﻀﻤﯿﻦ") == "تضمین"


def test_splitter_keeps_pages_and_ids():
    docs = [Document(page_content=("ماده %d - متن بند. " % i) * 40, metadata={"source": "x.pdf", "page": i}) for i in (1, 2)]
    chunks = split_docs(docs, persian_splitter(300, 50))
    assert {c.metadata["page"] for c in chunks} == {1, 2}
    for c in chunks:                                            # never crosses a page
        other = 2 if c.metadata["page"] == 1 else 1
        assert f"ماده {other} " not in c.page_content
        assert c.metadata["chunk_id"].startswith(f"x.pdf:p{c.metadata['page']}:")


@pytest.mark.skipif(not PKG.exists(), reason="run python data/make_packages.py first")
def test_load_pdf_pages_and_bond_clause_whole():
    docs = load_pdf(str(PKG))
    assert [d.metadata["page"] for d in docs] == list(range(1, 13))
    assert "۵,۵۵۰,۰۰۰,۰۰۰" in docs[1].page_content
    assert all(rtl_order_score(d.page_content) == 1.0 for d in docs)
    ch = split_docs(docs, persian_splitter())
    assert any("ماده ۵" in c.page_content and "۵,۵۵۰,۰۰۰,۰۰۰" in c.page_content for c in ch)


def test_chain_offline_answers_and_refuses():
    from langchain_core.runnables import RunnableLambda
    docs = [Document(page_content="بند الف - مبلغ تضمین شرکت در مناقصه ۵,۵۵۰,۰۰۰,۰۰۰ ریال است.", metadata={"page": 2})]
    chain = build_qa_chain(RunnableLambda(lambda q: docs), model="offline")
    assert format_docs(docs).startswith("[ص 2]")
    out = chain.invoke("مبلغ تضمین شرکت در مناقصه چقدر است؟")
    assert cited_pages(out) == {2} and judge({"gold_page": 2, "gold_keywords": ["5,550,000,000"]}, out)["answer_ok"]
    assert chain.invoke("قیمت دلار امروز چند است؟") == REFUSAL


def test_judge_rules():
    row = {"gold_page": 2, "gold_keywords": ["5,550,000,000"]}
    assert judge(row, "مبلغ ۵٬۵۵۰٬۰۰۰٬۰۰۰ ریال [ص ۲]") == {"answer_ok": True, "cite_ok": True, "refusal_ok": None}
    assert judge({"gold_page": None}, REFUSAL)["refusal_ok"] is True


def test_madde_splitter_starts_chunk_at_clause_and_fixed_cuts_words():
    from tenderyar.rag.splitter import fixed_splitter
    page = Document(page_content="شرایط خصوصی پیمان\nماده ۵ - تضمین شرکت در فرایند ارجاع کار\n"
                    "بند الف - مبلغ تضمین شرکت در مناقصه ۵,۵۵۰,۰۰۰,۰۰۰ ریال است.\n"
                    "بند ب - تضمین باید به صورت ضمانتنامه بانکی یا واریز نقدی ارائه شود.\n"
                    "بند ج - اعتبار تضمین باید حداقل سه ماه باشد.", metadata={"page": 2})
    madde = split_docs([page], persian_splitter(200, 30))
    assert any(c.page_content.startswith("ماده ۵") for c in madde)
    fixed = split_docs([page], fixed_splitter(150, 0))
    assert not fixed[0].page_content.endswith((" ", "\n"))       # blind cut lands inside a line


def test_gradio_rag_offline_smoke(monkeypatch):
    pytest.importorskip("gradio"); pytest.importorskip("langchain_chroma")
    if not PKG.exists(): pytest.skip("no package PDF")
    monkeypatch.setenv("TY_MODEL", "offline"); monkeypatch.setenv("TY_EMBED", "offline")
    import importlib, tenderyar.apps.gradio_rag as g
    g = importlib.reload(g); g.build_ui()
    card, status = g.index_pdf(str(PKG))
    assert card["bond_amount_rial"] == 5550000000 and "12" in status
    hist, src = g.chat("مبلغ تضمین شرکت در مناقصه چقدر است؟", [])
    assert "[ص ۲]" in hist[-1]["content"] and "[ص 2]" in src
    hist, _ = g.chat("قیمت دلار امروز چند است؟", [])
    assert REFUSAL in hist[-1]["content"]
