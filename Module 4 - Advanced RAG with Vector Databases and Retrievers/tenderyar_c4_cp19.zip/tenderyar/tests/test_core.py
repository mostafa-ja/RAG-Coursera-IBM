from datetime import date, timedelta

from tenderyar.evaluate import load_gold, load_notices, score
from tenderyar.extractor import postprocess, rule_extract
from tenderyar.jalali import gregorian_to_jalali, jalali_str_to_iso, jalali_to_gregorian, parse_jalali
from tenderyar.money import parse_amount, words_to_number
from tenderyar.normalize import normalize


def test_normalize():
    assert normalize("شركت مي خواهد ۱۲۳") == "شرکت می\u200cخواهد 123"
    assert normalize("مناقصـــه") == "مناقصه"


def test_jalali_roundtrip():
    d = date(2000, 1, 1)
    for i in range(0, 12000, 7):
        g = d + timedelta(i)
        assert jalali_to_gregorian(*gregorian_to_jalali(g)) == g
    assert jalali_str_to_iso("۱۴۰۵/۰۱/۰۱") == "2026-03-21"
    assert parse_jalali("۲۰ آبان ماه ۱۴۰۵") == (1405, 8, 20)
    assert parse_jalali("1405/13/01") is None


def test_money():
    assert parse_amount("۳۲۰ میلیون تومان") == 3_200_000_000
    assert parse_amount("دو میلیارد و چهارصد میلیون ریال") == 2_400_000_000
    assert parse_amount("٦,٨٠٠,٠٠٠,٠٠٠ ریال") == 6_800_000_000
    assert words_to_number("یک میلیارد و پانصد میلیون") == 1_500_000_000


def test_postprocess_fills_from_rules():
    text = "مناقصه شماره ۱۴۰۵/۱ تضمین ۵۰۰,۰۰۰,۰۰۰ ریال آخرین مهلت ارسال ۱۴۰۵/۰۸/۱۰"
    card = postprocess('```json\n{"organization": "x", "deadline_jalali": null}\n```', normalize(text))
    assert card.deadline_jalali == "1405/08/10" and card.deadline_iso == "2026-11-01"
    assert card.bond_amount_rial == 500_000_000


def test_rule_baseline_on_samples():
    gold, notices = load_gold(), load_notices()
    preds = {k: rule_extract(v) for k, v in notices.items()}
    s = score(preds, gold)
    assert s["accuracy"]["bond_amount_rial"] >= 0.9


def test_extended_deadline_uses_new_date():
    t = normalize("مهلت ارسال پیشنهاد که قبلاً ۰۵/۸/۱ بود، تا تاریخ ۰۵/۸/۱۵ ساعت ۱۶ تمدید گردید.")
    assert rule_extract(t)["deadline_jalali"] == "1405/08/15"


def test_prompt_injection_sample_not_obeyed_by_rules():
    notices = load_notices()
    r = rule_extract(notices["N10"])
    assert r["deadline_jalali"] == "1405/08/24" and r["bond_amount_rial"] == 900_000_000


def test_fewshot_examples_are_normalized_and_batch_works():
    import pytest
    pytest.importorskip("langchain_core")
    from langchain_core.runnables import RunnableLambda
    from tenderyar.extractor import extract_batch
    from tenderyar.prompts import EXAMPLES
    for e in EXAMPLES:
        assert e["notice"] == normalize(e["notice"]) and not any(c in e["output"] for c in "۰۱۲۳۴۵۶۷۸۹")

    def fake_llm(x):                      # no API key needed: echo a fixed JSON or fail
        if "boom" in x["notice"]:
            raise RuntimeError("quota")
        return {"organization": "شهرداری", "deadline_jalali": "۱۴۰۵/۰۸/۱۰"}
    out = extract_batch(["آخرین مهلت ارسال ۱۴۰۵/۰۸/۱۰", "boom آخرین مهلت ارسال ۱۴۰۵/۰۸/۱۲"], chain=RunnableLambda(fake_llm))
    assert out[0]["ok"] and out[0]["card"]["deadline_iso"] == "2026-11-01"
    assert not out[1]["ok"] and out[1]["card"]["deadline_jalali"] == "1405/08/12"


def test_synthetic_generator(tmp_path):
    import importlib.util, pathlib
    spec = importlib.util.spec_from_file_location("ms", pathlib.Path("data/make_synthetic.py"))
    ms = importlib.util.module_from_spec(spec); spec.loader.exec_module(ms)
    ms.main(["--n", "30", "--seed", "1", "--out", str(tmp_path)])
    gold, notices = load_gold(tmp_path / "gold.jsonl"), load_notices(tmp_path / "notices")
    preds = {k: rule_extract(v) for k, v in notices.items()}
    acc = score(preds, gold)["accuracy"]
    assert len(gold) == 30 and acc["deadline_jalali"] >= 0.95 and acc["bond_amount_rial"] >= 0.95
