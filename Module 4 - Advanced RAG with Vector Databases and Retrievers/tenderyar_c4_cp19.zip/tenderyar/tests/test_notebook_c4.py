"""C4 notebook is valid JSON, 19 numbered code cells, every cell parses (shell/magic lines skipped)."""
import ast, json, pathlib, re
NB = pathlib.Path(__file__).resolve().parents[1] / "notebooks/C4_TenderYar_v0_4.ipynb"


def test_c4_notebook_cells_parse():
    nb = json.loads(NB.read_text(encoding="utf-8"))
    code = [c for c in nb["cells"] if c["cell_type"] == "code"]
    assert len(code) == 19
    for i, c in enumerate(code, 1):
        src = c["source"] if isinstance(c["source"], str) else "".join(c["source"])
        assert src.startswith(f"# Cell {i} ·")
        ast.parse("\n".join(l for l in src.splitlines() if not l.lstrip().startswith(("!", "%"))))
