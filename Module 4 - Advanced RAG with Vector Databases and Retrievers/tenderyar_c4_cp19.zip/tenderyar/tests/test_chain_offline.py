"""The real C1 chain (prompt | llm.with_fallbacks | JsonOutputParser | postprocess) with a FAKE chat model.
Proves templates format (no stray { } in few-shot JSON), the parser + Pydantic accept the output, the fallback
model is used when the primary fails, and chain.batch keeps going on errors — all without an API key."""
import json
import pytest

pytest.importorskip("langchain_core")
from langchain_core.language_models.fake_chat_models import FakeListChatModel  # noqa: E402
from langchain_core.messages import AIMessage  # noqa: E402
from langchain_core.runnables import RunnableLambda  # noqa: E402

from tenderyar import extractor  # noqa: E402

GOLD = [json.loads(l) for l in open("data/gold.jsonl", encoding="utf-8")]
NOTICE = open(f"data/notices/{GOLD[0]['id']}.txt", encoding="utf-8").read()


def _boom(_):
    raise RuntimeError("429 quota (simulated)")


# Note: FakeListChatModel has its own batch() that ignores return_exceptions, so the fallback test uses plain
# Runnables (a real ChatGoogleGenerativeAI uses the standard Runnable.batch).
PRIMARY_FAILS = RunnableLambda(_boom)


def _answer(row):
    return "```json\n" + json.dumps({k: v for k, v in row.items() if k != "id"}, ensure_ascii=False) + "\n```"


def _patch(monkeypatch, primary, backup):
    def fake_get_llm(model=extractor.DEFAULT_MODEL, temperature=0.0):
        return primary if model == extractor.DEFAULT_MODEL else backup
    monkeypatch.setattr(extractor, "get_llm", fake_get_llm)


@pytest.mark.parametrize("few_shot", [True, False])
def test_chain_formats_and_parses(monkeypatch, few_shot):
    _patch(monkeypatch, FakeListChatModel(responses=[_answer(GOLD[0])]), None)
    chain = extractor.build_chain(few_shot=few_shot, fallback=None)
    r = extractor.extract(NOTICE, chain=chain)
    assert r["ok"], r["error"]
    assert r["card"]["deadline_jalali"] == GOLD[0]["deadline_jalali"]
    assert r["card"]["deadline_iso"]                      # computed in code, not by the LLM


def test_fallback_and_batch(monkeypatch):
    _patch(monkeypatch, PRIMARY_FAILS, RunnableLambda(lambda _: AIMessage(content=_answer(GOLD[0]))))
    chain = extractor.build_chain()                      # primary fails -> backup answers
    out = extractor.extract_batch([NOTICE, NOTICE, NOTICE], chain=chain)
    assert len(out) == 3 and all(o["ok"] for o in out), [o["error"] for o in out]
    assert out[0]["card"]["bond_amount_rial"] == GOLD[0]["bond_amount_rial"]
