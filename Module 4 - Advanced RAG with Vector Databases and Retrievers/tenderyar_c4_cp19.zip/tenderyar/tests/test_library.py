"""v0.3 library: where-filter shape, hard filter rules, idempotent upsert, Jalali → ts, categories."""
import pytest
from tenderyar.library.search import build_where, search
from tenderyar.library.match import hard_filter, match, precision_at_k
from tenderyar.library.cards import jalali_to_ts, parse_grade, card_meta
from tenderyar.library.categories import classify
from tenderyar.rag.index import HashEmbeddings

P = {"name": "راه‌سازان زاگرس", "fields": ["راه و ساختمان"], "grade": {"راه و باند": 3}, "provinces": ["اصفهان"], "max_bond_rial": 5_000_000_000}
C = {"id": "T1", "province": "اصفهان", "category": "راه و ساختمان", "deadline_jalali": "1405/09/10",
     "bond_amount_rial": 2_000_000_000, "required_grade": "رتبه 3 راه و باند", "organization": "اداره راه"}


def test_build_where_shapes():
    assert build_where() is None
    assert build_where(province="اصفهان") == {"province": {"$eq": "اصفهان"}}
    w = build_where(province=["اصفهان", "یزد"], category="راه و ساختمان", after="1405/08/15", max_bond=5e9)
    assert set(w) == {"$and"} and len(w["$and"]) == 4
    assert w["$and"][0] == {"province": {"$in": ["اصفهان", "یزد"]}}
    assert w["$and"][2] == {"deadline_ts": {"$gte": jalali_to_ts("1405/08/15")}}
    assert w["$and"][3] == {"bond_rial": {"$lte": 5_000_000_000}}


def test_jalali_text_and_numeric_agree():
    assert jalali_to_ts("۱۵ آبان ۱۴۰۵") == jalali_to_ts("1405/08/15") == jalali_to_ts("۱۴۰۵/۰۸/۱۵")
    with pytest.raises(ValueError):
        build_where(after="فردا")


def test_parse_grade_and_meta():
    assert parse_grade("حداقل رتبه ۵ رشته آب") == ("آب", 5) and parse_grade(None) == ("", 0)
    m = card_meta(C)
    assert m["grade_level"] == 3 and isinstance(m["deadline_ts"], int) and m["bond_rial"] == 2_000_000_000


def test_hard_filter_accepts_and_rejects():
    ok, why = hard_filter(P, C, today="1405/08/20")
    assert ok and why[0] == "رتبه کافی است"
    assert not hard_filter(P, dict(C, required_grade="رتبه 2 راه و باند"))[0]          # grade too low
    assert not hard_filter(P, dict(C, deadline_jalali="1405/08/01"), today="1405/08/20")[0]  # expired
    ok, why = hard_filter(P, dict(C, bond_amount_rial=9_000_000_000))
    assert not ok and any("سقف" in w for w in why)                                    # bond too big


def test_categories():
    assert classify("روکش آسفالت محور اصلی") == "راه و ساختمان"
    assert classify("خرید ۸۰۰ دستگاه کنتور هوشمند") == "برق و انرژی"
    assert classify("چیزی نامربوط") == "سایر"


def test_upsert_idempotent_and_crud(tmp_path):
    chromadb = pytest.importorskip("chromadb")
    from tenderyar.library import store
    emb = HashEmbeddings(dim=64)
    coll = store.get_collection(store.get_client(str(tmp_path)))
    for _ in range(2):
        store.upsert_tender(coll, C, ["متن یک", "متن دو"], emb)
    store.upsert_tender(coll, dict(C, id="T2", province="یزد"), ["آسفالت یزد"], emb)
    assert coll.count() == 3 and store.stats(coll)["tenders"] == 2
    hits = search(coll, emb, "آسفالت", where=build_where(province="یزد"))
    assert [h["tender_id"] for h in hits] == ["T2"]
    assert store.update_meta(coll, "T1", bond_rial=1) == 2
    assert store.update_meta(coll, "T1", deadline_jalali="1405/09/01") == 2           # also refreshes deadline_ts
    assert coll.get(ids=["T1:0"], include=["metadatas"])["metadatas"][0]["deadline_ts"] == jalali_to_ts("1405/09/01")
    assert store.delete_tender(coll, "T2") == 1 and coll.count() == 2
    # persistence: a new client on the same folder sees the data
    assert store.get_collection(store.get_client(str(tmp_path))).count() == 2
    rows = match(P, coll, emb, [C], k=5, today="1405/08/20")
    assert rows[0]["tender_id"] == "T1" and precision_at_k(["T1"], {"T1"}, k=1) == 1.0


def test_app_profile_errors_are_persian():
    import pytest
    from tenderyar.apps.gradio_library import parse_profile
    assert parse_profile('{"fields": ["آب"]}')["fields"] == ["آب"]
    for bad in ('{"fields": ["آب"]', "", "[]", '{"name": "x"}'):
        with pytest.raises(ValueError) as e:
            parse_profile(bad)
        assert "پروفایل" in str(e.value)
