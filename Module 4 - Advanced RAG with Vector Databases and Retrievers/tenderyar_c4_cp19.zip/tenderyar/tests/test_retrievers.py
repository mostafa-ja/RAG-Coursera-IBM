from tenderyar.rag.clean import search_normalize, tokens


def test_search_normalize_spec():
    assert search_normalize("كتاب\u200cها ي") == "کتاب ها ی"


def test_search_normalize_variants_digits():
    assert search_normalize("اطاق ۱۴۰۵/۱۲۷ هیأت") == "اتاق 1405/127 هیئت"


def test_tokens_keep_numbers_drop_stopwords():
    assert tokens("مناقصه شماره ۱۴۰۵/۱۲۷ در اصفهان") == ["مناقصه", "شماره", "1405/127", "اصفهان"]


from tenderyar.rag.metrics import recall_at_k, mrr, ndcg_at_k, judge


def test_metrics_toy():
    assert recall_at_k([3, 3, 7, 1], [1], k=3) == 1.0      # duplicates collapsed
    assert recall_at_k([3, 7, 9], [1], k=3) == 0.0
    assert mrr([3, 7, 1], [1]) == 1 / 3
    assert abs(ndcg_at_k([1, 2], [1, 2]) - 1.0) < 1e-9
    assert round(ndcg_at_k([9, 1], [1]), 3) == 0.631


def test_judge_offline():
    assert judge("مبلغ ضمانت ۵۰۰ میلیون ریال است", "۵۰۰ میلیون ریال") == 2
    assert judge("نمی‌دانم", "۵۰۰ میلیون ریال") == 0


from tenderyar.rag.retrievers import jalali_filter, _ts


def test_jalali_preparser_spec():
    w, _ = jalali_filter("مناقصه‌های راه‌سازی اصفهان با مهلت قبل از ۱۵ آبان ۱۴۰۵")
    assert w == {"deadline_ts": {"$lt": 1793923200}}       # 1405/08/15 = 2026-11-06 00:00 UTC


def test_jalali_preparser_five_phrasings():
    t = _ts(1405, 8, 15)
    assert jalali_filter("بعد از ۱۵ آبان")[0] == {"deadline_ts": {"$gte": t + 86400}}
    assert jalali_filter("تا ۱۵ آبان")[0] == {"deadline_ts": {"$lte": t}}
    assert jalali_filter("همین هفته", today="1405/08/20")[0]["$and"][0] == {"deadline_ts": {"$gte": _ts(1405, 8, 20)}}
    assert jalali_filter("ماه آینده", today="1405/08/20")[0]["$and"][1] == {"deadline_ts": {"$lt": _ts(1405, 10, 1)}}
    assert jalali_filter("مهلت ۱۴۰۵/۰۸/۱۵")[0]["$and"][0] == {"deadline_ts": {"$gte": t}}
    assert jalali_filter("ضمانت چقدر است؟") == (None, "ضمانت چقدر است؟")


from langchain_core.documents import Document
from tenderyar.rag.retrievers import BM25, rrf_fuse, Hybrid


def _docs():
    t = ["مبلغ تضمین شرکت در مناقصه ۵,۵۵۰,۰۰۰,۰۰۰ ریال است.", "برای هر روز تاخیر جریمه یک دهم درصد کسر می‌شود.",
         "مدت اجرای کار ۹ ماه شمسی است.", "رتبه ۵ رشته آب الزامی است."]
    return [Document(page_content=x, metadata={"chunk_id": f"c{i}", "page": i + 1}) for i, x in enumerate(t)]


def test_bm25_exact_numbers_and_zwnj():
    b = BM25(_docs(), k=2)
    assert b.invoke("رتبه ۵")[0].metadata["page"] == 4
    assert b.invoke("تضمین 5,550,000,000")[0].metadata["page"] == 1
    assert b.invoke("جریمه تاخیر میشود")[0].metadata["page"] == 2   # ZWNJ-free spelling still matches


def test_rrf_fuse_formula():
    d = _docs()
    fused = rrf_fuse([[d[0], d[1]], [d[1], d[2]]], weights=[1, 1], c=60)
    assert fused[0][0] is d[1] and abs(fused[0][1] - (1 / 62 + 1 / 61)) < 1e-12
    assert [x[0].metadata["page"] for x in fused] == [2, 1, 3]


class _Fixed:
    def __init__(self, docs): self.docs = docs
    def invoke(self, q): return self.docs


def test_hybrid_weights():
    d = _docs()
    h = Hybrid([_Fixed([d[0], d[1]]), _Fixed([d[1], d[0]])], weights=[0.2, 0.8], k=2)
    assert h.invoke("x")[0] is d[1]


from tenderyar.rag.retrievers import (offline_paraphrases, MultiQuery, split_articles, ParentRetriever,
                                      SelfQuery, rerank)


def test_multi_query_offline_paraphrases():
    ps = offline_paraphrases("جریمه تاخیر چقدر است؟", n=3)
    assert len(ps) >= 2 and all(p != "جریمه تاخیر چقدر است؟" for p in ps)
    mq = MultiQuery(BM25(_docs(), k=3), n=3, k=3)
    assert mq.invoke("دیرکرد چه جریمه ای دارد")[0].metadata["page"] == 2
    assert len(mq.last_queries) >= 2


def test_parent_returns_whole_article():
    page = Document(page_content="تاخیرات و جرایم\nماده ۳۰ - برای هر روز تاخیر، جریمه یک دهم درصد کسر میشود.\n"
                    "ماده ۳۱ - سقف جریمه تاخیر ده درصد مبلغ پیمان است.", metadata={"source": "P01.pdf", "page": 9})
    arts = split_articles(page)
    assert [a.page_content.split()[0] for a in arts] == ["تاخیرات", "ماده", "ماده"]
    pr = ParentRetriever([page], child_size=40, k=1)
    assert len(pr.children) > len(arts)
    top = pr.invoke("سقف جریمه")[0]
    assert top.page_content.startswith("ماده ۳۱") and top.page_content.endswith("است.")


def test_self_query_offline_structure():
    sq = SelfQuery(vs=None, today="1405/08/20")
    s = sq.structured("مناقصه‌های راه‌سازی اصفهان با مهلت قبل از ۱۵ آبان ۱۴۰۵")
    f = s["filter"]["$and"]
    assert {"province": {"$eq": "اصفهان"}} in f and {"category": {"$eq": "راه و ساختمان"}} in f
    assert {"deadline_ts": {"$lt": _ts(1405, 8, 15)}} in f and "اصفهان" not in s["query"]


def test_rerank_offline():
    d = _docs()
    assert rerank(d, "سقف مدت اجرای کار چند ماه", top_n=1)[0].metadata["page"] == 3


import json, pathlib, pytest
ROOT = pathlib.Path(__file__).resolve().parents[1]


def test_tenderqa_v0_shape():
    rows = [json.loads(l) for l in open(ROOT / "data/tenderqa/v0.jsonl", encoding="utf-8")]
    assert len(rows) == 60 and len({r["id"] for r in rows}) == 60
    assert {r["type"] for r in rows} == {"fact", "list", "clause", "numeric", "date", "negative"}
    assert all((r["type"] == "negative") == (r["gold_pages"] == []) for r in rows)
    assert sum(r["origin"] == "hand" for r in rows) == 30


def test_bench_run_small():
    pytest.importorskip("pymupdf")
    from tenderyar.rag import bench
    qa = [r for r in bench.load_tenderqa(ROOT / "data/tenderqa/v0.jsonl") if r["package"] == "P01"][:6]
    df = bench.run({"bm25": lambda p, c: BM25(c, k=5)}, qa, root=ROOT)
    assert df.loc[0, "n"] == 6 and 0 <= df.loc[0, "MRR"] <= df.loc[0, "recall@5"] <= 1


def test_tokens_numbers_and_zwnj_glue():
    assert "5550000000" in tokens("۵,۵۵۰,۰۰۰,۰۰۰ ریال")
    assert "شود" in tokens("می‌شود") and tokens("میشود") == ["شود"]


def test_msg_text_handles_gemini3_block_lists():
    from tenderyar.rag.metrics import msg_text, judge
    class M:  # Gemini 3 style: content is a list of blocks, no .text
        content = [{"type": "text", "text": "نمره: 2"}]
    assert msg_text(M()) == "نمره: 2"
    class L:
        def invoke(self, p): return M()
    assert judge("x", "y", llm=L()) == 2
    from tenderyar.rag.retrievers import paraphrases
    class P:
        def invoke(self, p):
            class R: content = [{"type": "text", "text": "۱. جرایم دیرکرد چقدر است\n۲. مبلغ جریمه تاخیر"}]
            return R()
    assert len(paraphrases("جریمه تأخیر چقدر است؟", P(), 3)) == 2


def test_naive_date_filter_is_wrong_preparser_right():
    from tenderyar.rag.retrievers import jalali_filter, llm_date_filter
    q = "مناقصه‌های راه‌سازی اصفهان با مهلت قبل از ۱۵ آبان ۱۴۰۵"
    good = jalali_filter(q)[0]["deadline_ts"]["$lt"]
    bad = llm_date_filter(q)["deadline_ts"]["$lt"]
    assert good == 1793923200 and bad != good and bad < 0     # 15 Aug 1405 AD = before 1970


def test_tokens_drop_persian_punctuation():
    from tenderyar.rag.clean import tokens
    assert tokens("پیش‌پرداخت چند درصد است؟") == ["پیش", "پرداخت", "چند", "درصد", "پیشپرداخت"]
    assert "شرکت" in tokens("تضمين شركت، بند")
