# HTML style guide — IBM RAG & Agentic AI revision guides (+ TenderYar section)

Reference implementation: **`html/RAG_C1_Guide_v13.html`** (Course 1, "Claude" theme — see §9). v12 = same content, old blue theme. Every new course guide is **one self-contained HTML file**
with the *same CSS, JS and markup*. Easiest path: copy the `<head>` (all `<style>` blocks) and every `<script>` block after
`</main>` from the **v13** C1 guide unchanged (the last block must stay `<style id="v13-theme">`), then write new content inside `<main>`. Change only the localStorage prefix (see §7).

## 1. Page skeleton (order of sections)
```
<nav id="side"> … sidebar (search box #sq, progress .bar, links) … </nav>
<main>
  section.hero#top          eyebrow, h1, .lead, .hstats cards, "How to use" box + study plan (ol.plan), quiz dashboard #qdash
  section.week#start        orientation: concept map diagram + Colab setup cell (Secrets → GOOGLE_API_KEY)
  section.week#w1 … #wN     one per course module (week)
  section#cmp               Appendix A · comparison tables, IBM → Colab mapping, troubleshooting
  section.week#kit          Appendix B · builder's toolkit (reusable code patterns P1…Pn)
  section.week#proj         Appendix C · 🏗 TenderYar vX.Y (the project part of this course)   ← NEW since v12
  section#cover             ✅ source coverage matrix (every bullet of every source → lesson id)
  section#exam              🎲 mixed exam simulator
  section#gloss  #fcards  #cheat  #ex     glossary · flashcards · one-page cheat sheet · Colab exercises
</main>
<script> … </script>
```

## 2. IDs and numbering
| Thing | Pattern | Example |
|---|---|---|
| week section | `w1`, `w2`, … | `<section class="week" id="w2">` |
| lesson | `w<week>-<slug>` | `w2-lcel` |
| toolkit pattern | `kit-p<n>` | `kit-p3` |
| project section | `proj`; articles `proj-why`, `proj-setup`, `proj-s1` … `proj-guard`, `proj-done` | |
| quiz | `qz-week<w>_quiz<n>`, questions `week<w>_quiz<n>-<i>` | |
| secnum text | `Week 2 · 2.3`, `Project · C.4 · Step 3 · Module 1` | |

Any element with `data-track=""` and an `id` gets a "Mark section complete" button and counts in the sidebar progress.

## 3. Lesson card (copy exactly)
```html
<article class="lesson" data-track="" id="w1-pe">
 <div class="secnum">Week 1 · 1.4</div><h2>Title</h2>
 <div class="meta"><span>⏱ ~8 min</span><span>🗺 1 diagram</span><span>💻 2 code cells</span></div>
 <div class="tldr"><span class="nut">In a nutshell</span> 2–3 sentence summary.</div>
 <div class="obj"><div class="objl"><b>🎯 After this lesson you can</b><ul><li>…</li></ul></div>
      <div class="objr"><b>💡 In plain words</b><p>Analogy for a beginner.</p></div></div>
 <h3>…</h3><p>…</p>
 <div class="svgw"><svg viewBox="0 0 930 250" style="max-width:1000px">…</svg><div class="cap">Caption</div></div>
 <details><summary>💻 Cell 3 · what it does</summary><pre><code><span class="c"># comment</span>
code…</code></pre></details>
 <p>✅ <b>You should see</b> … exact expected output …</p>
 <div class="take"><h4>Key takeaways</h4><div class="tgrid">
   <div class="box why"><b class="t">Why it matters</b><ul><li>…</li></ul></div>
   <div class="box pit"><b class="t">Common pitfalls</b><ul><li>…</li></ul></div>
   <div class="box rem"><b class="t">Remember</b><ul><li>…</li></ul></div></div></div>
</article>
```
Boxes: `box why` (cactus green) · `box pit` (clay red) · `box tip` (kraft gold) · `box rem` (heather purple) · `box try` (green, "Try it" / bridge).
Tables always inside `<div class="tw"><table>…</table></div>`. Tags: `<span class="tag t-green|t-orange|t-purple">`.
Keyboard keys: `<kbd>S</kbd>`. Links to other lessons: `<a href="#w1-icl">→ 1.5</a>`.

## 4. Diagrams (inline SVG only, no images from the web)
* Wrap in `.svgw`; `viewBox` width 900–940; `style="max-width:1000px"`; caption in `.cap`.
* Node classes: `n` (terracotta outline = input/step), `n2` (heather = prompt/template), `n3` (cactus green = result / good), `n4` (kraft gold = model / risk); arrows `<path class="ln" d="M x1,y1 L x2,y2"/>` (marker comes from CSS); muted text `class="mt"`.
* Persian text in SVG: add `class="prs"`; avoid mixing Persian and Latin in one `<text>` (bidi reorders it) — put them in separate boxes.
* Use the generator helpers in `kit/svg_helpers.py` (`B()` box, `A()` arrow, `T()` text, `wrap()`), the same code as `html/make_diagrams.py`.
* Aim for ≥ 1 diagram per lesson and per project step. Diagram types that work: pipeline (left→right), before/after table, staircase/roadmap, voting fan-in, sequence (client → server → model), state graph (C7).

## 5. Quizzes, flashcards, coverage
* Quiz: `<div class="quiz" id="qz-…"><span class="score"></span><h3>📝 …</h3><button class="btn o reset">Reset quiz</button>` then per question `<div class="q" data-a="<index of correct option>" id="…"><p><b>Q1.</b> …</p><button class="opt">A. …</button>…<div class="ex">✅ <b>Answer A.</b> explanation + 📖 Review link</div></div>`.
* Include every Coursera practice + graded quiz question (rewritten in your words if needed) + extra checks.
* Flashcard: `<div class="fc"><div><div class="fa">Term</div><div class="fb">Definition</div></div></div>` — **`.fa` is reserved for flashcards; use `.prs` for Persian text.**
* Module-summary checklist: `<li><label><input class="sumchk" data-k="w1s0" type="checkbox"/> bullet</label> <a class="goto" href="#w1-icl">→ 1.5</a></li>`.
* Coverage matrix rows: concept from source → lesson link. State the total ("128/128 items covered").

## 6. TenderYar project section (Appendix C) — rules
1. Header: `<section class="week" data-track="" id="proj"><div class="eyebrow">Appendix C · Portfolio project (optional)</div><h1>🏗 Project: <span class="prs">مناقصه‌یار</span> (TenderYar) vX.Y — name</h1><p class="wkintro">…</p>`.
2. Articles in this order: `proj-why` (what this version adds + pipeline diagram + where it sits in the 10-course table) → `proj-setup` (restore repo from previous tag, install, tests) → `proj-s1…proj-sN` (one per module concept, secnum says which module it re-uses) → optional side quest → `proj-done`.
3. Each step = nutshell · 🎯 steps · 💡 plain words · **diagram** · closed `<details>` code cells numbered "Cell n" continuing the notebook numbering · ✅ "You should see" with concrete numbers · key takeaways.
4. `proj-done` contains `<ul class="pdone">` with `<li><label><input type="checkbox" data-k="pd<course>_<n>"/> …</label></li>` (saved automatically), a results table to fill, the GitHub push cell, the resume line, "What the next course adds".
5. Week-end bridge boxes: `<div class="box try bridge"><b class="t">🏗 TenderYar checkpoint — after Week n</b><p>…</p><p><b>Go to:</b> links</p></div>` at the end of each week section.
6. Sidebar group: `<a class="gh" href="#proj">Appendix C · 🏗 Project: TenderYar vX.Y</a><div class="grp"><a class="sub" href="#proj-why">C.0 …</a>…</div>`, placed before `#cover`.
7. Add a "🌱 Beyond the course" box in at least 3 steps: a related topic not in the syllabus (Unicode/bidi, OCR, BM25 maths, Docker, CI …) with 1–2 links.

## 7. Per-course changes
* `<title>Course N Revision Guide (vX) · RAG & Agentic AI</title>`.
* localStorage keys: C1 uses prefix `c1m13_` (`_prog`, `_qs`, `_kn`, `_th`, `_sum`, `_pd`). For course N use `cNm_` — search-and-replace `c1m13_` in the copied scripts so progress of different courses never mixes.
* Models: `gemini-3.8-flash` (main), `gemini-3.5-flash-lite` (cheap), `gemini-2.5-flash` (fallback), embeddings `models/gemini-embedding-2`; key from Colab Secrets `GOOGLE_API_KEY`. Replace IBM watsonx code with these, and add an "IBM → Colab" row in Appendix A for every replacement.

## 8. Build workflow (recommended)
Write the project section as small files `html/parts/A_…html`, `B_…`, … (one checkpoint each), diagrams in `html/make_diagrams.py`,
and assemble with a `build_vX.py` like `html/build_v12.py`. Check with a headless screenshot in **light and dark** mode (Playwright + Chromium, set `data-theme=dark` on `<html>`), 0 JS errors, or just open the file in a browser and press the ◐ button.

## 9. Theme — "Notion pastel" (v14, use for every course)
Calm, low-distraction. All colours are CSS variables in `<style id="v14-theme">` (source: `html/build_v14.py`), which must be the LAST
`<style>` in `<head>`. Never write a hex colour in lesson markup or SVG — use classes/variables only.

| Role | Light | Dark |
|---|---|---|
| page / sidebar (thin divider) | `#FFFFFF` / page colour + `#E6E5E3` line | `#191919` |
| cards, diagram panels, quizzes (flat) | `#F9F8F7` | `#202020` (soft2 `#2A2A29`) |
| borders | `#E6E5E3` | `rgba(255,255,255,.18)` |
| text / muted | `#2C2C2B` / `#7D7A75` | `#FFFFFF` |
| code background | `#F6F5F3` | — |
| blue (primary: links, eyebrow, progress) | `#2783DE` / `#E5F2FC` | `#5E9FE8` on 12 % tint |
| purple | `#9065B0` / `#F3EBF8` | `#BF8EDA` |
| green | `#46A171` / `#E8F1EC` | `#72BC8F` |
| orange | `#D5803B` / `#FBEBDE` | `#DE9255` |
| red | `#E56458` / `#FCE9E7` | `#E97366` |

**Shapes:** no shadows, no gradients; radius 14 px cards, 10 px callouts/inputs. Callout = 4 px left border (strong colour) on its tint; tags = pastel pills.
**Fonts:** one system sans stack for everything (-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial); bold headings,
slight negative tracking (hero h1 44 px, h2 28 px, h3 19 px); body 16.5 px / 1.65; code Menlo/Consolas; Vazirmatn only for `.prs`/`.rtl`. No serif/Inter/JetBrains.
**Buttons:** quiet pills; primary/active = `#2C2C2B` bg + white text; secondary = outline. **Dark mode** follows the system setting; ◐ toggle kept (`cNm_th`).
**Apply:** copy `<head>` + all `<style>` + `<script>` from `html/RAG_C1_Guide_v14.html`, or run `python html/build_v14.py old.html new.html`.
**Quality bar:** light + dark screenshots of hero, a lesson diagram, a code cell, a quiz, the project section; 0 console errors; Persian renders RTL in Vazirmatn.
