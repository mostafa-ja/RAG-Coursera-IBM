# Course specs — TenderYar part of each course guide

Each file is the **exact brief** for the "Appendix C · 🏗 Project" section of that course's HTML guide and for the code/notebook of that version.
Use it with `kit/NEXT_UNIT_PROMPT.md` (Prompt A) and `kit/HTML_STYLE_GUIDE.md`.

| Course | Spec | Version | Visible result | Resume metric |
|---|---|---|---|---|
| C1 | (done — `html/RAG_C1_Guide_v13.html`, `notebooks/C1_TenderYar_v0_1.ipynb`) | v0.1 Tender card | 10 notices → valid JSON cards, Gradio + Flask | field accuracy |
| C2 | `C02.md` (done — `html/RAG_C2_Guide_v1.html`, `notebooks/C2_TenderYar_v0_2.ipynb`) | v0.2 Ask the package | PDF chat with `[ص n]` citations | answer & citation acc. /15 |
| C3 | `C03.md` (done — `html/RAG_C3_Guide_v1.html`, `notebooks/C3_TenderYar_v0_3.ipynb`) | v0.3 Library + matching | filtered library, top-5 tenders for a company | precision@5 |
| C4 | `C04.md` | v0.4 Better search + TenderQA v0 | recall chart before/after | recall@5 X → Y |
| C5 | `C05.md` | v0.5 Scans, tables, voice | OCR side-by-side, BoQ DataFrame, voice Q | CER, totals ok |
| C6 | `C06.md` | v0.6 Tools + chart agent | tool trace, Persian charts | numeric acc. LLM vs tools |
| C7 | `C07.md` | v0.7 Bid/no-bid graph | Mermaid graph, memo, approval step | agreement with expert |
| C8 | `C08.md` | v0.8 Review crew | 3 reviews + DOCX checklist & cover letter | checklist coverage |
| C9 | `C09.md` | v0.9 MCP server | Claude Desktop/Cursor calling TenderYar | tool success rate |
| C10 | `C10.md` | v1.0 Public release | HF Space, HF dataset, video | attack success A→B, final table |

Every spec has the same 8 parts: what it adds (+ pipeline sketch) · before you start (deps, data) · package changes (files + signatures) ·
steps `proj-s1…` (cells, diagram, "you should see", 🌱 beyond) · `proj-done` checklist keys `pd<N>_<n>` · RESULTS rows · GitHub to learn from · resume bullet + hand-off.

If your Coursera module titles differ, keep the steps and change only which module each step "re-uses".
