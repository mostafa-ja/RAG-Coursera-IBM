"""SVG helpers for guide diagrams (same as html/make_diagrams.py). Example at the bottom.
Each diagram uses the guide's SVG classes: n (accent = terracotta), n2 (heather purple), n3 (cactus green), n4 (kraft gold), ln (arrow), mt (muted)."""
import os, html
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "diagrams"); os.makedirs(OUT, exist_ok=True)
E = html.escape
def B(x, y, w, h, cls, t, sub="", fa=False, fs=12):
    c = ' class="prs"' if fa else ""
    cx = x + w / 2
    r = f'<rect class="{cls}" x="{x}" y="{y}" width="{w}" height="{h}" rx="10"/>'
    if sub:
        r += f'<text{c} x="{cx}" y="{y+h/2-3}" font-size="{fs}" font-weight="700" text-anchor="middle">{E(t)}</text>'
        r += f'<text x="{cx}" y="{y+h/2+13}" font-size="10" text-anchor="middle" class="mt">{E(sub)}</text>'
    else:
        r += f'<text{c} x="{cx}" y="{y+h/2+4}" font-size="{fs}" font-weight="700" text-anchor="middle">{E(t)}</text>'
    return r
def A(x1, y1, x2, y2): return f'<path class="ln" d="M{x1},{y1} L{x2},{y2}"/>'
def T(x, y, t, fs=11, anchor="middle", bold=False, cls="", fa=False):
    c = (cls + (" prs" if fa else "")).strip()
    return f'<text x="{x}" y="{y}" font-size="{fs}" text-anchor="{anchor}"{" font-weight=\"700\"" if bold else ""}{f" class=\"{c}\"" if c else ""}>{E(t)}</text>'
def wrap(title, vb, body, cap):
    return (f'<h3>🗺 {title}</h3><div class="svgw"><svg style="max-width:1000px" viewBox="0 0 {vb}">{body}</svg>'
            f'<div class="cap">{cap}</div></div>\n')

if __name__ == "__main__":   # example: a 3-box pipeline
    body = B(20, 30, 160, 52, "n", "PDF", "tender package") + A(182, 56, 230, 56) + B(232, 30, 160, 52, "n2", "splitter", "Persian-aware") + A(394, 56, 442, 56) + B(444, 30, 160, 52, "n3", "chunks", "with page numbers")
    print(wrap("Example pipeline", "630 110", body, "Caption under the diagram."))
