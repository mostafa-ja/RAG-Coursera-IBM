# C4 inventory — "Advanced RAG with Vector Databases and Retrievers" (= coverage matrix source)
Source: attached Module 4 zips (part1+part2). Video titles reconstructed from slide deck "Advanced RAG with Vector Databases and Retrievers.pdf" (13 pp, image-only).
No graded quiz files were attached → DECISION: write practice + graded-style questions in my own words from summary.md + cheat sheets.

## Week 1 (M1) — Advanced retrievers
| id | type | item | source |
|---|---|---|---|
| V-1 | video | What is a LangChain retriever? Vector store-based retriever (similarity, MMR, score threshold) | slides p2–3 |
| V-2 | video | Multi-Query, Self-Query, Parent Document retrievers | slides p4–6 |
| V-3 | video | LlamaIndex index types: VectorStoreIndex, DocumentSummaryIndex, KeywordTableIndex | slides p7 |
| V-4 | video | LlamaIndex core & advanced retrievers: Vector Index, BM25 (TF-IDF), Document Summary (LLM/embedding), Auto Merging, Recursive, Query Fusion (RRF / relative score / distribution-based); retrievers by use case | slides p8–9 |
| R-1 | reading | Lesson summary (M1/summary.md) | M1 |
| R-2 | reading | Cheat Sheet: Advanced Retrievers for RAG (3 pp) | M1 |
| L-1 | lab | Build a Smarter Search with LangChain Context Retrieval (companypolicies.txt; similarity/MMR/threshold, MultiQuery, SelfQuery, ParentDocument; Ex 1–2) | M1/LangChain retriever-v1.ipynb |
| L-2 | lab | Explore Advanced Retrievers in LlamaIndex (6 retrievers + RRF/relative-score/dist fusion) | M1/Advanced retrievers in LlamaIndex-v1.ipynb |
| Q-1 | quiz | Practice + graded quiz M1 (own questions) | — |
## Week 2 (M2) — Vector databases (FAISS, Chroma, Milvus)
| V-5 | video | What is FAISS / Chroma; key differences; what is an index | slides p10 |
| V-6 | video | Index types: Flat, IVF, LSH, HNSW; extending FAISS with Milvus; when to use which | slides p11–12 |
| R-3 | reading | Hierarchical Navigable Small World (HNSW) (11 pp) | M2 |
| R-4 | reading | Cheat Sheet: Build a Comprehensive RAG Application (FAISS vs Chroma) | M2 |
| L-3 | lab | Semantic Similarity with FAISS (20 Newsgroups, USE embeddings, IndexFlatL2) | M2/Lab1 M2 Faiss Chroma.ipynb (= root copy) |
| L-4 | project lab | AI-Powered YouTube Summarizer & QA Tool (RAG, LangChain, FAISS; ytbot.py, Gradio/Streamlit) | M2 PDF + YouTube_Summarizer_QA_Bot/ |
| Q-2 | quiz | Practice + graded quiz M2 (own) | — |
Duplicates noted: root `Explore Advanced Retrievers…` = M1 LlamaIndex lab; root `Build a Smarter Search…` = M1 LangChain lab; root `Semantic Similarity with FAISS` = M2 lab.
## Project
| P-1 | project | TenderYar v0.4 (kit/courses/C04.md) proj-s1…s5 |
