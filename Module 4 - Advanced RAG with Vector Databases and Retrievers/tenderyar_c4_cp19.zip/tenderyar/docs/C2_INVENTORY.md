# Course 2 · Build RAG Applications — source inventory (= coverage matrix rows)

Sources attached: `Build RAG Applications.pdf` (16 slide pages, image-only), week1/companyPolicies.txt, week2 lab PDFs + qabot.py,
week3 LlamaIndex cheat sheet, Icebreaker lab PDF + code, reading "LangChain and LlamaIndex Compared", lecture-notes.md,
4 Colab notebooks, Colab review notes, unfinished guide RAG_C2M2_Guide_v10.html (164/164 items mapped).

| # | Item | Type | Guide lesson |
|---|---|---|---|
| M1-1 | What is RAG? / Importance of RAG | video | w1-what |
| M1-2 | RAG process (retriever, generator, 8 steps diagram) | video | w1-process |
| M1-3 | Context encoding · chunks to vectors · questions to vectors | video | w1-encode |
| M1-4 | Vector similarity (dot vs cosine) · search · select top-K · response generation | video | w1-sim |
| M1-5 | What about models with long context windows? | reading | w1-long |
| M1-6 | Lab: Summarize private documents with RAG, LangChain & LLMs (companyPolicies.txt) part 1 | lab/notebook C02-M1-L1 | w1-lab |
| M1-7 | Lab part 2: prompt template, memory, chat loop | lab | w1-lab2 |
| M1-8 | Module 1 summary & highlights (12 bullets) | reading | w1-sum |
| M1-9 | Practice quiz · Graded quiz | quiz | w1-quiz (qz-week1_quiz1/2, extra) |
| M2-1 | Gradio: how it works (4 steps) | video | w2-gradio |
| M2-2 | Simple text input/output · multiple inputs · upload/drop files | video | w2-inputs |
| M2-3 | Lab: Set up a simple Gradio interface to interact with your models (C02-M2-L1) | lab | w2-llm |
| M2-4 | Lab: Construct a QA bot with LangChain + LLM (qabot.py, Construct-a-QA-Bot.pdf, C02-M2-L2) | lab | w2-qabot, w2-qatest |
| M2-5 | Module 2 summary checklist (8) | reading | w2-sum |
| M2-6 | Practice quiz · Graded quiz | quiz | w2-quiz |
| M3-1 | High-level overview of LlamaIndex · typical use cases | video | w3-what |
| M3-2 | Loading source documents · Document class · SimpleDirectoryReader | video | w3-load |
| M3-3 | Nodes · SentenceSplitter · other splitters (semantic, LangChain wrapper) | video | w3-nodes |
| M3-4 | Embeddings in-memory / persistent (Chroma, StorageContext) | video | w3-index |
| M3-5 | Prompt embedding & retrieval · response synthesizer · query engine | video | w3-query |
| M3-6 | Reading: LangChain and LlamaIndex compared | reading | w3-compare |
| M3-7 | Cheat sheet: Build RAG apps with LlamaIndex | reading | w3-index, w3-query, cheat |
| M3-8 | Lecture notes: Understanding LlamaIndex for RAG | reading | w3-what … w3-query |
| M3-9 | Lab: AI Icebreaker Bot with Granite + LlamaIndex (C02-M3-L1, icebreaker/) part 1 + 2 | lab | w3-ice1, w3-ice2 |
| M3-10 | Module 3 recap (31) · glossary (18) | reading | w3-sum, gloss |
| M3-11 | Practice quiz · Graded quiz | quiz | w3-quiz |
| P-1 | TenderYar v0.2 (kit/courses/C02.md) | project | proj-* |
