# C4 guide plan — html/RAG_C4_Guide_v1.html (built by html/build_c4_v1.py)
Shell = C1 v14 (head/styles/engines). Content = html/parts_c4/<section>_<L>_<name>.html, concatenated per section in
sorted order (first file opens `<section>`, last closes it). Special: `00_hero.html` (hero, `{les}{q}{svg}{fc}{gl}` counted),
`gloss_*.html` = `<tr>` rows only, `fcards_*.html` = `<div class="fc">` cards only, `exam` = C1 engine (Week 1/2 scope).
Reuse: C1 v14 Part D (#adv D.0–D.6, 5 SVG, 8 q) is a condensed version of Module 4 → reuse ideas/diagrams, expand to full lessons.
Coverage ids: docs/C4_INVENTORY.md (V-1..6, R-1..4, L-1..4, Q-1..2, P-1). Quiz ids week1_quiz1/2, week2_quiz1/2 (exam scope uses 'week'+n).

| step | file | articles (id · secnum · topic) | sources |
|---|---|---|---|
| CP119 | 00_hero.html + start_A.html | hero (study plan, how to use) · start-map 0.1 concept map · start-colab 0.2 Colab setup cell | slides p1, all |
| CP120 | w1_A_ret.html | w1 open + glance · w1-ret 1.1 retriever interface + vector-store retriever (similarity/MMR/threshold) | V-1, L-1 Ex1 |
| CP121 | w1_B_mq_sq.html | w1-mq 1.2 Multi-Query · w1-sq 1.3 Self-Query | V-2, L-1 |
| CP122 | w1_C_parent.html | w1-pd 1.4 Parent Document (+ L-1 Ex2) | V-2, L-1 |
| CP123 | w1_D_llama.html | w1-li 1.5 LlamaIndex index types · w1-lir 1.6 Vector/BM25/DocSummary retrievers | V-3, V-4, L-2 |
| CP124 | w1_E_merge_fuse.html | w1-am 1.7 Auto-merging + Recursive · w1-fus 1.8 Query fusion (RRF / relative score / distribution) | V-4, L-2, R-2 |
| CP125 | w1_F_sum_quiz.html | w1-pick 1.9 retrievers by use case · w1-sum checklist (R-1 bullets) · w1-quiz (2 quizzes) · closes w1 | R-1, R-2, Q-1 |
| CP126 | w2_A_faiss.html | w2 open · w2-what 2.1 FAISS/Chroma + what an index is · w2-idx 2.2 Flat/IVF/LSH/HNSW + Milvus | V-5, V-6 |
| CP127 | w2_B_hnsw.html | w2-hnsw 2.3 HNSW (layers, M, efConstruction, efSearch) | R-3 |
| CP128 | w2_C_lab.html | w2-lab 2.4 Semantic similarity with FAISS (20NG, IndexFlatL2) · w2-rag 2.5 FAISS vs Chroma app | L-3, R-4 |
| CP129 | w2_D_yt.html | w2-yt 2.6 YouTube summarizer + QA bot · w2-sum · w2-quiz · closes w2 | L-4, Q-2 |
| CP130 | cmp_A.html | Appendix A: retriever/index comparisons, IBM→Colab rows, troubleshooting | all |
| CP131–133 | kit_A..C.html | Appendix B toolkit (K.1 skills, P1–P6 patterns, K.2 debugging, K.3 mini-projects) | labs |
| CP134–136 | proj_A..D.html | Appendix C TenderYar v0.4 (proj-why, setup, s1–s5, done; Cells from notebooks/C4_TenderYar_v0_4.ipynb, numbers = RESULTS v0.4) | C04.md |
| CP137 | cover_A, gloss_A, fcards_A, cheat_A, ex_A | coverage matrix (all inventory rows), glossary, flashcards, cheat sheet, exercises | — |
| CP138+ | build extras | bridges, CSS (.prs/.pdone/.bridge), QA (ids/links/hex/JS/screenshots), docs, FINAL | — |
