# C2 guide v1 — gap list vs C1 v13 skeleton (CP73)
Present already: hero (4 stats: 37 lessons, 54 Q, 26 diagrams, 76 cards), #start, w1–w3, Appendix A #cmp (incl. IBM→Colab mapping, watsonx params, legacy API, troubleshooting), #kit (K.* + kit-proj mini-projects), #cover, #exam, #gloss, #fcards, #cheat, #ex.
Missing (to add in html/build_c2_v1.py, parts in html/parts_c2/):
1. Appendix C section#proj "TenderYar v0.2 — Ask the package": proj-why, proj-setup, proj-s1..s6, proj-done (9 lesson cards, ≥1 SVG each, Colab cells from notebooks/build_nb_c2.py, ✅ numbers from docs/results_c2_*.json).
2. Sidebar group "Appendix C · 🏗 Project: TenderYar v0.2" before #cover.
3. Week-end TenderYar bridge boxes (after w1 → s1; after w2 → s2/s3/s4; after w3 → s5/s6/done).
4. Hero study-plan line for Appendix C; hero stats recount (lessons 37→46, diagrams).
5. CSS .prs/.rtl/.pdone/.bridge + done-when checklist JS (key c2m_pd).
6. Coverage matrix row P-1 → proj-*; cmp: one IBM→Colab row for the project (PyMuPDF instead of PyPDFLoader for Persian PDFs).
7. QA: ids unique, all #links resolve, no new hex colours, v13-theme last head style.

## Status (CP83, C2 run6)
All 7 gaps closed in html/build_c2_v1.py → html/RAG_C2_Guide_v1.html: 1 (CP74–79), 2 (CP79), 3 (CP81), 4 + 6 (CP82: 46 lessons, 35 diagrams, hero project box, P-1 row → 165/165, PyPDFLoader→PyMuPDF row), 5 (CP80), 7 (CP83 QA: 0 dup ids, all #links resolve, 0 new hex colours, v13-theme last head style, tags balanced, 0 JS errors, light+dark screenshots OK, 22 tests pass).
