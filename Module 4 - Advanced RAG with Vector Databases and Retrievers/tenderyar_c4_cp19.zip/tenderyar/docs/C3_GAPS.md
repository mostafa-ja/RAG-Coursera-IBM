# C3 guide v1 — gap list vs C1 v13 skeleton (CP86 input → CP98 QA)
Input html/RAG_C3_Guide_input.html had: hero (16 lessons, 27 Q, 19 diagrams, 74 cards), #start, w1, w2, Appendix A #cmp (incl. IBM→Colab mapping + troubleshooting), #cover (196/196), #exam, #gloss, #fcards, #cheat, #ex.

| # | Gap | Status |
|---|-----|--------|
| 1 | v13 theme (last head style) + title "(v1)" + storage prefix c3_ → c3m_ | ✅ CP94 |
| 2 | Appendix C section#proj "TenderYar v0.3 — Tender library + company matching" (8 cards, Cells 1–13) | ✅ CP90–CP94 |
| 3 | Sidebar group "Appendix C · 🏗 Project: TenderYar v0.3" before #cover | ✅ CP94 |
| 4 | CSS .prs/.rtl/.pdone/.bridge + done-when JS (key c3m_pd) | ✅ CP95 |
| 5 | Week-end bridges (w1 → C.0–C.4, w2 → C.5–C.7) | ✅ CP96 |
| 6 | Hero stats recount (24 lessons, 27 diagrams) + hero project box; coverage P-1 (197/197); cmp row "Embedding model choice (project)" | ✅ CP97 |
| 7 | QA: unique ids, #links resolve, 0 new hex colours, v13-theme last, tags balanced, 0 JS errors, light/dark/mobile screenshots | ✅ CP98 |
| 8 | Appendix B toolkit section#kit (K.1 kit-skills, P1–P8 kit-p1..p8, K.2 kit-debug, K.3 kit-proj) after #w2 before #cmp + sidebar group "Appendix B · 🛠 Builder's toolkit"; hero 35 lessons / 38 diagrams; coverage K-1 (198/198) | ✅ CP99–CP106 |

Notes (CP98): mobile (420 px) — 0 project SVGs overflow; the floating ☀/🌙 + Print buttons overlap body text at the bottom edge — inherited from the v13 shell (same in C1 v13 / C2 v1), not changed here.

QA (CP106, after Appendix B): 0 dup ids, all #links resolve (only JS templates), 0 new hex vs input+theme, v13-theme last head style, tags balanced (section 13, article 39, svg 39, table 48, div 1031, details 89, script 7), no unrenamed c3_ storage key; c3m_sk9 skills tracker: 3 ticks → "1/10 understood · 2/10 build", persists after reload; #dbgq 'dimension' → 1 of 35 rows; 0 JS errors; screenshots: K.1/P3/P7 light, P5/K.2/K.3 dark, P2/P6 mobile 420 px dark (0 kit SVG overflow). Mobile page overflow 13 px comes from the inherited breadcrumb + #start-map table (input 9 px, C2 v1 61 px) — not from Appendix B. 29 passed.
All 8 gaps closed.
