# TenderYar audit (runs 7–8) — is everything consistent and does it work?

**Result:** v0.1 works end to end offline; all 17 findings below are fixed. `pytest -q` → **12 passed**
(9 pure-Python core + 3 that run the real LCEL chain with a fake chat model). Only thing left that needs *you*:
run the notebook with your Gemini key and fill the model rows in `docs/RESULTS.md`.

## 1. What was checked
| Area | How | Status |
|---|---|---|
| Package code (`tenderyar/`) | read every module, unit tests, offline run on 10 + 50 notices | ✅ |
| LLM chain | `tests/test_chain_offline.py`: few-shot + zero-shot templates format, parser + Pydantic accept output, fallback model takes over on a simulated 429, `chain.batch` survives errors | ✅ |
| Flask / Gradio | Flask test client: `/health`, offline `/extract`, unknown model → 400; Gradio smoke-tested in run 4 (offline mode) | ✅ |
| Data + labels | 10 hand-made notices (`data/notices`, `gold.jsonl`), 50 generated (`data/synth`, exact labels); Jalali ↔ Gregorian round-trip on 20 000 days | ✅ |
| Notebook | 20 code cells parse (`ast`), numbers match RESULTS + HTML, rebuilt from `build_nb.py` | ✅ |
| HTML guide v13 | rebuilt from v11 + parts; diff vs previous build = only the intended text changes; 0 JS errors; light + dark screenshots | ✅ |
| Plan + specs C02–C10 | every file/path a later course needs is produced by an earlier course (table §3) | ✅ |

## 2. Findings and fixes
| # | Finding | Fix |
|---|---|---|
| 1 | Rules baseline took the *old* deadline in an "extended" (تمدید) notice (N05) → deadline acc. 0.90 | use the last date in the deadline sentence → **1.00** |
| 2 | Few-shot examples had Persian digits, but input is normalised to Latin digits (style mismatch) | examples normalised the same way |
| 3 | `schema.SCORED_FIELDS` listed `subject`, the evaluator did not score it | one list, defined in `evaluate.py` |
| 4 | `extract_batch` said "chain.batch" but looped one by one | real `chain.batch(..., return_exceptions=True)` + per-item regex fallback |
| 5 | `ۀ` → `هٔ` → diacritic removal → `ه` (accidental) | explicit `ۀ` → `ه` |
| 6 | Notebook/HTML said "5 passed" | now "12 passed" everywhere |
| 7 | Model names | match your notebooks: `gemini-3.8-flash` (main), `gemini-3.5-flash-lite`, `gemini-2.5-flash` (fallback) |
| 8 | Data is synthetic | labelled as synthetic everywhere; plan says add real public notices as `N11+` |
| 9 | Unquoted zip name in the notebook unzip cell | quoted |
| 10 | C03 called `make_samples.py --n 50`, which had no `--n` | new `data/make_synthetic.py --n --seed` → `data/synth/` |
| 11 | Dependency chain C1→C10 | checked, see §3 |
| 12 | MASTER_PLAN said 8 steps for C1 (Flask = step 7, Gradio = step 8); guide + notebook have 6 | plan table rewritten to the real 6 steps + Guard |
| 13 | C10 "10 attacks from the C1 log" without a file name | `guard_log.csv` named in plan + C10 spec |
| 14 | C07 needs ≥ 5 packages and C04 needs gold pages, but `make_packages.py` (C2) had no options | C02 spec: `--n --seed` + `data/packages/facts.jsonl` (true bond / deadline / penalty + page) |
| 15 | C06 chart agent read `cards.jsonl` (the C1 file has only 10 cards) | `data/cards.jsonl` (50+ cards cached in C3) |
| 16 | Repo layout missed `agents/`, `clients/`, `data/synth`, `profiles/`, `html/`, `kit/` | layout updated |
| 17 | Plan vs spec drift (C5 OCR engines, C6 tool count, C9 tool list) | plan aligned with specs |
| + | Flask accepted any model name from the client | allow-list of the 3 course models |

## 3. Hand-offs between courses (what each course needs, and who makes it)
| Needed in | Thing | Made in |
|---|---|---|
| C2 | `normalize.py`, `TenderCard`, Jalali/money utils | C1 ✅ |
| C3 | 50+ notices with labels | C1 audit: `data/make_synthetic.py --n 50` ✅ |
| C3, C6 | `data/cards.jsonl` (cached extraction, never re-pay the LLM) | C3 step 0 |
| C4, C7 | packages + gold pages | C2 `make_packages.py --n` + `facts.jsonl` |
| C4 | Chroma library + metadata | C3 |
| C5 | TenderQA v0 to re-run after OCR | C4 |
| C6 | library search, Jalali/money code to wrap as tools | C1 + C3 |
| C7 | company profiles, ≥ 5 packages | C3 `data/profiles/`, C2 `--n 5` |
| C8 | v0.7 graph to plug the crew into | C7 |
| C9 | library, retrievers, tools, graph, crew | C3–C8 |
| C10 | `guard_log.csv`, TenderQA v0, every RESULTS row | C1, C4, all |

## 4. Baseline numbers (offline, no LLM — reproducible)
| Data | Overall | Deadline | Bond | Number | Province | Org / category / grade |
|---|---|---|---|---|---|---|
| 10 notices (`data/notices`) | **0.63** | 1.00 | 1.00 | 1.00 | 0.50 | 0.00 / 0.00 / 0.20 |
| 50 synthetic (`data/synth`) | **0.66** | 1.00 | 1.00 | 1.00 | 0.72 | 0.00 / 0.00 / 0.24 |

Regex is perfect on patterned fields and fails on "meaning" fields — exactly the gap the LLM must close (target ≥ 0.85).

## 5. Known limits (honest list for your README)
* All data so far is **synthetic**; before publishing claims, add ≥ 10 real public notices (`N11+`) and report both.
* `deadline_iso` is derived from `deadline_jalali`, so it is not an independent score (kept for readability).
* Model names follow your course notebooks; if Google renames a model, change `DEFAULT_MODEL` / `FALLBACK_MODEL` and `ALLOWED_MODELS` only.
* Bond percentages and legal rules are **parameters**, not legal advice (C6 spec says so).
* The guide's theme is *inspired by* claude.ai colours and serif typography; it is not an official Anthropic asset.

## 6. Re-check it yourself (2 minutes in Colab)
```
!pip -q install -r requirements.txt
!python -m pytest -q tests                        # 12 passed
!python data/make_synthetic.py --n 50 --seed 7    # same 50 notices every time
!TENDERYAR_OFFLINE=1 python -m tenderyar.apps.flask_api &   # then POST /extract
```
