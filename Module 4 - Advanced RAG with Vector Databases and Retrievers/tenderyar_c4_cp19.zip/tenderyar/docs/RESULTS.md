# TenderYar — results log (fill after every course)

## v0.1 · Course 1 — tender card extraction (10 notices, data/gold.jsonl)
| Model | Prompt | Valid JSON | Overall acc. | Deadline acc. | Bond acc. | Avg s / notice |
|---|---|---|---|---|---|---|
| rules only (no LLM) | — | 10/10 | 0.63 | 1.00 | 1.00 | <0.01 |
| gemini-3.8-flash | few-shot | | | | | |
| gemini-3.5-flash-lite | few-shot | | | | | |
| gemini-2.5-flash | few-shot | | | | | |
| gemini-3.8-flash | zero-shot | | | | | |

Injection test (N10) — bond / deadline unchanged? ☐ yes ☐ no
Guard the Secret — leaks out of 10 attacks: __

Stretch (optional): run the best model on `data/synth/` (50 notices from `python data/make_synthetic.py --n 50`) — overall acc. __ · rules only: 0.66 (deadline 1.00, bond 1.00).

## v0.2 · Course 2 — ask the package (15 questions on P01 + P02, `data/qa_c2.jsonl`: 12 answerable + 3 out of scope)
| chunker | k | answer acc (15) | citation acc | refusals ok (3) | avg s/question |
|---|---|---|---|---|---|
| offline baseline · fixed200 (no key) | 1 | 12/15 | 0.83 | 3/3 | <0.01 |
| offline baseline · fixed200 (no key) | 3 / 5 / 8 | 14/15 | 1.00 | 3/3 | <0.01 |
| offline baseline · madde800 (no key) | 1 | 13/15 | 0.83 | 3/3 | <0.01 |
| offline baseline · madde800 (no key) | 3 / 5 / 8 | **15/15** | **1.00** | 3/3 | <0.01 |
| gemini-3.8-flash · fixed200 | 5 | | | | |
| gemini-3.8-flash · madde800 (default) | 5 | | | | |
| gemini-3.5-flash-lite · madde800 | 5 | | | | |

Offline = `HashEmbeddings` (character 3-grams) + `offline_llm` (copies the best-overlapping context line and cites its page) — `python scripts/eval_c2_offline.py`, saved in `docs/results_c2_offline.json`. It is a *plumbing* check on short synthetic pages, not a quality claim: fill the Gemini rows from notebook Cell 14.

Loader check (P01, `scripts/c2_numbers.py` → `docs/results_c2_numbers.json`): rtl_order_score page 2 — pypdf **0.833** (bond amount reversed `۰۰۰٬۰۰۰٬۰۵۵٬۵`), PyMuPDF raw **0.167**, PyMuPDF + `fix_reversed_lines` **1.000** (all 12 pages 1.000).
Splitter check (P01, 12 pages): words cut in half — fixed150 **7**, fixed200 **5**, recursive200 **0**, «ماده»-aware 200 **0** (only this one starts a chunk with «ماده ۵»).
Retrieval rank of the bond page (offline index): Persian query **1**, Arabic-letter query **1**, English query **5** → with Gemini: __ / __ / __.

## v0.3 · C3 — tender library + company matching
Library: 60 tenders (N01–N10 + S001–S050) → 60 chunks in Chroma `tenders` (`hnsw:space=cosine`), persistent. Fixed evaluation "today" = 1405/08/20. `python scripts/eval_c3_offline.py` → `docs/results_c3_offline.json`.

| embedding model | recall@1 | recall@5 | ms/emb |
|---|---|---|---|
| offline HashEmbeddings (normalised) | 0.60 | 1.00 | <1 |
| offline HashEmbeddings (raw text) | 0.50 | 0.85 | <1 |
| models/gemini-embedding-2 (notebook Cell 4) | | | |
| PartAI/Tooka-SBERT (Cell 4) | | | |
| BAAI/bge-m3 (Cell 4) | | | |

Default model decision (fill after Cell 4): pick the best recall@5; tie → the faster / free one. Offline: normalising text first (ي→ی, digits) lifts recall@1 0.50 → 0.60.

| matching variant | precision@5 (avg 3 profiles) | zagros | kavir | shomal |
|---|---|---|---|---|
| semantic only (offline) | 0.200 | 0.2 | 0.4 | 0.0 |
| hard filter + semantic (offline) | 0.800 | 0.6 | 1.0 | 0.8 |
| full score 0.6/0.2/0.2 (offline) | **0.933** | 1.0 | 1.0 | 0.8 |
| full score · gemini-embedding-2 (Cell 11) | | | | |

`match_gold.jsonl` is rule-labelled (relevant = passes the company's hard rules and ≥ 7 days left), so it rewards rules by design; shomal has only 4 relevant tenders → its max is 0.8. Hand-check ~10 per profile in Colab before trusting the numbers.
Filter demo («روکش آسفالت محور», Isfahan + راه و ساختمان + after 1405/08/15 + bond ≤ 5 bn): semantic only top-5 = S014, S028, S050, S021, S024 (4 provinces) → filtered = S024, S015 (only 2 pass all 4 rules).
CRUD demo: 60 chunks → delete S002 → 59.

## v0.4 · C4 — better search + TenderQA v0
TenderQA v0 = `data/tenderqa/v0.jsonl`: 60 rows (P01 30 hand-written, P02 30 candidates checked one by one; 54 answerable + 6 negative; types fact 19 · clause 16 · numeric 8 · list 6 · date 5 · negative 6). Candidate fixes in the sandbox run: **0** (`FIXES` in `data/tenderqa/make_v0.py`; add yours after the Gemini candidate cell). `python scripts/eval_c4_offline.py` → `docs/results_c4_offline.json` + `docs/img/v0_4_recall.png`. Metrics are page-level on the 54 answerable questions, retrieval inside the question's package (12 pages), k = 5. Offline stand-ins: HashEmbeddings (dense), offline synonym paraphraser (multi-query), OverlapReranker (re-rank), extractive answer + offline judge.

| config | recall@1 | recall@5 | MRR | nDCG@5 | judge score (0–2) | ms/query |
|---|---|---|---|---|---|---|
| 1 dense (v0.3 baseline) (offline) | 0.796 | 0.963 | 0.870 | 0.893 | 1.24 | 1.0 |
| dense + MMR (offline) | 0.796 | 0.981 | 0.883 | 0.880 | 1.28 | 1.8 |
| 2 BM25 (clean tokens) (offline) | 0.907 | 0.963 | 0.932 | 0.940 | 1.30 | 0.1 |
| hybrid 0.3/0.7 (offline) | 0.815 | 1.000 | 0.892 | 0.918 | 1.24 | 1.2 |
| 3 hybrid 0.5/0.5 (offline) | **0.907** | **1.000** | **0.946** | **0.960** | 1.28 | 1.1 |
| hybrid 0.7/0.3 (offline) | 0.889 | 1.000 | 0.932 | 0.949 | 1.28 | 1.2 |
| 4 hybrid + multi-query (offline) | 0.907 | 0.981 | 0.938 | 0.949 | 1.28 | 2.2 |
| 5 hybrid + MQ + re-rank (offline) | 0.889 | 0.981 | 0.927 | 0.941 | 1.26 | 10.6 |
| parent (BM25 children → article) (offline) | 0.889 | 0.963 | 0.926 | 0.936 | 1.26 | 0.1 |
| BM25 raw tokens (clean-up OFF) (offline) | 0.778 | 0.963 | 0.857 | 0.884 | 1.20 | 0.0 |
| 6 = 3 with clean-up OFF (offline) | 0.833 | 0.963 | 0.882 | 0.902 | 1.24 | 1.4 |
| dense · gemini-embedding-2 (notebook Cell 5) | | | | | | |
| hybrid 0.5/0.5 · Gemini (Cell 9) | | | | | | |
| hybrid + MQ (Gemini paraphrases, Cell 11) | | | | | | |
| hybrid + MQ + bge-reranker-v2-m3 (Cell 16) | | | | | | |

**Headline (offline): recall@5 0.963 → 1.000, recall@1 0.796 → 0.907, MRR 0.870 → 0.946** (dense baseline → hybrid BM25+dense 0.5/0.5). Default set in `tenderyar/config.py`: hybrid 0.5/0.5, k 5, multi-query and re-rank OFF.
Clean-up matters: BM25 with raw whitespace tokens recall@1 **0.778** vs clean tokens **0.907**; the hybrid with clean-up OFF drops to MRR **0.882**. CP115 fix: «؟ ، ؛» were glued to words («است؟») → tokens are letters only now (hybrid MRR 0.937 → 0.946, recall@5 0.981 → 1.000).
The offline paraphraser and offline re-ranker do NOT help (MRR 0.938 / 0.927 < 0.946): they are crude stand-ins. Fill the Gemini + bge rows in Colab and switch `multi_query`/`rerank` on in `config.py` only if they win.
Baseline by type (dense, recall@5 / MRR): clause 1.00/1.00, date 0.80/0.60, fact 1.00/0.85, list 0.83/0.64, numeric 1.00/1.00. 10 worst baseline questions + reason → `worst10_baseline` in the JSON (numbers, paraphrases, shared boilerplate pages).
Self-query (library of 60 tenders, today = 1405/08/20): 6/6 phrasings → correct filter (spec phrase, بعد از، تا، همین هفته، ماه آینده، ۱۴۰۵/۰۸/۱۵). «قبل از ۱۵ آبان ۱۴۰۵» → `deadline_ts $lt 1793923200` (+ اصفهان + راه و ساختمان) → 0 tenders (Isfahan road tenders S024/S015 close later — correct, strict filter).

## v0.5 · C5 (CER)  |  …
