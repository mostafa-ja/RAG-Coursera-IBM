# TenderYar — open-source projects to learn from / reuse

| Project | Link | Use in TenderYar | Course |
|---|---|---|---|
| TenderLens (Arabic RTL tender agent) | https://github.com/syedzish/tenderlens-agentic-ai | Closest idea (bidder-side bid/no-bid with RAG + MCP). Study its decision flow and evidence citations; TenderYar does the Persian version | C6–C9 |
| GitHub topic: tender-intelligence | https://github.com/topics/tender-intelligence | Tender scraping + matching to company profiles | C3 |
| GitHub topic: tender-evaluation | https://github.com/topics/tender-evaluation | Comparing bidder docs vs tender criteria | C7–C8 |
| Construction RAG Doc Copilot | https://github.com/CarloCogni/construction-rag-doc-copilot | Upload PDFs → extract key info with RAG | C2 |
| persiantools | https://github.com/majiidd/persiantools | Jalali dates, Persian/Arabic digits, char fixes (cross-check for our own jalali.py) | C1, C6 |
| hazm | https://github.com/roshan-research/hazm | Persian normalizer, tokenizer, sentence splitter | C2, C4 |
| ParsiNorm | https://arxiv.org/abs/2111.03470 | Persian normalisation incl. numbers/dates | C4 |
| num2fawords | https://pypi.org/project/num2fawords/ | number → Persian words (we build the reverse: words → number) | C1, C6 |
| ParsBERT / PEYMA NER | https://github.com/hooshvare/parsbert | Persian NER (money, date, org) baseline | C4 |
| Tooka-SBERT | https://huggingface.co/PartAI/Tooka-SBERT | Persian sentence embeddings (compare vs Gemini embeddings) | C3, C4 |
| BAAI bge-m3 | https://huggingface.co/BAAI/bge-m3 | Multilingual dense+sparse embeddings, hybrid search | C3, C4 |
| FaMTEB / PTEB | https://arxiv.org/abs/2502.11571 | How Persian retrieval is benchmarked → design TenderQA | C4, C10 |
| Docling | https://github.com/docling-project/docling | PDF layout, reading order, tables | C2, C5 |
| Surya OCR | https://github.com/datalab-to/surya | OCR + layout + reading order (90+ languages incl. Persian) | C5 |
| RAG-Anything | https://github.com/hkuds/rag-anything | Multimodal RAG (tables, images) ideas | C5 |
| LLM Guard | https://github.com/protectai/llm-guard | Prompt-injection scanner for uploaded documents | C10 |
