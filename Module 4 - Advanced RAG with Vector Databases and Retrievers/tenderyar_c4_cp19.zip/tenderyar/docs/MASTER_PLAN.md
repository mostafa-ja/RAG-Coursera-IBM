# مناقصه‌یار · TenderYar — master plan (10 courses → 1 product)

> **One sentence:** TenderYar reads Persian tender notices and full tender packages (often scanned, RTL, Jalali dates, Rial amounts) and tells a company *can we bid, what do we need, by when, and what are the risks* — with page references.

## 0. Rules that keep the project healthy
1. **One repo, one version per course.** Tag `v0.1` … `v1.0`. Each course adds a folder of code plus a demo and a metric; nothing is thrown away.
2. **Same data all the way.** `data/notices/` (short notices) grows into `data/packages/` (full PDFs) and `data/tenderqa/` (test set). Every new feature is measured on it.
3. **Every unit ends with a visible result**: a screenshot or GIF, a filled table, a JSON file, and a ✅ "Done when" checklist in that unit's HTML guide.
4. **Free stack first.** Colab + Gemini free tier (`gemini-3.8-flash`, `gemini-3.5-flash-lite`, `gemini-2.5-flash`, `models/gemini-embedding-2`). Open models (Tooka-SBERT, bge-m3) as alternatives.
5. **Persian-specific hard parts are the selling point**: ي/ی ك/ک, half-space (ZWNJ), Persian/Arabic digits, Jalali dates, Rial vs Toman, amounts in words, RTL tables, scans.
6. **Data ethics.** Only public notices. Keep company profiles fake. Never commit API keys.

## 1. Architecture growth

```
v0.1 C1  notice text ──► normalise ──► prompt template + few-shot ──► Gemini ──► Pydantic TenderCard ──► post-check (Jalali, Rial) ──► Gradio / Flask
v0.2 C2  PDF ──► loader + splitter ──► embeddings ──► retriever ──► answer with [page n]
v0.3 C3  many tenders ──► Chroma library + metadata (province, category, deadline) ──► company-profile matching
v0.4 C4  Persian clean-up + hybrid (BM25 + dense) + multi-query + date-aware self-query ──► TenderQA v0 metrics (recall@5, MRR)
v0.5 C5  scans / stamped tables ──► Gemini vision ──► pandas price lists; Persian voice questions
v0.6 C6  ≥8 tools: Jalali calendar, working days, Rial/Toman, number words, bond, library search; ReAct + chart agent
v0.7 C7  LangGraph bid/no-bid graph with routing, state, human approval
v0.8 C8  multi-agent review crew (legal, technical, finance) + writer (checklist + cover letter)
v0.9 C9  MCP server: search_tenders, get_card, analyze_tender, get_checklist, … (Claude Desktop / Cursor)
v1.0 C10 security (prompt-injection in uploads), TenderQA on Hugging Face, HF Spaces demo, bilingual README, 2-min video
```

## 2. Repo layout (final)
```
tenderyar/
  tenderyar/            # python package
    normalize.py        # C1  Persian text clean-up
    jalali.py           # C1  Jalali <-> Gregorian (no deps)
    money.py            # C1  Rial/Toman + Persian number words -> int
    schema.py           # C1  Pydantic TenderCard
    prompts.py          # C1  zero/few-shot templates
    extractor.py        # C1  LCEL chain + post-validation + fallback
    evaluate.py         # C1  field accuracy + model comparison
    apps/               # C1 gradio_app.py, flask_api.py · C2 gradio_rag.py · later tabs
    rag/                # C2 loaders/splitter/index/qa/eval_qa · C3 library/matching · C4 retrievers/eval
    vision/             # C5 page_kind, OCR, tables, speech
    tools/              # C6 calendar, money, library (@tool)
    agents/             # C6 bid_agent, chart_agent
    graph/              # C7 LangGraph bid/no-bid
    crew/               # C8 reviewers + writer
    mcp_server/         # C9 server, limits, auth, logging
    guard/              # C10 prompt-injection scanner
  clients/              # C9 Claude Desktop config, LangGraph MCP client
  data/
    notices/ + gold.jsonl          # C1 10 notices (synthetic, realistic) + labels
    synth/                         # C1 audit: make_synthetic.py --n 50 (exact labels, used from C3)
    packages/ + facts.jsonl        # C2 tender PDFs (real public or make_packages.py --n) + gold pages
    qa_c2.jsonl · profiles/ · match_gold.jsonl · tenderqa/ · scans/ · tables/ · voice/ · redteam/
  notebooks/C1_TenderYar_v0_1.ipynb … C10_TenderYar_v1_0.ipynb
  tests/                # pytest, must stay green every version
  docs/                 # this plan, REFERENCES, RESULTS, AUDIT
  html/  kit/           # course guides (v13 theme), build scripts, prompts, specs
```

## 3. Course-by-course plan

Each course row: **what you add → module split → visible result → done when → metric for the resume**.
Module names follow the certificate outline; rename to your actual module titles when you reach the course.

### C1 · Develop Generative AI Applications: Get Started → **v0.1 Tender card** (this unit)
| Module | TenderYar step | You see |
|---|---|---|
| M1 Prompt engineering & templates | **Step 1** normaliser + Jalali + money utils (pure Python, tested, no LLM). **Step 2** zero-shot vs few-shot `ChatPromptTemplate` for notice extraction. **Step 3** chain-of-thought for the bond amount; self-consistency vote for the deadline | Rules baseline (overall 0.63) · zero vs few-shot table |
| M2 LangChain core | **Step 4** `TenderCard` Pydantic schema + `JsonOutputParser`; LCEL chain `prompt \| llm.with_fallbacks([backup]) \| parser` + `postprocess()`; `chain.batch` over 10 notices | `cards.jsonl` with 10 valid cards |
| M3 Build a GenAI app | **Step 5** field accuracy vs `gold.jsonl` for the 3 Gemini models (accuracy, latency). **Step 6** Flask `POST /extract` + Gradio RTL UI. **Side quest** *Guard the Secret* (→ `guard_log.csv`) | Model comparison table, Gradio screenshot, curl response |
**Done when:** 10 notices → 10 valid JSON cards; deadline converted correctly (Jalali → ISO); bond amount in Rial as an integer; field accuracy ≥ 85 % for the best model; Flask and Gradio both work; comparison table filled.
**Resume metric:** "field-level accuracy X % on 10 notices; best model Y at Z s/notice".
**Side quest (fun):** *Guard the Secret* — a system prompt hides a word; try 10 injection attacks; keep the log `guard_log.csv` (re-used in C10 red team).

### C2 · Build RAG Applications: Get Started → **v0.2 Ask the package**
| Module | Step | You see |
|---|---|---|
| M1 RAG intro & document loading | `PyPDFLoader`/`PyMuPDF` load a tender PDF with page numbers in metadata; normalise every page with `normalize.py`; detect broken RTL order | Page-by-page text preview |
| M2 Splitting, embeddings, vector store, retriever | Persian-aware splitter (sentence end `.` `؟` `!` `؛`, headings like «ماده»/«بند»); Gemini embeddings; in-memory Chroma; `as_retriever(k=5)` | Top-5 chunks for «مبلغ تضمین شرکت در مناقصه چقدر است؟» |
| M3 QA bot with Gradio | RetrievalQA (LCEL) answering in Persian with `[ص ۱۲]` citations; "I don't know" when not found; Gradio upload + chat | Gradio app: upload PDF → answers with page refs |
**Done when:** 15 hand-written questions on 2 packages; ≥ 12 answered correctly with a correct page; refuses to answer 3 out-of-scope questions.
**Metric:** answer accuracy and citation accuracy on 15 questions.

### C3 · Vector Databases for RAG → **v0.3 Tender library + matching**
| Module | Step | You see |
|---|---|---|
| M1 Vector DB concepts, similarity | Compare cosine / dot / L2 on Persian chunks; Gemini vs Tooka-SBERT vs bge-m3 embeddings on 20 query–passage pairs | Small embedding leaderboard |
| M2 Chroma in depth | Persistent Chroma collection `tenders` with metadata: province, category, org, deadline_ts, bond_rial, grade; CRUD + `where` filters | Query: "Isfahan road works" filtered by province |
| M3 Recommender / matching | Company profile (fields, grade, provinces, max bond) → ranked tender list with reasons | "Top 5 tenders for company X" table |
**Done when:** 50+ notices indexed with metadata; metadata filters work; matching returns sensible top-5 for 3 fake company profiles.
**Metric:** precision@5 of matching on labelled profile–tender pairs.

### C4 · Advanced RAG with Vector Databases and Retrievers → **v0.4 Better search + TenderQA v0**
| Module | Step | You see |
|---|---|---|
| M1 Retriever types | Hybrid BM25 (on normalised Persian tokens, hazm) + dense via `EnsembleRetriever`; MMR | recall table: BM25 vs dense vs hybrid |
| M2 Advanced retrievers | Multi-query (Persian paraphrases), parent-document retriever (clause → full article), self-query with Jalali-aware date filter ("before 15 Aban") | Date filter demo |
| M3 Evaluation | TenderQA v0: 60 Q–A–page triples; recall@5, MRR, answer correctness (LLM-as-judge with rubric) | Before/after chart: recall@5 X → Y |
**Done when:** TenderQA v0 file exists; hybrid + clean-up beats dense-only on recall@5.
**Metric:** the resume line "raised recall@5 from X to Y".

### C5 · Build Multimodal Generative AI Applications → **v0.5 Scans, tables, voice**
| Module | Step | You see |
|---|---|---|
| M1 Vision | Gemini reads scanned pages + stamps; compare with Tesseract (`fas`) and optionally Surya | OCR CER table on 5 scanned pages |
| M2 Tables | Price-list / bill-of-quantities (فهرست بها) tables → pandas DataFrame with Persian headers, totals checked | Correct DataFrame + sum check |
| M3 Speech | Persian voice question → text → RAG → answer (and optional TTS) | Voice demo in Gradio |
**Done when:** 5 scanned pages extracted with acceptable CER; 3 tables reconstructed with matching totals; voice question works.

### C6 · Fundamentals of Building AI Agents → **v0.6 Tools + chart agent**
| Module | Step | You see |
|---|---|---|
| M1 Tool calling | ≥ 8 `@tool`s: jalali_to_gregorian, gregorian_to_jalali, days_until_deadline, add_working_days, words_to_number, rial_to_toman, toman_to_rial, bond_amount, search_library, get_card | Agent trace calling 2 tools |
| M2 Agent loop | ReAct agent that answers "Can we still submit, and how much bond?" | Step-by-step trace |
| M3 Data/chart agent | pandas agent over the library → charts: tenders per province / month, avg bond | Two charts |
**Done when:** 10 tool questions answered correctly; tool unit tests pass; charts generated.

### C7 · Agentic AI with LangChain and LangGraph → **v0.7 Bid/no-bid workflow**
| Module | Step | You see |
|---|---|---|
| M1 Graph basics | `StateGraph` with nodes: extract → check_eligibility → check_deadline → assess_risk | Mermaid graph image |
| M2 Routing & loops | Conditional edges (not eligible → stop early), retry/reflection on low-confidence fields | Two traces (eligible / not) |
| M3 Human in the loop | `interrupt` before final decision; checkpointer memory; resume | Approval step in Gradio |
**Done when:** 5 packages run end-to-end, each producing a bid/no-bid memo; human approval works.

### C8 · Agentic AI with LangGraph, CrewAI, AutoGen (AG2) and BeeAI → **v0.8 Review crew**
| Module | Step | You see |
|---|---|---|
| M1 CrewAI | Crew: legal reviewer (penalties, guarantees), technical reviewer (scope vs company), finance reviewer (bond, cash flow) | Three review reports |
| M2 AG2 / BeeAI | Same reviewers as an AG2 group chat or BeeAI workflow; compare cost/latency/quality | Framework comparison table |
| M3 Writer & orchestration | Writer agent drafts document checklist + Persian cover letter (نامه) | Final DOCX/Markdown |
**Done when:** One package → checklist + cover letter + risk table; frameworks compared on 3 packages.

### C9 · Build AI Agents using MCP → **v0.9 TenderYar MCP server**
| Module | Step | You see |
|---|---|---|
| M1 MCP concepts | FastMCP server: 6 tools (`search_tenders`, `get_card`, `analyze_tender`, `get_checklist`, `days_until_deadline`, `bond_amount`), resources `tender://{id}/card`, `tender://{id}/memo`, `library://stats`, 2 prompts | MCP Inspector screenshot |
| M2 Clients | Use from Claude Desktop / Cursor / a LangGraph MCP client | Chat screenshot calling tools |
| M3 Production | Auth, input limits, logging, Docker | `docker run` works |
**Done when:** An external client finds and analyses a tender through MCP.

### C10 · Capstone → **v1.0 Public release**
| Part | Step |
|---|---|
| Security | Prompt-injection scanner for uploaded documents (rules + LLM Guard), re-using the *Guard the Secret* attack log; red-team set of 30 attacks |
| Dataset | Publish **Persian TenderQA** on Hugging Face (dataset card, licence, splits) |
| Demo | Hugging Face Spaces (Gradio) with sample packages |
| Docs | README in English + Persian, architecture diagram, results tables |
| Show | 2-minute video, LinkedIn post, resume line |
**Done when:** public demo link, dataset link, repo with CI tests, video.

## 4. Resume line you earn
"Built **TenderYar**, an open-source Persian tender assistant (RAG, LangGraph agents, MCP) that turns 100-page tender packages into a checklist with page references; created the **Persian TenderQA** test set; hybrid search raised recall@5 from **X** to **Y**; structured extraction reached **Z %** field accuracy."

## 5. Weekly rhythm (each unit)
1. Study the unit (HTML guide + notebook). 2. Open that unit's TenderYar section. 3. Run the project notebook step by step. 4. Fill the results table. 5. Tick ✅ Done when. 6. Commit + tag. 7. Paste the results into `docs/RESULTS.md`.
