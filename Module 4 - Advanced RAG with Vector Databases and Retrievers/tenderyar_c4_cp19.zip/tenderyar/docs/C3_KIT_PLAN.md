# C3 guide v1 — Appendix B toolkit plan (gap 8, CP99)

Goal: add `section.week#kit` "🛠 Practical vector-DB skills for your next projects" to html/RAG_C3_Guide_v1.html,
same card shape as C2 v1 (kit-skills · kit-p* · kit-debug · kit-proj), v13 theme classes only (0 new hex).

## Where
- Insert **after `</section>` of #w2, before `<section ... id="cmp">`** (same order as C2: weeks → kit → cmp → proj).
- Sidebar: group `Appendix B · 🛠 Builder's toolkit` (gh → #kit, subs = 11 cards) before `<a ... href="#cmp">`.
- Bridge note: bridges_c3 key "cmp" is inserted *before #cmp*; after kit insertion that would land after the kit.
  → build step order: insert bridges (2b) first, kit after (2c) anchored on the bridge's end, or re-key bridge to "kit". Decide in CP105; check box sits at end of w2.
- Already present in C3 shell (v9 toolkit, no new CSS/JS needed): `.skt` skills table + `c3m_sk9` Know/Build tracker + `#skprog`; `#dbgq` / `#dbgt` debug-table search.

## Cards (11 = K.1 + P1–P8 + K.2 + K.3)
| id | Title | From (lessons / labs / code) |
|----|-------|------------------------------|
| kit-skills | K.1 · The 10 practical skills Course 3 really teaches (tracker, data-sk 1–10) | all; SVG ingest→index→query→use |
| kit-p1 | P1 · Starter: client (ephemeral / persistent on Drive) + embedding function (Gemini ef / SentenceTransformer / offline) | start-colab, w1-chroma, w1-lab2, proj-setup |
| kit-p2 | P2 · Similarity by hand: L2 / dot / cosine with NumPy, normalise, rank | w1-metrics, w1-lab1, proj-s1 |
| kit-p3 | P3 · Collections + CRUD: get_or_create, add vs upsert, get(include=), update, delete, count/peek, clone to change model/metric | w2-ops, library/store.py (update_meta bug CP91) |
| kit-p4 | P4 · Metadata design + `where` ($and/$or/$in/$gte/$lte) + `where_document` ($contains) — numbers as numbers, dates as timestamps | w1-filter, w2-emp, library/search.build_where |
| kit-p5 | P5 · Pick the space + HNSW knobs (cosine/l2/ip, ef_search, ef_construction, max_neighbors); distance → similarity | w1-hnsw, w2-ops |
| kit-p6 | P6 · Recommender pattern: filter by rule, rank by similarity, exclude self, explain why | w2-food, w2-emp book ex., library/match.py |
| kit-p7 | P7 · Vector DB as the RAG retriever: query → context with ids → Gemini prompt with citations + "not found" | w2-rag, w2-food enhanced_rag_chatbot |
| kit-p8 | P8 · Measure retrieval: recall@1 leaderboard, precision@k, before/after table | proj-s1 leaderboard, match.precision_at_k, eval_c3_offline |
| kit-debug | K.2 · Vector-DB debugging playbook: symptom → cause → fix (searchable #dbgt) | lab pitfalls, cmp-trouble, CP91/CP92 bugs, Arabic ي/ك finding (CP90) |
| kit-proj | K.3 · Mini-projects (4): grocery search, employee finder with filters, book recommender, food RAG chatbot — each with "done when" | course data only |

## Steps (one CP each, zip + Notion each)
- CP100 html/parts_c3_kit/A_skills_p1_p2.html (section#kit open + K.1 + P1 + P2)
- CP101 B_p3_p4.html · CP102 C_p5_p6.html · CP103 D_p7_p8.html
- CP104 E_debug_proj.html (K.2 + K.3, closes </section>)
- CP105 build_c3_v1.py step 2c (insert kit + sidebar group) + hero stats (lessons 24 → 35) + coverage row (Appendix B, 197 → 198)
- CP106 QA (ids/links/hex/theme last/tags/JS, tracker c3m_sk9 + dbg search, light/dark/mobile screenshots); C3_GAPS gap 8 closed.

Rules: every code snippet must run offline with the repo's HashEmbeddings stand-in or be marked "needs key"; outputs in "✅ You should see" must come from a real run.
