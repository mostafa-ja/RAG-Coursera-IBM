"""Project defaults (v0.4). Chosen from the C4 benchmark (docs/RESULTS.md · C4): hybrid BM25+dense, RRF, weights 0.5/0.5."""
LLM_MAIN, LLM_CHEAP, LLM_FALLBACK = "gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash"
EMBED_MODEL = "models/gemini-embedding-2"
RETRIEVER = {"type": "hybrid", "bm25_weight": 0.5, "dense_weight": 0.5, "k": 5, "fetch_k": 20, "rrf_c": 60,
             "multi_query": False, "rerank": False,      # switch on in Colab if your Gemini/bge rows beat the default
             "parent": "clause questions", "rerank_model": "BAAI/bge-reranker-v2-m3"}
