"""Persian text clean-up for tender notices (no external dependencies).

Fixes the classic problems of Persian text copied from PDFs/websites:
Arabic ي/ك, Persian/Arabic digits, broken half-spaces (ZWNJ), tatweel,
diacritics, odd spaces. Keep it deterministic so it can be unit-tested.
"""
import re
import unicodedata

ZWNJ = "\u200c"
FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
AR_DIGITS = "٠١٢٣٤٥٦٧٨٩"
_DIGIT_MAP = {ord(c): str(i) for i, c in enumerate(FA_DIGITS)}
_DIGIT_MAP.update({ord(c): str(i) for i, c in enumerate(AR_DIGITS)})
_CHAR_MAP = {
    ord("ي"): "ی", ord("ى"): "ی", 
    ord("ك"): "ک", ord("ة"): "ه", ord("ۀ"): "ه",  # ۀ -> ه (hamza-above would be stripped with diacritics anyway)
    ord("\u0640"): None,          # tatweel ـ
    ord("\u200f"): None, ord("\u200e"): None,  # RLM / LRM marks
    ord("\ufeff"): None,
    ord("٬"): ",", ord("٫"): ".",  # Arabic thousands / decimal separators
}
_DIACRITICS = re.compile("[\u064b-\u065f\u0670]")
_SPACES = re.compile(r"[ \t\u00a0\u2000-\u200b\u202f]+")
# prefixes/suffixes that should be joined with a half-space
_MI = re.compile(r"\b(ن?می)\s+(?=[آ-ی])")
_SUFFIX = re.compile(r"(?<=[آ-ی])\s+(ها|های|هایی|ای|تر|ترین|اند|ایم|اید)\b")


def to_latin_digits(text: str) -> str:
    """'۱۴۰۵/۰۷/۲۱' -> '1405/07/21'"""
    return text.translate(_DIGIT_MAP)


def to_persian_digits(text: str) -> str:
    return re.sub(r"\d", lambda m: FA_DIGITS[int(m.group())], text)


def normalize(text: str, digits: str = "latin", fix_halfspace: bool = True) -> str:
    """Return clean Persian text.

    digits: 'latin' (best for LLM + regex), 'persian', or 'keep'.
    """
    if not text:
        return ""
    t = unicodedata.normalize("NFC", text)
    t = t.translate(_CHAR_MAP)
    t = _DIACRITICS.sub("", t)
    if digits == "latin":
        t = to_latin_digits(t)
    elif digits == "persian":
        t = to_persian_digits(to_latin_digits(t))
    if fix_halfspace:
        t = _MI.sub(lambda m: m.group(1) + ZWNJ, t)
        t = _SUFFIX.sub(lambda m: ZWNJ + m.group(1), t)
        t = re.sub(ZWNJ + "{2,}", ZWNJ, t)
        t = re.sub(r"\s*" + ZWNJ + r"\s*", ZWNJ, t)
    t = _SPACES.sub(" ", t)
    t = re.sub(r" *\n *", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def report(text: str) -> dict:
    """Count the problems normalize() fixes — nice for a 'before/after' table."""
    return {
        "arabic_yeh_kaf": sum(text.count(c) for c in "يكى"),
        "persian_arabic_digits": sum(1 for c in text if c in FA_DIGITS + AR_DIGITS),
        "tatweel": text.count("\u0640"),
        "diacritics": len(_DIACRITICS.findall(text)),
        "zwnj": text.count(ZWNJ),
    }
