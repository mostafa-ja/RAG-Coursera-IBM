"""Persian money parsing: digits with separators, Persian number words, Rial vs Toman.

    parse_amount("۲۵۰,۰۰۰,۰۰۰ ریال")                 -> 250_000_000 (Rial)
    parse_amount("۲۵ میلیون تومان")                    -> 250_000_000 (Rial)
    parse_amount("دو میلیارد و پانصد میلیون ریال")     -> 2_500_000_000
Everything is returned in **Rial** (integer) — the official unit in tender documents.
"""
import re

from .normalize import normalize

ONES = {"صفر": 0, "یک": 1, "یه": 1, "دو": 2, "سه": 3, "چهار": 4, "پنج": 5, "شش": 6, "شیش": 6,
        "هفت": 7, "هشت": 8, "نه": 9, "ده": 10, "یازده": 11, "دوازده": 12, "سیزده": 13,
        "چهارده": 14, "پانزده": 15, "پونزده": 15, "شانزده": 16, "هفده": 17, "هجده": 18,
        "هیجده": 18, "نوزده": 19, "بیست": 20, "سی": 30, "چهل": 40, "پنجاه": 50, "شصت": 60,
        "هفتاد": 70, "هشتاد": 80, "نود": 90, "صد": 100, "یکصد": 100, "دویست": 200,
        "سیصد": 300, "چهارصد": 400, "پانصد": 500, "پونصد": 500, "ششصد": 600,
        "هفتصد": 700, "هشتصد": 800, "نهصد": 900}
SCALES = {"هزار": 10**3, "میلیون": 10**6, "میلیارد": 10**9, "بیلیون": 10**9, "تریلیون": 10**12}
TOMAN_WORDS = ("تومان", "تومن")
RIAL_WORDS = ("ریال",)


def words_to_number(text: str):
    """Persian number words (optionally mixed with digits) -> int. None if nothing found.

    'دو میلیارد و پانصد میلیون' -> 2500000000 ; '1.5 میلیارد' -> 1500000000 ;
    'سیصد و بیست هزار' -> 320000
    """
    t = normalize(text).replace(",", "").replace("\u200c", " ")
    tokens = re.findall(r"\d+(?:\.\d+)?|[آ-ی]+", t)
    total, current, seen = 0, 0.0, False
    for tok in tokens:
        if tok == "و":
            continue
        if re.fullmatch(r"\d+(?:\.\d+)?", tok):
            current += float(tok); seen = True
        elif tok in ONES:
            current += ONES[tok]; seen = True
        elif tok in SCALES:
            current = (current or 1) * SCALES[tok]
            if SCALES[tok] >= 1000:
                total += current; current = 0
            seen = True
        elif seen:
            break                       # stop at the first non-number word after a number
    return int(round(total + current)) if seen else None


_AMOUNT = re.compile(
    r"(\d[\d,]*(?:\.\d+)?(?:\s*(?:هزار|میلیون|میلیارد))*"
    r"|(?:(?:" + "|".join(sorted(ONES, key=len, reverse=True)) + r"|هزار|میلیون|میلیارد|و)\s*)+)"
    r"\s*(ریال|تومان|تومن)")


def parse_amount(text: str, default_unit: str = "rial"):
    """Return the first money amount in text as integer Rial, or None.

    If no unit is written, `default_unit` decides (tender docs are almost always Rial).
    """
    t = normalize(text)
    m = _AMOUNT.search(t)
    if m:
        value = words_to_number(m.group(1))
        if value is None:
            return None
        return value * 10 if m.group(2) in TOMAN_WORDS else value
    value = words_to_number(t)
    if value is None:
        return None
    return value * 10 if default_unit == "toman" else value


def rial_to_toman(rial: int) -> int:
    return rial // 10


def format_rial(rial: int, persian_digits: bool = False) -> str:
    s = f"{rial:,} ریال"
    if persian_digits:
        from .normalize import to_persian_digits
        s = to_persian_digits(s).replace(",", "٬")
    return s
