"""Field-level accuracy against data/gold.jsonl + model comparison (Course 1 M3: choosing the right model)."""
import json
import pathlib
import re
import time

from .jalali import jalali_str_to_iso
from .normalize import normalize

EXACT = ["tender_number", "tender_type", "deadline_jalali", "deadline_iso", "bond_amount_rial"]
FUZZY = ["organization", "province", "category", "required_grade"]
FIELDS = EXACT + FUZZY


def load_gold(path="data/gold.jsonl"):
    rows = [json.loads(l) for l in pathlib.Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]
    for r in rows:
        r["deadline_iso"] = jalali_str_to_iso(r["deadline_jalali"]) if r.get("deadline_jalali") else None
    return rows


def load_notices(folder="data/notices"):
    return {p.stem: p.read_text(encoding="utf-8") for p in sorted(pathlib.Path(folder).glob("*.txt"))}


def _tokens(s):
    s = normalize(str(s)).replace("\u200c", " ")
    return set(re.findall(r"[\w]+", s)) - {"و", "از", "در", "به", "حداقل", "رتبه", "استان"}


def field_match(field, pred, gold) -> bool:
    if gold is None or gold == "":
        return pred in (None, "", [], "نامشخص")
    if pred is None:
        return False
    if field in EXACT:
        return normalize(str(pred)).replace(" ", "") == normalize(str(gold)).replace(" ", "")
    g, p = _tokens(gold), _tokens(pred)
    if not g:
        return not p
    return len(g & p) / len(g) >= 0.6        # recall of gold tokens


def score(preds: dict, gold_rows: list) -> dict:
    """preds: {id: card_dict}. Returns per-field and overall accuracy + list of mistakes."""
    per_field = {f: 0 for f in FIELDS}
    mistakes = []
    for g in gold_rows:
        p = preds.get(g["id"], {}) or {}
        for f in FIELDS:
            if field_match(f, p.get(f), g.get(f)):
                per_field[f] += 1
            else:
                mistakes.append({"id": g["id"], "field": f, "pred": p.get(f), "gold": g.get(f)})
    n = len(gold_rows)
    acc = {f: round(c / n, 3) for f, c in per_field.items()}
    acc["_overall"] = round(sum(per_field.values()) / (n * len(FIELDS)), 3)
    return {"accuracy": acc, "mistakes": mistakes}


def compare_models(models, notices: dict, gold_rows: list, few_shot=True, pause=0.0):
    """Run every model on every notice. Returns a list of summary rows (one per model) and raw results."""
    from .extractor import build_chain, extract
    summary, raw = [], {}
    for m in models:
        chain = build_chain(model=m, few_shot=few_shot, fallback=None)
        results = {}
        for nid, text in notices.items():
            results[nid] = extract(text, chain=chain)
            time.sleep(pause)                       # free tier: stay under requests-per-minute
        s = score({k: v["card"] for k, v in results.items()}, gold_rows)
        secs = [r["seconds"] for r in results.values()]
        summary.append({"model": m, "few_shot": few_shot,
                        "valid_json": sum(r["ok"] for r in results.values()),
                        "accuracy": s["accuracy"]["_overall"],
                        "deadline_acc": s["accuracy"]["deadline_jalali"],
                        "bond_acc": s["accuracy"]["bond_amount_rial"],
                        "avg_sec": round(sum(secs) / len(secs), 2)})
        raw[m] = {"results": results, "score": s}
    return summary, raw


if __name__ == "__main__":       # offline check with the regex baseline
    from .extractor import rule_extract
    from .jalali import jalali_str_to_iso as j2i
    gold, notices = load_gold(), load_notices()
    preds = {}
    for k, v in notices.items():
        r = rule_extract(v)
        r["deadline_iso"] = j2i(r["deadline_jalali"]) if r.get("deadline_jalali") else None
        preds[k] = r
    s = score(preds, gold)
    print(json.dumps(s["accuracy"], ensure_ascii=False, indent=1))
    for m in s["mistakes"]:
        if m["field"] in ("deadline_jalali", "bond_amount_rial", "tender_number"):
            print(m)
