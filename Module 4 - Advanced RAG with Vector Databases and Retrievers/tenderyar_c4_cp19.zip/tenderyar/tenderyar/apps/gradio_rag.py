"""TenderYar v0.2 «Ask the package» — Gradio Blocks (RTL): upload PDF -> tender card + chat with page citations.
Run:  python -m tenderyar.apps.gradio_rag            (Colab: demo.launch(share=True))
Env:  TY_MODEL (default gemini-3.8-flash; 'offline' = no key), TY_EMBED (default models/gemini-embedding-2; 'offline')."""
import os
import gradio as gr
from tenderyar.rag.loaders import load_pdf, rtl_order_score
from tenderyar.rag.splitter import split_docs, persian_splitter
from tenderyar.rag.index import build_index, get_embeddings, retriever
from tenderyar.rag.qa import build_qa_chain, answer
from tenderyar.extractor import rule_extract

MODEL = os.getenv("TY_MODEL", "gemini-3.8-flash")
EMBED = os.getenv("TY_EMBED", "models/gemini-embedding-2")
STATE = {}
RTL_CSS = ".prs, .gradio-container {direction: rtl; font-family: Vazirmatn, Tahoma, sans-serif}"


def _kw(cls, **kw):
    """Gradio 4/5/6 compatible: pass only the keyword arguments this Gradio version accepts
    (Gradio 6 removed Blocks(rtl=..., css=...) and Chatbot(type=...); css moved to launch())."""
    import inspect
    ok = inspect.signature(cls.__init__).parameters
    return {k: v for k, v in kw.items() if k in ok}


def index_pdf(file):
    if file is None: return {}, "یک فایل PDF انتخاب کنید."
    path = file if isinstance(file, str) else file.name
    docs = load_pdf(path)
    chunks = split_docs(docs, persian_splitter())
    ret = retriever(build_index(chunks, embeddings=get_embeddings(EMBED)), k=5)
    STATE.update(ret=ret, chain=build_qa_chain(ret, model=MODEL))
    card = rule_extract("\n".join(d.page_content for d in docs[:3]))        # v0.1 re-used on the notice pages
    low = [d.metadata["page"] for d in docs if d.metadata["rtl_score_raw"] < 0.5]
    return card, f"{len(docs)} صفحه · {len(chunks)} قطعه · صفحات با ترتیب معکوس (اصلاح‌شده): {low or '—'}"


def chat(msg, history):
    if "chain" not in STATE:
        return history + [{"role": "user", "content": msg}, {"role": "assistant", "content": "اول فایل را بارگذاری کنید."}], ""
    r = answer(msg, STATE["ret"], STATE["chain"])
    src = "\n\n".join(f"**[ص {c.metadata['page']}]** {c.page_content[:300]}" for c in r["chunks"])
    return history + [{"role": "user", "content": msg}, {"role": "assistant", "content": r["answer"]}], src


def build_ui():
    with gr.Blocks(**_kw(gr.Blocks, rtl=True, title="مناقصه‌یار v0.2", css=RTL_CSS)) as demo:
        gr.Markdown("## مناقصه‌یار · از اسناد مناقصه بپرسید")
        with gr.Row():
            with gr.Column(scale=1):
                f = gr.File(label="اسناد مناقصه (PDF)", file_types=[".pdf"])
                status = gr.Markdown()
                card = gr.JSON(label="کارت مناقصه")
            with gr.Column(scale=2):
                bot = gr.Chatbot(**_kw(gr.Chatbot, type="messages", label="پرسش و پاسخ", height=420, rtl=True))
                q = gr.Textbox(**_kw(gr.Textbox, label="پرسش", placeholder="مبلغ تضمین شرکت در مناقصه چقدر است؟", rtl=True))
                with gr.Accordion("منابع (قطعه‌های بازیابی‌شده)", open=False):
                    sources = gr.Markdown()
        f.change(index_pdf, f, [card, status])
        q.submit(chat, [q, bot], [bot, sources]).then(lambda: "", None, q)
    return demo


def launch(demo=None, **kw):
    """demo.launch() with RTL css on Gradio 6 (where css moved from Blocks to launch)."""
    demo = demo or build_ui()
    return demo.launch(**_kw(type(demo).launch, css=RTL_CSS), **kw) if "css" not in _kw(gr.Blocks, css=1) else demo.launch(**kw)


if __name__ == "__main__":
    launch(share=bool(os.getenv("COLAB_RELEASE_TAG")))
