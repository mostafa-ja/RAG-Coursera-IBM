"""v0.3 Gradio app: tab «کتابخانه» (filters + search) and tab «پیشنهاد برای شرکت من» (profile JSON -> top-5 with reasons).
    python -m tenderyar.apps.gradio_library          # TY_EMBED=offline = no key; TY_DB=chroma_db (Drive path in Colab)"""
import json, os, pathlib
from ..rag.index import get_embeddings
from ..rag.splitter import persian_splitter
from ..library import store, search as S, match as M
from ..library.cards import load_cards, EVAL_TODAY
from ..library.categories import CATEGORIES

R = pathlib.Path(__file__).resolve().parents[2]


def open_library(db=None, embed=None):
    emb = get_embeddings(embed or os.environ.get("TY_EMBED", "models/gemini-embedding-2"))
    coll = store.get_collection(store.get_client(db or os.environ.get("TY_DB", str(R / "chroma_db"))))
    cards = load_cards(R / "data/cards.jsonl")
    if coll.count() == 0:
        sp = persian_splitter()
        for c in cards:
            store.upsert_tender(coll, c, sp.split_text((R / c["text_path"]).read_text(encoding="utf-8")), emb)
    return coll, emb, cards


def library_rows(coll, emb, query, province, category, after, max_bond_bn):
    w = S.build_where(province=province or None, category=category or None, after=after or None,
                      max_bond=float(max_bond_bn) * 1e9 if max_bond_bn else None)
    return [[h["tender_id"], h["meta"]["org"], h["meta"]["province"], h["meta"]["category"], h["meta"]["deadline_jalali"],
             f'{h["meta"]["bond_rial"]:,}', h["sim"]] for h in S.search(coll, emb, query or "مناقصه", where=w, k=10)]


def parse_profile(profile_json):
    """JSON text -> profile dict, or ValueError with a Persian message (shown by the app instead of a traceback)."""
    try:
        p = json.loads(profile_json or "")
    except json.JSONDecodeError as e:
        raise ValueError(f"پروفایل JSON نامعتبر است (سطر {e.lineno}، ستون {e.colno})") from None
    if not isinstance(p, dict) or not p.get("fields"):
        raise ValueError("پروفایل باید یک شیء JSON با کلید «fields» باشد")
    return p


def match_rows(coll, emb, cards, profile_json, today=EVAL_TODAY):
    p = parse_profile(profile_json)
    return [[r["tender_id"], r["score"], r["reasons_fa"]] for r in M.match(p, coll, emb, cards, k=5, today=today)]


def build():
    import gradio as gr
    coll, emb, cards = open_library()
    provs = sorted({c["province"] for c in cards if c.get("province")})
    prof = (R / "data/profiles/zagros.json").read_text(encoding="utf-8")
    with gr.Blocks(title="TenderYar v0.3") as demo:
        gr.Markdown("## مناقصه‌یار · کتابخانه مناقصه‌ها و پیشنهاد برای شرکت", rtl=True)
        with gr.Tab("کتابخانه"):
            q = gr.Textbox(label="جستجو", value="روکش آسفالت", rtl=True)
            with gr.Row():
                pv = gr.Dropdown(provs, label="استان"); ct = gr.Dropdown(CATEGORIES, label="دسته")
                af = gr.Textbox(label="مهلت بعد از (شمسی)", value="1405/08/15"); mb = gr.Number(label="سقف تضمین (میلیارد ریال)", value=5)
            out = gr.Dataframe(headers=["id", "دستگاه", "استان", "دسته", "مهلت", "تضمین (ریال)", "شباهت"])
            gr.Button("جستجو").click(lambda *a: library_rows(coll, emb, *a), [q, pv, ct, af, mb], out)
        with gr.Tab("پیشنهاد برای شرکت من"):
            pj = gr.Code(value=prof, language="json", label="پروفایل شرکت")
            out2 = gr.Dataframe(headers=["id", "امتیاز", "دلایل"])
            def _match(j):
                try:
                    return match_rows(coll, emb, cards, j)
                except ValueError as e:
                    raise gr.Error(str(e))
            gr.Button("پیشنهاد بده").click(_match, pj, out2)
    return demo


if __name__ == "__main__":
    build().launch(share=bool(os.environ.get("COLAB_RELEASE_TAG")))
