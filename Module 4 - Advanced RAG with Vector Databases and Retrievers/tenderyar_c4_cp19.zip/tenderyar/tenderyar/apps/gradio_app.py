"""Gradio RTL UI (Course 1 M3: Gradio interface).  python -m tenderyar.apps.gradio_app"""
import json
import os
import pathlib

import gradio as gr

from ..extractor import build_chain, extract, rule_extract
from ..money import format_rial
from ..normalize import normalize
from ..schema import TenderCard

MODELS = ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash", "rules-only (offline)"]
EXAMPLES_DIR = pathlib.Path(__file__).resolve().parents[2] / "data" / "notices"
_chains = {}

LABELS = {"organization": "دستگاه مناقصه‌گزار", "subject": "موضوع", "tender_number": "شماره",
          "tender_type": "نوع", "province": "استان", "city": "شهر", "category": "دسته",
          "deadline_jalali": "مهلت (شمسی)", "deadline_time": "ساعت", "deadline_iso": "مهلت (میلادی)",
          "opening_jalali": "بازگشایی", "bond_amount_rial": "تضمین", "bond_types": "نوع تضمین",
          "estimate_rial": "برآورد", "required_grade": "رتبه/صلاحیت", "document_fee_rial": "بهای اسناد",
          "contact_phone": "تلفن"}
CSS = """.rtl, .rtl textarea, .rtl table {direction: rtl; text-align: right;
          font-family: Vazirmatn, Tahoma, sans-serif;}"""


def run(text, model, few_shot):
    if not text.strip():
        return [], "{}", "متن آگهی را وارد کنید."
    if model.startswith("rules"):
        card, info = TenderCard(**rule_extract(normalize(text))).fill_computed().model_dump(), "حالت آفلاین (قواعد)"
    else:
        key = (model, few_shot)
        if key not in _chains:
            _chains[key] = build_chain(model=model, few_shot=few_shot)
        r = extract(text, chain=_chains[key])
        card = r["card"]
        info = f"⏱ {r['seconds']} ثانیه" + ("" if r["ok"] else f" — خطا، نتیجهٔ قواعد نمایش داده شد: {r['error'][:120]}")
    rows = []
    for k, label in LABELS.items():
        v = card.get(k)
        if v in (None, [], ""):
            continue
        if k.endswith("_rial") and isinstance(v, int):
            v = format_rial(v, persian_digits=True)
        rows.append([label, "، ".join(v) if isinstance(v, list) else str(v)])
    return rows, json.dumps(card, ensure_ascii=False, indent=2), info


def build_ui():
    examples = [[p.read_text(encoding="utf-8")] for p in sorted(EXAMPLES_DIR.glob("*.txt"))[:5]]
    with gr.Blocks(title="مناقصه‌یار · TenderYar v0.1", css=CSS) as demo:
        gr.Markdown("# مناقصه‌یار · TenderYar v0.1\nمتن آگهی مناقصه را بچسبانید تا کارت مناقصه (JSON) بگیرید.", elem_classes="rtl")
        with gr.Row():
            with gr.Column():
                text = gr.Textbox(lines=14, label="متن آگهی", elem_classes="rtl", rtl=True)
                model = gr.Dropdown(MODELS, value=MODELS[0], label="مدل")
                few = gr.Checkbox(value=True, label="few-shot")
                btn = gr.Button("استخراج", variant="primary")
            with gr.Column():
                table = gr.Dataframe(headers=["فیلد", "مقدار"], elem_classes="rtl", wrap=True)
                info = gr.Markdown(elem_classes="rtl")
                js = gr.Code(language="json", label="JSON")
        gr.Examples(examples, inputs=[text])
        btn.click(run, [text, model, few], [table, js, info])
    return demo


if __name__ == "__main__":
    build_ui().launch(share=bool(os.getenv("COLAB_RELEASE_TAG")), debug=False)
