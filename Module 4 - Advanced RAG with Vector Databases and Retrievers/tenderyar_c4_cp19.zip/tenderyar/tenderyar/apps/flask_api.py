"""Flask API (Course 1 M3: Flask app).  POST /extract {"text": "...", "model": "gemini-3.8-flash"}

Run:   python -m tenderyar.apps.flask_api        (needs GOOGLE_API_KEY)
       TENDERYAR_OFFLINE=1 python -m tenderyar.apps.flask_api   (regex baseline, no key)
Test:  curl -X POST localhost:5000/extract -H "Content-Type: application/json" -d '{"text":"..."}'
"""
import os

from flask import Flask, jsonify, request

from ..extractor import DEFAULT_MODEL, build_chain, extract, rule_extract
from ..schema import TenderCard
from ..normalize import normalize

app = Flask(__name__)
app.json.ensure_ascii = False          # return Persian as Persian, not \u0645...
MAX_CHARS = 12_000                     # notices are short; protects the free-tier quota
ALLOWED_MODELS = {"gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash"}  # no arbitrary model names from clients
_chains = {}


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.0"}


@app.post("/extract")
def extract_endpoint():
    body = request.get_json(silent=True) or {}
    text = (body.get("text") or "").strip()
    if not text:
        return jsonify(error="field 'text' is required"), 400
    if len(text) > MAX_CHARS:
        return jsonify(error=f"text longer than {MAX_CHARS} characters"), 413
    if os.getenv("TENDERYAR_OFFLINE") == "1" or body.get("offline"):
        card = TenderCard(**rule_extract(normalize(text))).fill_computed()
        return jsonify(card=card.model_dump(), ok=True, mode="rules")
    model = body.get("model", DEFAULT_MODEL)
    if model not in ALLOWED_MODELS:
        return jsonify(error=f"model must be one of {sorted(ALLOWED_MODELS)}"), 400
    if model not in _chains:
        _chains[model] = build_chain(model=model, few_shot=body.get("few_shot", True))
    result = extract(text, chain=_chains[model])
    result["mode"] = model
    return jsonify(result), (200 if result["ok"] else 502)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
