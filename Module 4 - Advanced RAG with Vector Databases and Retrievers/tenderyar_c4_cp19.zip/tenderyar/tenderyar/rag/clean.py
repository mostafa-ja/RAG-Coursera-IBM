"""Search-time clean-up for Persian (C4 / v0.4).

search_normalize() = v0.1 normalize() + extra rules that only matter for *matching*:
ZWNJ -> space (so «کتاب‌ها» matches «کتاب ها»), unify hamza forms, common spelling
variants, digits -> Latin, lower-case Latin. tokens() uses hazm's WordTokenizer when
installed, otherwise a regex fallback (so tests run offline without hazm).
"""
import re
from tenderyar.normalize import normalize, ZWNJ

VARIANTS = {"اطاق": "اتاق", "طهران": "تهران", "هیات": "هیئت", "هیأت": "هیئت",
            "مسئول": "مسئول", "مسوول": "مسئول", "مسؤول": "مسئول", "ريال": "ریال"}
_HAMZA = str.maketrans({"أ": "ا", "إ": "ا", "ٱ": "ا", "ؤ": "و", "ٔ": None})
STOPWORDS = set("""و در به از که این آن با را برای تا یا هم نیز بر است هست بود شد شود می ها های
یک هر چه اگر پس ای ای‌ها اند کرد کند کنند شده خواهد باید""".split())
_TOKEN = re.compile(r"[0-9]+(?:[/.\-][0-9]+)*|[A-Za-z]+|[\u0621-\u064A\u0670-\u06D3\u06FA-\u06FF]+")   # letters only: ، ؛ ؟ ٪ « » are NOT word chars (CP115 fix)


def search_normalize(text: str) -> str:
    """'كتاب‌ها ي' -> 'کتاب ها ی' (Persian chars, ZWNJ->space, digits Latin)."""
    t = normalize(text or "", digits="latin", fix_halfspace=False)
    t = t.replace("هیأت", "هیئت")            # before hamza strip
    t = t.translate(_HAMZA)
    t = t.replace(ZWNJ, " ")
    t = " ".join(VARIANTS.get(w, w) for w in t.split())
    return re.sub(r"\s+", " ", t).strip().lower()


def _hazm_tokenize(t):
    try:
        from hazm import WordTokenizer  # optional dependency
    except Exception:
        return None
    return WordTokenizer(separate_emoji=False).tokenize(t)


_NUM = re.compile(r"[0-9]+(?:[,٬][0-9]{3})+")          # 5,550,000,000 -> 5550000000 (one token)
_ZW_WORD = re.compile(r"[\u0600-\u06FF]+(?:\u200c[\u0600-\u06FF]+)+")
PREFIXES, SUFFIXES = ("نمی", "می"), ("هایی", "های", "ها")


def stem(w: str) -> str:
    """Very light Persian stemmer: «میشود»->«شود», «صورتوضعیتها»->«صورتوضعیت». Only if >= 3 letters remain."""
    for p in PREFIXES:
        if w.startswith(p) and len(w) - len(p) >= 3:
            w = w[len(p):]; break
    for x in SUFFIXES:
        if w.endswith(x) and len(w) - len(x) >= 3:
            w = w[: -len(x)]; break
    return w


def tokens(text: str, stop: bool = True, use_hazm: bool = False, light_stem: bool = True) -> list:
    """Tokens for BM25: search_normalize → split → drop stop words / 1-char tokens → light stem.
    Numbers keep their thousands groups together; a ZWNJ word («می‌شود») ALSO yields its glued form («میشود»→«شود»)
    so it matches PDFs that lost the ZWNJ."""
    t = _NUM.sub(lambda m: re.sub(r"[,٬]", "", m.group()), search_normalize(text))
    toks = (_hazm_tokenize(t) if use_hazm else None) or _TOKEN.findall(t)
    toks = [w for w in toks if len(w) > 1 and not (stop and w in STOPWORDS)]
    glued = [search_normalize(w.replace(ZWNJ, "")) for w in _ZW_WORD.findall(normalize(text or "", fix_halfspace=False))]
    if light_stem:
        toks = [stem(w) for w in toks]; glued = [stem(w) for w in glued]
    return toks + [g for g in glued if g not in toks]
