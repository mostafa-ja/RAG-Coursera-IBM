"""Retrieval benchmark on TenderQA (C4 / v0.4).

    df = run(configs, tenderqa)        # configs: {name: factory(pages, chunks) -> retriever with .invoke(q)}
    plot(df, "docs/img/v0_4_recall.png")
Metrics are PAGE level (rag.metrics) on the answerable questions; negatives are reported separately
(a retriever always returns something, so they are judged on the ANSWER: "در اسناد نیامده است")."""
import json, re, time, pathlib
from tenderyar.rag.metrics import recall_at_k, mrr, ndcg_at_k, judge
from tenderyar.rag.clean import tokens

K = 5


def load_tenderqa(path="data/tenderqa/v0.jsonl"):
    return [json.loads(l) for l in pathlib.Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]


def load_package(pkg, root="."):
    from tenderyar.rag.loaders import load_pdf
    from tenderyar.rag.splitter import split_docs, persian_splitter
    pages = load_pdf(pathlib.Path(root) / f"data/packages/{pkg}.pdf")
    return pages, split_docs(pages, persian_splitter(800, 120))     # v0.3 chunk settings


def extractive_answer(question, docs):
    """Keyless 'LLM': the sentence of the retrieved text that shares most tokens with the question."""
    q = set(tokens(question)); best, sc = "", -1
    for d in docs[:3]:
        for s in re.split(r"[\n.؟!]", d.page_content):
            o = len(q & set(tokens(s)))
            if o > sc and s.strip():
                best, sc = s.strip(), o
    return best


def run(configs, tenderqa, root=".", k=K, answer_fn=None, judge_llm=None, cache=None):
    """-> pandas DataFrame, one row per config: recall@k, MRR, nDCG@k, judge (0–2), ms/query (+ per-question details in .attrs)."""
    import pandas as pd
    cache = cache if cache is not None else {}
    rows, detail = [], {}
    for name, factory in configs.items():
        rs, ms, js, per = [], [], [], []
        for pkg in sorted({q["package"] for q in tenderqa}):
            if pkg not in cache:
                cache[pkg] = load_package(pkg, root)
            pages, chunks = cache[pkg]
            ret = factory(pages, chunks)
            for q in [x for x in tenderqa if x["package"] == pkg]:
                t0 = time.perf_counter(); docs = ret.invoke(q["question"]); ms.append((time.perf_counter() - t0) * 1000)
                got = [d.metadata.get("page") for d in docs]
                if q["gold_pages"]:
                    r = (recall_at_k(got, q["gold_pages"], k), mrr(got, q["gold_pages"]), ndcg_at_k(got, q["gold_pages"], k),
                         recall_at_k(got, q["gold_pages"], 1))
                    rs.append(r)
                    ans = (answer_fn or extractive_answer)(q["question"], docs)
                    js.append(judge(ans, q["answer"], judge_llm))
                    per.append({"id": q["id"], "type": q["type"], "got": got[:k], "gold": q["gold_pages"], "recall": r[0], "mrr": r[1]})
        n = len(rs)
        rows.append({"config": name, "recall@1": round(sum(r[3] for r in rs) / n, 3), f"recall@{k}": round(sum(r[0] for r in rs) / n, 3), "MRR": round(sum(r[1] for r in rs) / n, 3),
                     f"nDCG@{k}": round(sum(r[2] for r in rs) / n, 3), "judge (0–2)": round(sum(js) / len(js), 2),
                     "ms/query": round(sum(ms) / len(ms), 1), "n": n})
        detail[name] = per
    df = pd.DataFrame(rows)
    df.attrs["detail"] = detail
    return df


def by_type(df, config):
    import pandas as pd
    d = pd.DataFrame(df.attrs["detail"][config])
    return d.groupby("type")[["recall", "mrr"]].mean().round(3)


def why_fails(q):
    """Rough failure label for the 'worst questions' table (proj-s1)."""
    ev = set(tokens(q.get("evidence") or "")); qt = set(tokens(q["question"]))
    if any(ch.isdigit() for ch in q["question"]):
        return "number"
    if q["gold_pages"] and 7 in q["gold_pages"] and q["type"] == "list":
        return "table"
    if not (ev & qt):
        return "synonym / paraphrase"
    return "spelling (ZWNJ, ي/ك) or shared boilerplate"


def plot(df, path="docs/img/v0_4_recall.png", metric=f"recall@{K}"):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 3.6))
    ax.barh(df["config"][::-1], df[metric][::-1], color="#2783DE")
    for i, v in enumerate(df[metric][::-1]):
        ax.text(v + 0.01, i, f"{v:.2f}", va="center", fontsize=9)
    ax.set_xlim(0, 1.08); ax.set_xlabel(metric); ax.set_title(f"TenderQA v0 · {metric} by retriever")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout(); pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True); fig.savefig(path, dpi=130); plt.close(fig)
    return path


# ---------------------------------------------------------------- the 6 spec configs (+ grid rows), shared by the script and the notebook
def raw_tok(t):
    """Clean-up OFF: whitespace split, no normalisation (what v0.3 effectively did)."""
    return [w for w in (t or "").split() if len(w) > 1]


def standard_configs(embeddings, embeddings_raw=None, llm=None, reranker=None, grid=True):
    """{name: factory(pages, chunks)}. embeddings = dense model (HashEmbeddings offline, Gemini in Colab);
    embeddings_raw = same model WITHOUT Persian clean-up (offline: HashEmbeddings(normalise=False));
    llm = paraphraser for multi-query (None = offline synonyms); reranker = CrossEncoder or None (= OverlapReranker)."""
    from tenderyar.rag.index import build_index
    from tenderyar.rag import retrievers as T
    vs_cache = {}
    def vs(chunks, raw=False):
        key = (id(chunks), raw)
        if key not in vs_cache:
            vs_cache[key] = build_index(chunks, "c4raw" if raw else "c4", (embeddings_raw or embeddings) if raw else embeddings)
        return vs_cache[key]
    d = lambda c, k=5, raw=False: T.dense_retriever(vs(c, raw), k=k)
    hy = lambda c, w=0.5, k=5: T.hybrid(T.BM25(c, k=20), d(c, 20), weights=(w, 1 - w), k=k)
    cfg = {"1 dense (v0.3 baseline)": lambda p, c: d(c)}
    if grid:
        cfg["dense + MMR"] = lambda p, c: T.dense_retriever(vs(c), k=5, mmr=True)
    cfg["2 BM25 (clean tokens)"] = lambda p, c: T.BM25(c, k=5)
    if grid:
        cfg["hybrid 0.3/0.7"] = lambda p, c: hy(c, 0.3)
    cfg["3 hybrid 0.5/0.5"] = lambda p, c: hy(c, 0.5)
    if grid:
        cfg["hybrid 0.7/0.3"] = lambda p, c: hy(c, 0.7)
    cfg["4 hybrid + multi-query"] = lambda p, c: T.multi_query(hy(c, 0.5, 20), llm=llm, n=3, k=5)
    cfg["5 hybrid + MQ + re-rank"] = lambda p, c: T.Reranked(T.multi_query(hy(c, 0.5, 20), llm=llm, n=3, k=20), top_n=5, reranker=reranker)
    if grid:
        cfg["parent (BM25 children → article)"] = lambda p, c: T.parent_retriever(p, k=5)
        cfg["BM25 raw tokens (clean-up OFF)"] = lambda p, c: T.BM25(c, k=5, tokenizer=raw_tok)
    cfg["6 = 3 with clean-up OFF"] = lambda p, c: T.hybrid(T.BM25(c, k=20, tokenizer=raw_tok), d(c, 20, raw=True), weights=(0.5, 0.5), k=5)
    return cfg


def results_rows(df, suffix=""):
    """Markdown rows for docs/RESULTS.md: | config | recall@1 | recall@5 | MRR | nDCG@5 | judge (0–2) | ms/query |"""
    return "\n".join(f"| {r['config']}{suffix} | {r['recall@1']:.3f} | {r[f'recall@{K}']:.3f} | {r['MRR']:.3f} | {r[f'nDCG@{K}']:.3f} | {r['judge (0–2)']:.2f} | {r['ms/query']:.1f} |"
                     for r in df.to_dict("records"))
