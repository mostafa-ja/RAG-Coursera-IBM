"""Measure the Q&A: answer accuracy, citation accuracy, refusals (v0.2)."""
import json, re, time
from ..normalize import normalize, to_latin_digits

_CITE = re.compile(r"\[\s*(?:ص|p\.?|page)\s*([0-9۰-۹٠-٩]+)\s*\]", re.I)


def cited_pages(answer: str) -> set:
    """'… [ص ۱۲] و [ص 3]' -> {12, 3}; also [p. 12]."""
    return {int(to_latin_digits(m)) for m in _CITE.findall(answer or "")}


def _canon(s: str) -> str:
    return re.sub(r"[,\s\u200c]", "", normalize(s or ""))


def is_refusal(answer: str) -> bool:
    return "در اسناد نیامده" in normalize(answer or "")


def judge(row: dict, ans: str) -> dict:
    gold_page = row.get("gold_page")
    if gold_page is None:
        ok = is_refusal(ans); return {"answer_ok": ok, "cite_ok": None, "refusal_ok": ok}
    a = _canon(ans)
    ok = all(_canon(k) in a for k in row["gold_keywords"]) and not is_refusal(ans)
    return {"answer_ok": ok, "cite_ok": gold_page in cited_pages(ans), "refusal_ok": None}


def load_rows(path="data/qa_c2.jsonl"):
    return [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]


def eval_qa(chain_for, rows, pause: float = 0.0) -> dict:
    """chain_for(package) -> chain (one index per package, like the app). Returns metrics + per-row log."""
    log, t0 = [], time.time()
    for r in rows:
        ans = chain_for(r["package"]).invoke(r["question"])
        log.append({**r, "answer": ans, **judge(r, ans)}); time.sleep(pause)
    ans_rows = [x for x in log if x["gold_page"] is not None]; oos = [x for x in log if x["gold_page"] is None]
    return {"answer_acc": sum(x["answer_ok"] for x in log), "n": len(log),
            "citation_acc": round(sum(x["cite_ok"] for x in ans_rows) / max(1, len(ans_rows)), 3),
            "refusal_ok": sum(x["refusal_ok"] for x in oos), "n_oos": len(oos),
            "s_per_q": round((time.time() - t0) / max(1, len(log)), 3), "log": log}
