"""Retrieval metrics at PAGE level (C4 / v0.4).

A hit = any retrieved page that is in the question's gold_pages. `retrieved` is the
ordered list of page numbers (duplicates are collapsed, first rank kept).
"""
import math


def _dedup(pages):
    seen, out = set(), []
    for p in pages:
        if p not in seen:
            seen.add(p); out.append(p)
    return out


def recall_at_k(retrieved, gold, k=5) -> float:
    """1.0 if any gold page is in the top-k (hit-rate form used in TenderQA)."""
    if not gold:
        return 1.0 if not retrieved else 0.0  # negative question: nothing should match
    return 1.0 if set(_dedup(retrieved)[:k]) & set(gold) else 0.0


def mrr(retrieved, gold) -> float:
    for i, p in enumerate(_dedup(retrieved), 1):
        if p in set(gold):
            return 1.0 / i
    return 0.0


def ndcg_at_k(retrieved, gold, k=5) -> float:
    g = set(gold)
    if not g:
        return 0.0
    dcg = sum(1 / math.log2(i + 1) for i, p in enumerate(_dedup(retrieved)[:k], 1) if p in g)
    idcg = sum(1 / math.log2(i + 1) for i in range(1, min(len(g), k) + 1))
    return dcg / idcg


JUDGE_PROMPT = """شما داور هستید. پاسخ مدل را با پاسخ مرجع مقایسه کنید و فقط یک عدد بنویسید:
2 = کاملاً درست، 1 = بخشی درست یا ناقص، 0 = غلط یا بی‌ربط.
پاسخ مرجع: {gold}
پاسخ مدل: {answer}
نمره:"""


def msg_text(out) -> str:
    """Text of an LLM reply. Gemini 3 `.content` can be a LIST of blocks -> prefer `.text`, then join blocks."""
    t = getattr(out, "text", None)
    if callable(t):
        t = t()
    if isinstance(t, str) and t:
        return t
    c = getattr(out, "content", out)
    if isinstance(c, list):
        return "".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in c)
    return str(c)


def judge(answer: str, gold: str, llm=None) -> int:
    """LLM-as-judge 0/1/2. Without llm: offline heuristic (exact=2, overlap=1, else 0)."""
    if llm is not None:
        out = llm.invoke(JUDGE_PROMPT.format(gold=gold, answer=answer))
        txt = msg_text(out)
        for ch in txt:
            if ch in "012":
                return int(ch)
        return 0
    from tenderyar.rag.clean import tokens
    a, b = set(tokens(answer)), set(tokens(gold))
    if not b:
        return 0
    if b <= a:
        return 2
    return 1 if len(a & b) / len(b) >= 0.5 else 0
