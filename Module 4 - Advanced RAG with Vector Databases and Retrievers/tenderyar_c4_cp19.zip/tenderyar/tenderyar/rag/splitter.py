"""Persian, clause-aware splitting (v0.2). Chunks never cross a page: we split page by page and keep metadata."""
from langchain_text_splitters import RecursiveCharacterTextSplitter, CharacterTextSplitter

SEPARATORS = ["\n\nماده", "\nماده", "\nبند", "\n\n", "\n", "۔", ".", "؟", "!", "؛", " "]


def persian_splitter(chunk_size: int = 800, overlap: int = 120) -> RecursiveCharacterTextSplitter:
    """«ماده»/«بند»-aware recursive splitter (keep_separator='start' so a chunk begins with «ماده ۵ …»)."""
    return RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=overlap, separators=SEPARATORS,
                                          keep_separator="start", length_function=len)


def fixed_splitter(chunk_size: int = 500, overlap: int = 0) -> CharacterTextSplitter:
    """Baseline for proj-s2: blind fixed-length cuts (separator='' = cut anywhere)."""
    return CharacterTextSplitter(separator="", chunk_size=chunk_size, chunk_overlap=overlap)


def plain_recursive(chunk_size: int = 800, overlap: int = 120) -> RecursiveCharacterTextSplitter:
    return RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=overlap)


def split_docs(docs, splitter=None) -> list:
    """Split each page separately -> page metadata survives; adds chunk_id like 'P01.pdf:p2:c0'."""
    splitter = splitter or persian_splitter()
    out = []
    for d in docs:
        for j, c in enumerate(splitter.split_documents([d])):
            c.metadata["chunk_id"] = f"{d.metadata.get('source', 'doc')}:p{d.metadata.get('page')}:c{j}"
            out.append(c)
    return out
