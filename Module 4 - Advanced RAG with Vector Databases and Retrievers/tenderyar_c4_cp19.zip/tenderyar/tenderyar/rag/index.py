"""Embeddings + Chroma vector store + retriever (v0.2).
Gemini embeddings in Colab; HashEmbeddings = a tiny offline stand-in (char n-grams) for tests and keyless demos."""
import hashlib, math, re
from typing import List
from langchain_core.embeddings import Embeddings
from ..normalize import normalize

EMBED_MODEL = "models/gemini-embedding-2"


class GeminiTaskEmbeddings(Embeddings):
    """Documents embedded with task_type=retrieval_document, queries with retrieval_query (better retrieval)."""
    def __init__(self, model: str = EMBED_MODEL):
        from langchain_google_genai import GoogleGenerativeAIEmbeddings
        self.doc = GoogleGenerativeAIEmbeddings(model=model, task_type="retrieval_document")
        self.qry = GoogleGenerativeAIEmbeddings(model=model, task_type="retrieval_query")
    def embed_documents(self, texts): return self.doc.embed_documents(texts)
    def embed_query(self, text): return self.qry.embed_query(text)


class HashEmbeddings(Embeddings):
    """Offline, deterministic: hashed character 3-grams of normalised text -> unit vector. NOT semantic — a baseline."""
    def __init__(self, dim: int = 512, normalise: bool = True):
        self.dim, self.normalise = dim, normalise
    def _vec(self, text: str) -> List[float]:
        t = normalize(text) if self.normalise else text
        t = re.sub(r"\s+", " ", t)
        v = [0.0] * self.dim
        for w in t.split():
            w = f" {w} "
            for i in range(len(w) - 2):
                v[int(hashlib.md5(w[i:i + 3].encode()).hexdigest(), 16) % self.dim] += 1.0
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        return [x / n for x in v]
    def embed_documents(self, texts): return [self._vec(t) for t in texts]
    def embed_query(self, text): return self._vec(text)


def get_embeddings(model: str = EMBED_MODEL) -> Embeddings:
    return HashEmbeddings() if model == "offline" else GeminiTaskEmbeddings(model)


def build_index(chunks, collection: str = "pkg", embeddings: Embeddings = None, persist_directory: str = None):
    """In-memory Chroma (C3 will pass persist_directory). Cosine distance."""
    from langchain_chroma import Chroma
    import uuid
    return Chroma.from_documents(chunks, embeddings or get_embeddings(), collection_name=f"{collection}_{uuid.uuid4().hex[:6]}",
                                 persist_directory=persist_directory, collection_metadata={"hnsw:space": "cosine"})


def retriever(vs, k: int = 5, mmr: bool = False):
    return vs.as_retriever(search_type="mmr" if mmr else "similarity",
                           search_kwargs={"k": k, "fetch_k": max(20, 4 * k)} if mmr else {"k": k})
