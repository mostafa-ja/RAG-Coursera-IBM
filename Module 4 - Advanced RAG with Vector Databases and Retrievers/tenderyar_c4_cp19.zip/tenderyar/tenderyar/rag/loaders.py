"""Load Persian tender PDFs page by page (v0.2).

Lesson learned in proj-s1: a PDF stores *drawing instructions*. Many Persian PDFs draw shaped glyphs (U+FExx
presentation forms) in visual order, so extractors must re-order them and they make different mistakes:
  * pypdf  : word order fine, but numbers come out REVERSED (5,550,000,000 -> ۰۰۰٬۰۰۰٬۰۵۵٬۵) — silent, dangerous.
  * PyMuPDF: numbers correct, but line segments / punctuation move ("X- ۵ ماده", ". ... است").
TenderYar uses PyMuPDF (values matter most) + NFKC + fix_reversed_lines() + normalize().
"""
import re, unicodedata
from langchain_core.documents import Document
from ..normalize import normalize

FA = "۰-۹0-9"
_LEAD_PUNCT = re.compile(r"^\s*([.،؛!؟])\s*(.+?)\s*$")
_ROT_ID_WORD = re.compile(rf"^(.+?)-\s*([{FA}]+)\s+(ماده|بند|ردیف|تبصره)\s*$")   # 'X- ۵ ماده' -> 'ماده ۵ - X'
_ROT_WORD_ID = re.compile(r"^(.+?)-\s*(ماده|بند|ردیف|تبصره)\s+(\S+)\s*$")         # 'X- بند ب'  -> 'بند ب - X'
LET = "\u0621-\u064A\u067E\u0686\u0698\u06A9\u06AF\u06CC"
_GLUED_NUM = re.compile(rf"^(.*?[{LET}])([{FA}][{FA}٬,]*)\s+(.+)$")         # 'کیلومتر۱۲ موضوع…طول' -> 'موضوع…طول ۱۲ کیلومتر'
_DATE_WORD = re.compile(rf"^([{FA}]{{4}})[/\s]+([{FA}]{{2}})[/\s]+([{FA}]{{2}})\s+(\S+)$")
_LABEL = re.compile(r"^(\S+)\s+:(.+)$")                                             # '۲۷۰-۱۴۰۵ :شماره مناقصه'
_REV_GROUPS = re.compile(r"[۰-۹0-9]{3}(?:[٬,][۰-۹0-9]{3})*[٬,][۰-۹0-9]{1,2}(?![۰-۹0-9])")  # ۰۰۰٬۰۰۰٬۰۵۵٬۵


def unshape(text: str) -> str:
    """Presentation forms (ﺗﻀﻤﯿﻦ) -> normal letters (تضمین). Without this, search for «تضمین» finds nothing."""
    return unicodedata.normalize("NFKC", text).replace("\x00", "/")   # some fonts map "/" to NUL


def fix_line(line: str) -> str:
    s = line.strip()
    m = _LEAD_PUNCT.match(s)
    if m: s = f"{m.group(2)}{m.group(1)}"
    end = s[-1] if s and s[-1] in ".،؛!؟" else ""
    body = s[:-1].strip() if end else s
    for rx, fmt in ((_ROT_ID_WORD, "{3} {2} - {1}"), (_ROT_WORD_ID, "{2} {3} - {1}")):
        m = rx.match(body)
        if m:
            body = fmt.format(None, *[g.strip() for g in m.groups()]); break
    head, sep, tail = body.partition(" - ")
    target = tail if sep else body
    m = _LABEL.match(target)
    if m:
        target = f"{m.group(2).strip()}: {m.group(1)}"
    else:
        m = _GLUED_NUM.match(target)
        if m:
            a, num, b = m.group(1).strip(), m.group(2), m.group(3).strip()
            d = _DATE_WORD.match(a)                     # '۱۴۰۵ ۰۸ ۱۵ روز' + '۱۴' -> 'ساعت ۱۴ روز ۱۴۰۵/۰۸/۱۵'
            target = f"{b} {num} {d.group(4)} {d.group(1)}/{d.group(2)}/{d.group(3)}" if d else f"{b} {num} {a}"
    body = f"{head} - {target}" if sep else target
    body = re.sub(r"\s{2,}", " ", body)
    return body + end


def fix_reversed_lines(text: str) -> str:
    """Repair PyMuPDF's visual-order artefacts line by line (idempotent on clean lines)."""
    return "\n".join(fix_line(l) if l.strip() else "" for l in text.splitlines())


def line_ok(line: str) -> bool:
    s = line.strip()
    return not s or (fix_line(s) == re.sub(r"\s{2,}", " ", s) and not _REV_GROUPS.search(s))


def rtl_order_score(text: str) -> float:
    """Share of non-empty lines that look like correct logical Persian order (1.0 = clean).
    Flags: leading punctuation, rotated 'X- ۵ ماده' segments, digits glued to the wrong word, reversed thousands groups."""
    lines = [l for l in unshape(text).splitlines() if l.strip()]
    return round(sum(line_ok(l) for l in lines) / len(lines), 3) if lines else 1.0


def load_pdf(path: str, fix: bool = True) -> list:
    """PyMuPDF -> one Document per page, metadata {'source', 'page'} (1-based), text unshaped + repaired + normalised."""
    import pymupdf
    docs = []
    with pymupdf.open(path) as pdf:
        for i, page in enumerate(pdf, start=1):
            raw = unshape(page.get_text())
            txt = fix_reversed_lines(raw) if fix else raw
            docs.append(Document(page_content=normalize(txt, digits="keep"),
                                 metadata={"source": str(path).split("/")[-1], "page": i, "rtl_score_raw": rtl_order_score(raw)}))
    return docs


def load_pdf_pypdf(path: str) -> list:
    """For comparison only (proj-s1): LangChain's PyPDFLoader-style extraction with pypdf."""
    from pypdf import PdfReader
    return [Document(page_content=unshape(p.extract_text() or ""), metadata={"source": str(path).split("/")[-1], "page": i})
            for i, p in enumerate(PdfReader(path).pages, start=1)]
