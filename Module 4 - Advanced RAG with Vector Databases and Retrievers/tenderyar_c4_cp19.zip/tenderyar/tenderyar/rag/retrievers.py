"""Retrievers for TenderYar v0.4 (C4). Part 1: Jalali pre-parser for self-query.

LLMs convert Jalali dates badly, so we turn date phrases into a Chroma `where`
on deadline_ts BEFORE the self-query LLM sees the question.
"""
import re
from datetime import datetime, timezone, timedelta
from tenderyar.jalali import parse_jalali, jalali_to_gregorian, gregorian_to_jalali
from tenderyar.normalize import to_latin_digits
from tenderyar.library.cards import EVAL_TODAY

DAY = 86400


def _ts(jy, jm, jd) -> int:
    g = jalali_to_gregorian(jy, jm, jd)
    return int(datetime(g.year, g.month, g.day, tzinfo=timezone.utc).timestamp())


def _today(today):
    p = parse_jalali(today or EVAL_TODAY)
    return p, _ts(*p)


def jalali_filter(question: str, today: str = None):
    """Return ({'deadline_ts': {...}} or None, question_without_date_phrase).

    «قبل از ۱۵ آبان ۱۴۰۵» -> {'deadline_ts': {'$lt': ts(1405/08/15)}}
    «بعد از X» -> $gt end of X ; «تا X» -> $lte ; «همین هفته» -> today..today+7 ;
    «ماه آینده» -> first..last day of next Jalali month ; bare date -> that day.
    """
    q = to_latin_digits(question).replace("ي", "ی")
    (ty, tm, td), tts = _today(today)
    if "همین هفته" in q or "این هفته" in q:
        return {"$and": [{"deadline_ts": {"$gte": tts}}, {"deadline_ts": {"$lt": tts + 7 * DAY}}]}, \
            re.sub(r"(همین|این) هفته", "", q).strip()
    if "ماه آینده" in q or "ماه بعد" in q:
        ny, nm = (ty + 1, 1) if tm == 12 else (ty, tm + 1)
        ay, am = (ny + 1, 1) if nm == 12 else (ny, nm + 1)
        return {"$and": [{"deadline_ts": {"$gte": _ts(ny, nm, 1)}}, {"deadline_ts": {"$lt": _ts(ay, am, 1)}}]}, \
            re.sub(r"ماه (آینده|بعد)", "", q).strip()
    p = parse_jalali(q, default_year=ty)
    if not p:
        return None, question
    ts = _ts(*p)
    if re.search(r"قبل از|پیش از", q):
        f, pat = {"$lt": ts}, r"(قبل از|پیش از)"
    elif re.search(r"بعد از|پس از", q):
        f, pat = {"$gte": ts + DAY}, r"(بعد از|پس از)"
    elif re.search(r"(^|\s)تا(\s|$)|حداکثر تا", q):
        f, pat = {"$lte": ts}, r"(حداکثر )?تا"
    else:
        f, pat = {"$gte": ts, "$lt": ts + DAY}, ""
    rest = re.sub(r"(با )?(مهلت )?" + pat + r"\s*(\d{1,2}\s+[^\s\d]+(\s+1[34]\d\d)?|[0-9/]+)", "", q)
    where = {"deadline_ts": f} if len(f) == 1 else {"$and": [{"deadline_ts": {k: v}} for k, v in f.items()]}
    return where, re.sub(r"\s+", " ", rest).strip()


# ---------------------------------------------------------------- Part 2 · BM25 + RRF + hybrid (CP112)
import math
from collections import Counter
from tenderyar.rag.clean import tokens as _tokens


def _key(d):
    m = getattr(d, "metadata", {}) or {}
    return m.get("chunk_id") or f"{m.get('source')}:{m.get('page')}:{hash(d.page_content)}"


class ListRetriever:
    """Tiny retriever protocol shared by every TenderYar retriever: .invoke(query) -> [Document] (best first).
    Same method name as LangChain retrievers, so a LangChain retriever can be dropped in anywhere."""
    k = 5
    def invoke(self, query):
        raise NotImplementedError
    def scored(self, query):
        return [(d, 1.0 / (i + 1)) for i, d in enumerate(self.invoke(query))]


class BM25(ListRetriever):
    """Okapi BM25 on search_normalize()+tokens(). score = Σ idf(t)·tf·(k1+1)/(tf+k1·(1-b+b·|d|/avgdl))."""
    def __init__(self, chunks, k=5, k1=1.5, b=0.75, tokenizer=None):
        self.docs, self.k, self.k1, self.b = list(chunks), k, k1, b
        self.tok = tokenizer or _tokens
        self.tf = [Counter(self.tok(d.page_content)) for d in self.docs]
        self.len = [sum(c.values()) for c in self.tf]
        self.avgdl = (sum(self.len) / len(self.len)) if self.len else 1.0
        df = Counter(t for c in self.tf for t in c)
        n = len(self.docs)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}

    def score(self, query):
        q = self.tok(query)
        out = []
        for c, L in zip(self.tf, self.len):
            s = 0.0
            for t in q:
                f = c.get(t, 0)
                if f:
                    s += self.idf[t] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * L / self.avgdl))
            out.append(s)
        return out

    def scored(self, query):
        s = self.score(query)
        order = sorted(range(len(s)), key=lambda i: -s[i])
        return [(self.docs[i], s[i]) for i in order[: self.k] if s[i] > 0]

    def invoke(self, query):
        return [d for d, _ in self.scored(query)]


def bm25_retriever(chunks, k=5, langchain=False):
    """Own BM25 (default, no extra dependency) or LangChain's BM25Retriever (needs rank_bm25) with Persian tokens."""
    if langchain:
        from langchain_community.retrievers import BM25Retriever
        r = BM25Retriever.from_documents(list(chunks), preprocess_func=_tokens)
        r.k = k
        return r
    return BM25(chunks, k=k)


class DenseRetriever(ListRetriever):
    """Wraps a LangChain vector store (Chroma). mmr=True -> Max Marginal Relevance (diversity)."""
    def __init__(self, vs, k=5, mmr=False, fetch_k=20):
        self.vs, self.k, self.mmr, self.fetch_k = vs, k, mmr, fetch_k
    def invoke(self, query):
        if self.mmr:
            return self.vs.max_marginal_relevance_search(query, k=self.k, fetch_k=max(self.fetch_k, 4 * self.k))
        return self.vs.similarity_search(query, k=self.k)


def dense_retriever(vs, k=5, mmr=False):
    return DenseRetriever(vs, k=k, mmr=mmr)


def rrf_fuse(ranked_lists, weights=None, c=60, top=None):
    """Reciprocal Rank Fusion: score(d) = Σ_i w_i / (c + rank_i(d)), rank from 1. Same as LangChain EnsembleRetriever."""
    weights = weights or [1.0] * len(ranked_lists)
    score, doc = {}, {}
    for w, lst in zip(weights, ranked_lists):
        for r, d in enumerate(lst, 1):
            kk = _key(d)
            doc.setdefault(kk, d)
            score[kk] = score.get(kk, 0.0) + w / (c + r)
    order = sorted(score, key=lambda kk: -score[kk])
    return [(doc[kk], score[kk]) for kk in order[:top]]


class Hybrid(ListRetriever):
    def __init__(self, retrievers, weights, k=5, c=60):
        self.rs, self.w, self.k, self.c = list(retrievers), list(weights), k, c
    def scored(self, query):
        return rrf_fuse([r.invoke(query) for r in self.rs], self.w, self.c, top=self.k)
    def invoke(self, query):
        return [d for d, _ in self.scored(query)]


def hybrid(bm25, dense, weights=(0.4, 0.6), k=5):
    """BM25 + dense fused with RRF (weights = (bm25, dense)). In Colab you can use
    langchain.retrievers.EnsembleRetriever(retrievers=[bm25, dense], weights=[0.4, 0.6]) — same maths."""
    return Hybrid([bm25, dense], weights, k=k)


# ---------------------------------------------------------------- Part 3 · multi-query, parent, self-query, re-rank (CP113)
import json as _json
from tenderyar.rag.clean import search_normalize as _sn
from tenderyar.rag.metrics import msg_text

MQ_PROMPT = """شما دستیار جستجو در اسناد مناقصه هستید. سؤال زیر را به {n} شکل متفاوت (با واژه‌های هم‌معنی) بازنویسی کنید.
هر بازنویسی را در یک خط جداگانه و بدون شماره بنویسید.
سؤال: {question}"""

SYNONYMS = [("جریمه", "جرایم"), ("تاخیر", "دیرکرد"), ("تضمین", "ضمانتنامه"), ("مهلت", "آخرین فرصت"),
            ("مدت", "زمان"), ("مبلغ", "مقدار"), ("پیشپرداخت", "پیش پرداخت"), ("مدارک", "اسناد"),
            ("کارفرما", "دستگاه مناقصهگزار"), ("قرارداد", "پیمان"), ("پیمانکار", "شرکت کننده"), ("سقف", "حداکثر")]


def offline_paraphrases(question, n=3):
    """Keyless stand-in for Gemini: swap known synonyms (both directions) -> up to n variants."""
    q = _sn(question)
    out = []
    for a, b in SYNONYMS:
        for x, y in ((a, b), (b, a)):
            if x in q and len(out) < n:
                v = q.replace(x, y)
                if v not in out and v != q:
                    out.append(v)
    return out[:n]


def paraphrases(question, llm=None, n=3):
    if llm is None:
        return offline_paraphrases(question, n)
    txt = msg_text(llm.invoke(MQ_PROMPT.format(n=n, question=question)))
    lines = [l.strip(" -•\t0123456789.") for l in txt.splitlines()]
    return [l for l in lines if len(l) > 3][:n]


class MultiQuery(ListRetriever):
    """Original + n paraphrases -> base retriever each -> RRF union (LangChain MultiQueryRetriever uses a plain union)."""
    def __init__(self, base, llm=None, n=3, k=5):
        self.base, self.llm, self.n, self.k = base, llm, n, k
        self.last_queries = []
    def scored(self, query):
        self.last_queries = [query] + paraphrases(query, self.llm, self.n)
        return rrf_fuse([self.base.invoke(q) for q in self.last_queries], top=self.k)
    def invoke(self, query):
        return [d for d, _ in self.scored(query)]


def multi_query(base, llm=None, n=3, k=5):
    return MultiQuery(base, llm, n, k)


_ARTICLE = re.compile(r"^\s*ماده\s*[0-9۰-۹]+")


def split_articles(page_doc):
    """One page -> parents: the page heading block + one parent per «ماده N …» (until the next ماده)."""
    from langchain_core.documents import Document
    parts, cur = [], []
    for line in page_doc.page_content.splitlines():
        if _ARTICLE.match(line) and cur:
            parts.append(cur); cur = []
        cur.append(line)
    if cur:
        parts.append(cur)
    out = []
    for j, p in enumerate(parts):
        txt = "\n".join(p).strip()
        if txt:
            m = dict(page_doc.metadata)
            m["parent_id"] = f"{m.get('source', 'doc')}:p{m.get('page')}:a{j}"
            m["chunk_id"] = m["parent_id"]
            out.append(Document(page_content=txt, metadata=m))
    return out


class ParentRetriever(ListRetriever):
    """Search small children (precise), return their parent article (complete)."""
    def __init__(self, page_docs, make_base=None, child_size=300, overlap=40, k=5):
        from tenderyar.rag.splitter import persian_splitter
        self.parents, self.children, self.k = {}, [], k
        sp = persian_splitter(child_size, overlap)
        for d in page_docs:
            for p in split_articles(d):
                self.parents[p.metadata["parent_id"]] = p
                for i, c in enumerate(sp.split_documents([p])):
                    c.metadata["chunk_id"] = f"{p.metadata['parent_id']}:c{i}"
                    self.children.append(c)
        self.base = (make_base or (lambda ch: BM25(ch, k=4 * k)))(self.children)
    def invoke(self, query):
        out, seen = [], set()
        for c in self.base.invoke(query):
            pid = c.metadata["parent_id"]
            if pid not in seen:
                seen.add(pid); out.append(self.parents[pid])
        return out[: self.k]


def parent_retriever(docs, make_base=None, child_size=300, k=5):
    return ParentRetriever(docs, make_base, child_size, k=k)


PROVINCES = ["آذربایجان شرقی", "آذربایجان غربی", "اصفهان", "بوشهر", "تهران", "خراسان رضوی", "خوزستان", "فارس", "مازندران",
             "کرمانشاه", "کرمان", "گیلان", "یزد", "قم", "البرز", "هرمزگان", "سیستان و بلوچستان", "همدان", "قزوین"]
CATEGORY_HINTS = {"راه و ساختمان": ["راهسازی", "راه سازی", "آسفالت", "جاده", "محور", "پل"], "آب": ["آب", "فاضلاب", "مخزن"],
                  "برق و انرژی": ["برق", "کنتور", "کیلوولت"], "نفت و گاز": ["گاز", "نفت", "پالایش"],
                  "فناوری اطلاعات": ["سامانه", "نرم افزار", "شبکه"], "خدمات": ["نظافت", "نگهداری", "خدمات"]}

SQ_PROMPT = """از سؤال زیر فیلترهای جستجو را استخراج کن و فقط JSON برگردان با کلیدهای
"query" (بخش معنایی)، "province" (یکی از استان‌های ایران یا null)، "category" (یکی از {cats} یا null).
تاریخ‌ها را نادیده بگیر (جداگانه پردازش می‌شوند).
سؤال: {question}"""


class SelfQuery(ListRetriever):
    """question -> (semantic query, Chroma where). Dates: our Jalali pre-parser (never the LLM).
    province/category: LLM JSON (Colab) or keyword rules (offline)."""
    def __init__(self, vs, llm=None, k=5, embeddings=None, today=None):
        self.vs, self.llm, self.k, self.emb, self.today = vs, llm, k, embeddings, today

    def structured(self, question):
        date_where, rest = jalali_filter(question, today=self.today)
        prov = cat = None
        q = _sn(rest)
        if self.llm is not None:
            from tenderyar.library.categories import CATEGORIES
            txt = msg_text(self.llm.invoke(SQ_PROMPT.format(cats="، ".join(CATEGORIES), question=rest)))
            try:
                js = _json.loads(txt[txt.index("{"): txt.rindex("}") + 1])
                prov, cat, q = js.get("province"), js.get("category"), js.get("query") or q
            except ValueError:
                pass
        else:
            for p in PROVINCES:
                if p in q:
                    prov = p; q = q.replace(p, " "); break
            words = set(q.split())
            for c, hints in CATEGORY_HINTS.items():
                if any((h in q) if " " in h else (h in words) for h in hints):
                    cat = c; break
            q = re.sub(r"\b(استان|مناقصه ها ی|مناقصه های|مناقصه ها|با|مهلت)\b", " ", q)
        conds = [{"province": {"$eq": prov}}] if prov else []
        conds += [{"category": {"$eq": cat}}] if cat else []
        if date_where:
            conds += date_where["$and"] if "$and" in date_where else [date_where]
        where = None if not conds else conds[0] if len(conds) == 1 else {"$and": conds}
        return {"query": re.sub(r"\s+", " ", q).strip() or "مناقصه", "filter": where}

    def invoke(self, question):
        s = self.structured(question)
        if hasattr(self.vs, "similarity_search"):
            return self.vs.similarity_search(s["query"], k=self.k, filter=s["filter"])
        from tenderyar.library.search import search
        return search(self.vs, self.emb, s["query"], where=s["filter"], k=self.k)


LLM_DATE_PROMPT = """Turn the date condition of this Persian question into a Chroma filter on deadline_ts
(Unix seconds, 00:00 UTC). Today is {today} (Jalali). Return ONLY JSON like {{"deadline_ts": {{"$lt": 1790000000}}}}.
Question: {question}"""


def naive_date_filter(question: str):
    """What goes wrong WITHOUT the pre-parser (offline stand-in for 'LLM alone'):
    the digits of «۱۵ آبان ۱۴۰۵» are read as a Gregorian day (Aban = month 8 -> 15 Aug 1405 AD!)."""
    q = to_latin_digits(question)
    m = re.search(r"(\d{1,2})\s+([^\s\d]+)(?:\s+(1[34]\d\d))?", q)
    if not m:
        return None
    months = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
    if m.group(2) not in months:
        return None
    y = int(m.group(3) or 1405)
    ts = int(datetime(y, months.index(m.group(2)) + 1, int(m.group(1)), tzinfo=timezone.utc).timestamp())
    return {"deadline_ts": {"$lt": ts}}


def llm_date_filter(question: str, llm=None, today: str = None):
    """Ask the LLM ALONE for the deadline_ts filter (to compare with jalali_filter). Offline -> naive_date_filter."""
    if llm is None:
        return naive_date_filter(question)
    txt = msg_text(llm.invoke(LLM_DATE_PROMPT.format(today=today or EVAL_TODAY, question=question)))
    try:
        return _json.loads(txt[txt.index("{"): txt.rindex("}") + 1])
    except ValueError:
        return None


def self_query(vs, llm=None, k=5, embeddings=None, today=None):
    return SelfQuery(vs, llm, k, embeddings, today)


class OverlapReranker:
    """Keyless stand-in for a cross-encoder: reads query+passage TOGETHER (token overlap + bigram overlap + 3-gram Jaccard)."""
    def _grams(self, t):
        t = _sn(t).replace(" ", "")
        return {t[i:i + 3] for i in range(max(0, len(t) - 2))}
    def score(self, query, text):
        q, d = _tokens(query), set(_tokens(text))
        if not q:
            return 0.0
        uni = sum(t in d for t in q) / len(q)
        qb = {a + " " + b for a, b in zip(q, q[1:])}
        dt = _tokens(text); db = {a + " " + b for a, b in zip(dt, dt[1:])}
        bi = len(qb & db) / len(qb) if qb else 0.0
        gq, gd = self._grams(query), self._grams(text)
        jac = len(gq & gd) / len(gq | gd) if gq | gd else 0.0
        return uni + 0.5 * bi + jac
    def predict(self, pairs):
        return [self.score(q, t) for q, t in pairs]


RERANK_MODEL = "BAAI/bge-reranker-v2-m3"


def get_reranker(model=None):
    if model in (None, "offline"):
        return OverlapReranker()
    from sentence_transformers import CrossEncoder   # Colab: pip install sentence-transformers (GPU recommended)
    return CrossEncoder(model, max_length=512)


def rerank(docs, query, top_n=5, model=None, reranker=None):
    """Score (query, passage) pairs jointly and keep the best top_n."""
    rr = reranker or get_reranker(model)
    s = rr.predict([(query, d.page_content) for d in docs])
    order = sorted(range(len(docs)), key=lambda i: -float(s[i]))
    return [docs[i] for i in order[:top_n]]


class Reranked(ListRetriever):
    def __init__(self, base, top_n=5, reranker=None):
        self.base, self.k, self.rr = base, top_n, reranker or OverlapReranker()
    def invoke(self, query):
        return rerank(self.base.invoke(query), query, self.k, reranker=self.rr)
