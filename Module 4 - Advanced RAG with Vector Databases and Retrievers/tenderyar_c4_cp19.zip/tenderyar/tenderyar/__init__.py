"""TenderYar (مناقصه‌یار) — Persian tender assistant. v0.1 = notice -> TenderCard JSON."""
__version__ = "0.1.0"
