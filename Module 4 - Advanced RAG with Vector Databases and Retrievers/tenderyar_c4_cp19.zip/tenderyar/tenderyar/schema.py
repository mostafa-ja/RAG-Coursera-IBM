"""TenderCard — the structured output of TenderYar v0.1 (Pydantic v2)."""
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator

from .jalali import jalali_str_to_iso, parse_jalali, format_jalali
from .money import parse_amount

TenderType = Literal["مناقصه عمومی", "مناقصه محدود", "مزایده", "استعلام", "فراخوان ارزیابی کیفی", "نامشخص"]


class TenderCard(BaseModel):
    """One tender notice -> one card. Keep Persian values in Persian; numbers as ints."""
    organization: Optional[str] = Field(None, description="نام دستگاه مناقصه‌گزار، مثل «شرکت آب و فاضلاب استان اصفهان»")
    subject: Optional[str] = Field(None, description="موضوع مناقصه در یک جمله کوتاه")
    tender_number: Optional[str] = Field(None, description="شماره مناقصه یا شماره فراخوان در سامانه ستاد، دقیقاً همان‌طور که نوشته شده")
    tender_type: TenderType = Field("نامشخص", description="نوع فراخوان")
    province: Optional[str] = Field(None, description="استان محل اجرای کار، بدون کلمه «استان»")
    city: Optional[str] = Field(None, description="شهر محل اجرا در صورت ذکر")
    category: Optional[str] = Field(None, description="یکی از: عمرانی، تاسیسات، راه و ساختمان، آب، برق و انرژی، نفت و گاز، فناوری اطلاعات، تجهیزات و کالا، خدمات، سایر")
    deadline_jalali: Optional[str] = Field(None, description="آخرین مهلت ارسال/تحویل پیشنهاد به شمسی، قالب YYYY/MM/DD")
    deadline_time: Optional[str] = Field(None, description="ساعت مهلت، قالب HH:MM")
    deadline_iso: Optional[str] = Field(None, description="همان مهلت به میلادی YYYY-MM-DD (کد آن را حساب می‌کند)")
    opening_jalali: Optional[str] = Field(None, description="تاریخ بازگشایی پاکات به شمسی YYYY/MM/DD")
    bond_amount_rial: Optional[int] = Field(None, description="مبلغ تضمین شرکت در فرآیند ارجاع کار به ریال (عدد صحیح). اگر تومان بود ×۱۰")
    bond_types: List[str] = Field(default_factory=list, description="انواع تضمین قابل قبول، مثل ضمانت‌نامه بانکی، واریز نقدی، اوراق مشارکت")
    estimate_rial: Optional[int] = Field(None, description="مبلغ برآورد اولیه به ریال اگر ذکر شده")
    required_grade: Optional[str] = Field(None, description="رتبه/صلاحیت لازم، مثل «حداقل رتبه ۵ رشته آب»")
    document_fee_rial: Optional[int] = Field(None, description="بهای اسناد به ریال")
    contact_phone: Optional[str] = Field(None, description="تلفن تماس")
    evidence: List[str] = Field(default_factory=list, description="عبارت‌های عینی از متن که مهلت و مبلغ تضمین از آن‌ها برداشته شده")

    @field_validator("deadline_jalali", "opening_jalali", mode="before")
    @classmethod
    def _norm_jalali(cls, v):
        if not v:
            return None
        p = parse_jalali(str(v))
        return format_jalali(*p) if p else None

    @field_validator("bond_amount_rial", "estimate_rial", "document_fee_rial", mode="before")
    @classmethod
    def _money(cls, v):
        if v is None or v == "":
            return None
        if isinstance(v, (int, float)):
            return int(v)
        return parse_amount(str(v))

    @field_validator("province", mode="before")
    @classmethod
    def _prov(cls, v):
        return v.replace("استان", "").strip() if isinstance(v, str) else v

    def fill_computed(self) -> "TenderCard":
        """Compute fields that code does better than an LLM (dates)."""
        if self.deadline_jalali:
            self.deadline_iso = jalali_str_to_iso(self.deadline_jalali)
        return self


# Fields that are scored in evaluation live in ONE place: tenderyar/evaluate.py (FIELDS).
# subject/city/evidence/contact are extracted but not scored in v0.1 (no gold labels yet).
