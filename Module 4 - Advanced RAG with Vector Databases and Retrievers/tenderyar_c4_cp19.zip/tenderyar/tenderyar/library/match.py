"""Company profile -> ranked tenders. Stage 1 = hard rules (with Persian reasons), stage 2 = soft score
score = 0.6·semantic + 0.2·deadline_room + 0.2·bond_fit."""
from ..normalize import normalize, to_persian_digits
from .cards import jalali_to_ts, parse_grade, EVAL_TODAY
from .search import search

W = (0.6, 0.2, 0.2)
DAY = 86400


def _fa(x):
    return to_persian_digits(str(x))


def _bn(rial):  # 3200000000 -> '۳٫۲ میلیارد ریال'
    s = f"{rial / 1e9:.1f}".rstrip("0").rstrip(".")
    return _fa(s).replace(".", "٫") + " میلیارد ریال"


def profile_text(p):
    return normalize(f"{p['name']} {' '.join(p['fields'])} {p.get('about', '')}")


def hard_filter(profile, card, today=EVAL_TODAY):
    """-> (ok, reasons_fa). Grade: Iranian rank 1 is best, so a company with rank g may bid if g <= required level."""
    ok, why = True, []
    prov = card.get("province")
    if profile.get("provinces") and prov not in profile["provinces"]:
        ok = False; why.append(f"استان {prov} در محدوده کاری شرکت نیست")
    if profile.get("fields") and card.get("category") not in profile["fields"]:
        ok = False; why.append(f"دسته «{card.get('category')}» جزو زمینه‌های شرکت نیست")
    field, level = parse_grade(card.get("required_grade"))
    if level:
        g = {normalize(k): v for k, v in profile.get("grade", {}).items()}.get(normalize(field))
        if g is None:
            ok = False; why.append(f"شرکت رتبه {field} ندارد")
        elif g > level:
            ok = False; why.append(f"رتبه شرکت ({_fa(g)}) پایین‌تر از رتبه لازم ({_fa(level)}) است")
        else:
            why.append("رتبه کافی است")
    dl, now = jalali_to_ts(card.get("deadline_jalali")), jalali_to_ts(today)
    if dl is None or dl < now:
        ok = False; why.append("مهلت گذشته است")
    else:
        why.append(f"{_fa((dl - now) // DAY)} روز تا مهلت")
    bond, cap = int(card.get("bond_amount_rial") or 0), profile.get("max_bond_rial")
    if cap and bond > cap:
        ok = False; why.append(f"تضمین {_bn(bond)} بیشتر از سقف است")
    elif cap:
        why.append(f"تضمین {_bn(bond)} کمتر از سقف")
    return ok, why


def soft_score(sem, card, profile, today=EVAL_TODAY):
    days = max(0, (jalali_to_ts(card.get("deadline_jalali")) - jalali_to_ts(today)) // DAY)
    room = min(days, 30) / 30
    cap = profile.get("max_bond_rial") or 1
    fit = max(0.0, 1 - int(card.get("bond_amount_rial") or 0) / cap)
    return W[0] * sem + W[1] * room + W[2] * fit


def match(profile, coll, embeddings, cards, k=5, variant="full", today=EVAL_TODAY):
    """variant: 'semantic' (vector only) | 'filter' (hard rules + semantic) | 'full' (hard rules + weighted score)."""
    by_id = {c["id"]: c for c in cards}
    hits = search(coll, embeddings, profile_text(profile), k=len(by_id))
    rows = []
    for h in hits:
        c = by_id.get(h["tender_id"])
        if c is None:
            continue
        ok, why = hard_filter(profile, c, today)
        if variant != "semantic" and not ok:
            continue
        s = soft_score(h["sim"], c, profile, today) if variant == "full" else h["sim"]
        rows.append({"tender_id": c["id"], "score": round(s, 4), "sim": h["sim"], "reasons_fa": "؛ ".join(why), "ok": ok})
    rows.sort(key=lambda r: -r["score"])
    return rows[:k]


def precision_at_k(pred_ids, relevant, k=5):
    return sum(1 for t in pred_ids[:k] if t in relevant) / k
