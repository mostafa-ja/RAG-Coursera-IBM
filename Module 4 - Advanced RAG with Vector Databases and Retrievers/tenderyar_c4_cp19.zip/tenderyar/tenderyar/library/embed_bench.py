"""Embedding leaderboard: recall@1 / recall@5 on query–passage pairs + ms per embedding."""
import time
import numpy as np


def bench(models: dict, pairs: list):
    """models = {name: LangChain Embeddings}; pairs = [{'query','passage'}]. Each query must find its own passage."""
    import pandas as pd
    rows = []
    passages = [p["passage"] for p in pairs]
    for name, emb in models.items():
        t0 = time.perf_counter()
        P = np.array(emb.embed_documents(passages)); Q = np.array([emb.embed_query(p["query"]) for p in pairs])
        ms = (time.perf_counter() - t0) * 1000 / (2 * len(pairs))
        P /= np.linalg.norm(P, axis=1, keepdims=True); Q /= np.linalg.norm(Q, axis=1, keepdims=True)
        rank = np.argsort(-(Q @ P.T), axis=1)
        r1 = float(np.mean([rank[i, 0] == i for i in range(len(pairs))]))
        r5 = float(np.mean([i in rank[i, :5] for i in range(len(pairs))]))
        rows.append({"model": name, "recall@1": round(r1, 2), "recall@5": round(r5, 2), "ms/emb": round(ms, 2)})
    return pd.DataFrame(rows).sort_values(["recall@1", "recall@5"], ascending=False).reset_index(drop=True)


class STEmbeddings:
    """sentence-transformers model as a LangChain-like Embeddings (Tooka-SBERT, bge-m3) — Colab only."""
    def __init__(self, name):
        from sentence_transformers import SentenceTransformer
        self.m = SentenceTransformer(name)
    def embed_documents(self, texts): return self.m.encode(list(texts), normalize_embeddings=True).tolist()
    def embed_query(self, text): return self.m.encode([text], normalize_embeddings=True)[0].tolist()
