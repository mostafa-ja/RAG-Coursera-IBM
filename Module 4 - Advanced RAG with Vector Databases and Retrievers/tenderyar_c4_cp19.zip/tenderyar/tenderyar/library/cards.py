"""TenderCard dict -> flat Chroma metadata (only str/int/float/bool allowed by Chroma)."""
import re, json, pathlib
from datetime import datetime, timezone
from ..jalali import parse_jalali, jalali_to_gregorian
from ..normalize import normalize

EVAL_TODAY = "1405/08/20"  # fixed "today" for reproducible offline numbers (some synthetic deadlines are past)


def jalali_to_ts(text) -> int:
    """'1405/08/12' or '۱۵ آبان ۱۴۰۵' -> unix seconds (00:00 UTC of that day); None if unparsable."""
    p = parse_jalali(str(text)) if text else None
    if not p:
        return None
    g = jalali_to_gregorian(*p)
    return int(datetime(g.year, g.month, g.day, tzinfo=timezone.utc).timestamp())


def parse_grade(text):
    """'رتبه 4 ابنیه' / 'حداقل رتبه ۵ رشته آب' -> ('ابنیه', 4); None -> ('', 0) = no grade needed."""
    if not text:
        return "", 0
    t = normalize(str(text))
    m = re.search(r"رتبه\s*(\d)\s*(?:رشته\s*)?(.+)", t)
    if not m:
        return "", 0
    return m.group(2).strip(), int(m.group(1))


def card_meta(card: dict, source: str = "", page: int = 0) -> dict:
    field, level = parse_grade(card.get("required_grade"))
    return {"tender_id": card["id"], "province": card.get("province") or "", "category": card.get("category") or "",
            "org": card.get("organization") or "", "deadline_ts": jalali_to_ts(card.get("deadline_jalali")) or 0,
            "deadline_jalali": card.get("deadline_jalali") or "", "bond_rial": int(card.get("bond_amount_rial") or 0),
            "grade_field": field, "grade_level": level, "source": source or card["id"], "page": page}


def load_cards(path="data/cards.jsonl"):
    return [json.loads(l) for l in pathlib.Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]
