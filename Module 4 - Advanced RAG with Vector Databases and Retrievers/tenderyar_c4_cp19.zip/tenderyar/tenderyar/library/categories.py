"""Keyword classifier -> the v0.1 category list; optional LLM fallback when no keyword matches."""
from ..normalize import normalize

CATEGORIES = ["عمرانی", "تاسیسات", "راه و ساختمان", "آب", "برق و انرژی", "نفت و گاز", "فناوری اطلاعات", "تجهیزات و کالا", "خدمات", "سایر"]
KEYWORDS = [("فناوری اطلاعات", ["سامانه", "نرم‌افزار", "نرم افزار", "درگاه", "شبکه مدیریت", "مخابرات"]),
            ("نفت و گاز", ["گاز", "نفت", "تقلیل فشار", "پالایش"]),
            ("برق و انرژی", ["برق", "کنتور", "کیلوولت", "پست "]),
            ("آب", ["آب", "فاضلاب", "مخزن"]),
            ("راه و ساختمان", ["آسفالت", "محور", "پل ", "راه"]),
            ("تجهیزات و کالا", ["خرید", "دستگاه", "تجهیزات"]),
            ("عمرانی", ["احداث", "ساخت", "مدرسه", "پارک", "شهرداری"]),
            ("خدمات", ["خدمات", "نگهداری", "نظافت"])]


def classify(text: str, llm=None) -> str:
    t = normalize(text) + " "
    for cat, kws in KEYWORDS:
        if any(normalize(k) in t for k in kws):
            return cat
    if llm is not None:  # e.g. ChatGoogleGenerativeAI(model="gemini-3.5-flash-lite")
        ans = llm.invoke("فقط یکی از این دسته‌ها را برگردان: " + "، ".join(CATEGORIES) + "\n\nمتن: " + text[:1500]).content.strip()
        return ans if ans in CATEGORIES else "سایر"
    return "سایر"
