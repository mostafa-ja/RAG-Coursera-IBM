"""v0.3 · Course 3 — persistent Chroma tender library, metadata filters, company matching."""
