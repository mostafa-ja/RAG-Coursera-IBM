"""Metadata filters (Chroma where) + vector search, grouped by tender."""
from .cards import jalali_to_ts


def build_where(province=None, category=None, after=None, max_bond=None):
    """province/category: str or list -> $in ; after: Jalali text or unix int -> deadline_ts $gte ; max_bond -> $lte."""
    c = []
    for key, v in (("province", province), ("category", category)):
        if v:
            c.append({key: {"$in": list(v)}} if isinstance(v, (list, tuple, set)) else {key: {"$eq": v}})
    if after is not None:
        ts = after if isinstance(after, int) else jalali_to_ts(after)
        if ts is None:
            raise ValueError(f"cannot parse date: {after!r}")
        c.append({"deadline_ts": {"$gte": ts}})
    if max_bond is not None:
        c.append({"bond_rial": {"$lte": int(max_bond)}})
    return None if not c else c[0] if len(c) == 1 else {"$and": c}


def search(coll, embeddings, query, where=None, k=10):
    """-> list of tenders [{tender_id, sim, meta, snippet}] best chunk per tender, sim = 1 - cosine distance."""
    n = coll.count()
    if n == 0:
        return []
    r = coll.query(query_embeddings=[embeddings.embed_query(query)], n_results=min(n, k * 3), where=where,
                   include=["metadatas", "documents", "distances"])
    out, seen = [], set()
    for m, d, dist in zip(r["metadatas"][0], r["documents"][0], r["distances"][0]):
        if m["tender_id"] in seen:
            continue
        seen.add(m["tender_id"])
        out.append({"tender_id": m["tender_id"], "sim": round(1 - dist, 4), "meta": m, "snippet": d[:160]})
    return out[:k]
