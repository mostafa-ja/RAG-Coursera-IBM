"""Persistent Chroma library. Embeddings are computed by us (any LangChain Embeddings) and passed explicitly,
so the same code works with Gemini, Tooka-SBERT, bge-m3 or the offline HashEmbeddings."""
import collections
import chromadb
from .cards import card_meta

COLL = "tenders"


def get_client(path="chroma_db"):
    return chromadb.PersistentClient(path=path)


def get_collection(client, name=COLL):
    return client.get_or_create_collection(name, metadata={"hnsw:space": "cosine"}, embedding_function=None)


def upsert_tender(coll, card: dict, chunks, embeddings, source="", page=0):
    """chunks = list[str]. ids '{tender_id}:{chunk_id}' -> re-running is idempotent (same ids overwrite)."""
    tid = card["id"]
    ids = [f"{tid}:{i}" for i in range(len(chunks))]
    meta = card_meta(card, source, page)
    coll.upsert(ids=ids, documents=list(chunks), embeddings=embeddings.embed_documents(list(chunks)),
                metadatas=[dict(meta, chunk=i) for i in range(len(chunks))])
    return ids


def update_meta(coll, tender_id, **changes):
    """Change metadata of every chunk of one tender. A new deadline_jalali also refreshes deadline_ts
    (the field the filters use) — otherwise the filter would still see the old date."""
    if "deadline_jalali" in changes and "deadline_ts" not in changes:
        from .cards import jalali_to_ts
        changes["deadline_ts"] = jalali_to_ts(changes["deadline_jalali"])
    got = coll.get(where={"tender_id": tender_id})
    coll.update(ids=got["ids"], metadatas=[dict(m, **changes) for m in got["metadatas"]])
    return len(got["ids"])


def delete_tender(coll, tender_id):
    n = len(coll.get(where={"tender_id": tender_id})["ids"])
    coll.delete(where={"tender_id": tender_id})
    return n


def stats(coll):
    ms = coll.get(include=["metadatas"])["metadatas"]
    tenders = {m["tender_id"]: m for m in ms}
    return {"chunks": coll.count(), "tenders": len(tenders),
            "by_province": dict(collections.Counter(m["province"] for m in tenders.values()).most_common()),
            "by_category": dict(collections.Counter(m["category"] for m in tenders.values()).most_common())}
