"""Jalali (Solar Hijri) <-> Gregorian conversion + parsing Persian dates. No dependencies.

Algorithm: the well-known jdf/jalaali-js arithmetic (valid ~1-3000 AP).
Cross-check with `persiantools` or `jdatetime` in tests if installed.
"""
import re
from datetime import date

from .normalize import to_latin_digits

MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
          "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
_MONTH_ALIASES = {"امرداد": 5}


def jalali_to_gregorian(jy: int, jm: int, jd: int) -> date:
    jy += 1595
    days = -355668 + 365 * jy + (jy // 33) * 8 + ((jy % 33) + 3) // 4 + jd
    days += (jm - 1) * 31 if jm < 7 else (jm - 7) * 30 + 186
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        days -= 1
        gy += 100 * (days // 36524)
        days %= 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    sal = [0, 31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 1
    while gm <= 12 and gd > sal[gm]:
        gd -= sal[gm]
        gm += 1
    return date(gy, gm, gd)


def gregorian_to_jalali(g: date) -> tuple:
    gy, gm, gd = g.year, g.month, g.day
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100 + (gy2 + 399) // 400 + gd + g_d_m[gm - 1]
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm, jd = 1 + days // 31, 1 + days % 31
    else:
        jm, jd = 7 + (days - 186) // 30, 1 + (days - 186) % 30
    return jy, jm, jd


def is_valid_jalali(jy: int, jm: int, jd: int) -> bool:
    if not (1 <= jm <= 12 and jd >= 1):
        return False
    if jm <= 6:
        return jd <= 31
    if jm <= 11:
        return jd <= 30
    # Esfand: 30 days only in leap years -> check by round trip
    return jd <= 29 or gregorian_to_jalali(jalali_to_gregorian(jy, 12, 30)) == (jy, 12, 30)


_NUMERIC = re.compile(r"(1[34]\d\d|\d\d)\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})")
_TEXTUAL = re.compile(r"(\d{1,2})\s*(?:ام)?\s*(" + "|".join(MONTHS + list(_MONTH_ALIASES)) + r")\s*(?:ماه)?\s*(?:سال)?\s*(1[34]\d\d|\d\d)?")


def parse_jalali(text: str, default_year: int = None):
    """Find the first Jalali date in text. Returns (jy, jm, jd) or None.

    Handles '1405/07/21', '۱۴۰۵-۰۷-۲۱', '05/7/21', '21 مهر 1405', '۲۱ مهرماه'.
    Two-digit years are read as 14xx.
    """
    t = to_latin_digits(text).replace("ي", "ی")
    m = _NUMERIC.search(t)
    if m:
        y, mo, d = (int(x) for x in m.groups())
        if y < 100:
            y += 1400
        if is_valid_jalali(y, mo, d):
            return y, mo, d
    m = _TEXTUAL.search(t)
    if m:
        d = int(m.group(1))
        name = m.group(2)
        mo = MONTHS.index(name) + 1 if name in MONTHS else _MONTH_ALIASES[name]
        y = m.group(3)
        y = int(y) if y else default_year
        if y is not None and y < 100:
            y += 1400
        if y and is_valid_jalali(y, mo, d):
            return y, mo, d
    return None


def jalali_str_to_iso(text: str, default_year: int = None):
    """'۱۴۰۵/۰۷/۲۱' -> '2026-10-13' (or None)."""
    p = parse_jalali(text, default_year)
    return jalali_to_gregorian(*p).isoformat() if p else None


def format_jalali(jy: int, jm: int, jd: int) -> str:
    return f"{jy:04d}/{jm:02d}/{jd:02d}"
