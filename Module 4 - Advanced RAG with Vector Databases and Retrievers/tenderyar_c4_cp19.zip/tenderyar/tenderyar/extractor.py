"""TenderYar v0.1 extractor: normalise -> prompt -> Gemini -> Pydantic -> rule-based cross-check.

Course 1 mapping:  M1 prompt templates / CoT / self-consistency,
                   M2 LCEL chain, output parser, fallbacks, batch,
                   M3 model choice (see evaluate.py) + apps/.
"""
import json
import re
import time
from collections import Counter
from typing import List, Optional

from .jalali import format_jalali, parse_jalali
from .money import parse_amount
from .normalize import normalize
from .schema import TenderCard

DEFAULT_MODEL = "gemini-3.8-flash"
FALLBACK_MODEL = "gemini-2.5-flash"


# --------------------------------------------------------------------------- rules (no LLM)
_DEADLINE_HINT = re.compile(r"(آخرین\s*مهلت|مهلت\s*(?:ارسال|تحویل|ارائه|بارگذاری)|تا\s*ساعت)[^\n]{0,120}")
_BOND_HINT = re.compile(r"(تضمین|ضمانت\s*نامه|سپرده)[^\n]{0,140}")
_NUMBER = re.compile(r"شماره[^\n:\d]{0,30}[:：]?\s*(\d{6,20}|[\dآ-ی]{1,6}(?:/[\dآ-ی]{1,6}){1,3})")


def rule_extract(notice: str) -> dict:
    """Regex baseline. Fast, explainable; used to cross-check the LLM and as an offline fallback."""
    t = normalize(notice)
    out = {}
    for m in _DEADLINE_HINT.finditer(t):
        sentence = m.group(0)
        if "تمدید" in sentence:          # "قبلاً X بود، تا Y تمدید گردید" -> the LAST date is the valid one
            sentence = sentence[sentence.rfind("تا"):] if "تا" in sentence else sentence
        p = parse_jalali(sentence)
        if p:
            out["deadline_jalali"] = format_jalali(*p)
            break
    for m in _BOND_HINT.finditer(t):
        a = parse_amount(m.group(0).split("ریال")[0] + "ریال" if "ریال" in m.group(0) else m.group(0))
        if a and a >= 1_000_000:
            out["bond_amount_rial"] = a
            break
    m = _NUMBER.search(t)
    if m:
        out["tender_number"] = m.group(1).strip("/-")
    if "مزایده" in t[:200]:
        out["tender_type"] = "مزایده"
    elif "ارزیابی کیفی" in t[:300]:
        out["tender_type"] = "فراخوان ارزیابی کیفی"
    elif "استعلام" in t[:200]:
        out["tender_type"] = "استعلام"
    elif "محدود" in t[:200]:
        out["tender_type"] = "مناقصه محدود"
    elif "مناقصه" in t[:300]:
        out["tender_type"] = "مناقصه عمومی"
    m = re.search(r"استان\s+([آ-ی]+(?:\s(?:و|جنوبی|شمالی|رضوی|غربی|شرقی|بختیاری|بویراحمد|بلوچستان)(?:\s[آ-ی]+)?)?)", t)
    if m:
        out["province"] = m.group(1)
    return out


# --------------------------------------------------------------------------- LLM chain
def get_llm(model: str = DEFAULT_MODEL, temperature: float = 0.0):
    from langchain_google_genai import ChatGoogleGenerativeAI
    return ChatGoogleGenerativeAI(model=model, temperature=temperature, max_retries=2)


def build_chain(model: str = DEFAULT_MODEL, few_shot: bool = True, fallback: Optional[str] = FALLBACK_MODEL):
    """LCEL: {notice} -> prompt | llm | JsonOutputParser  (with an optional fallback model)."""
    from langchain_core.output_parsers import JsonOutputParser
    from .prompts import FEW_SHOT, ZERO_SHOT

    parser = JsonOutputParser(pydantic_object=TenderCard)
    prompt = (FEW_SHOT if few_shot else ZERO_SHOT).partial(format_instructions=parser.get_format_instructions())
    llm = get_llm(model)
    if fallback and fallback != model:
        llm = llm.with_fallbacks([get_llm(fallback)])
    return prompt | llm | parser


def _clean_json(raw):
    if isinstance(raw, dict):
        return raw
    s = str(raw).strip().strip("`")
    s = s[s.find("{"): s.rfind("}") + 1]
    return json.loads(s)


def postprocess(raw: dict, notice: str) -> TenderCard:
    """Validate with Pydantic, then let deterministic code override fields it is sure about."""
    raw = {k: v for k, v in _clean_json(raw).items() if k in TenderCard.model_fields}
    card = TenderCard(**raw)
    rules = rule_extract(notice)
    # code wins for the deadline when the LLM is missing it or produced an impossible date
    if rules.get("deadline_jalali") and not card.deadline_jalali:
        card.deadline_jalali = rules["deadline_jalali"]
    if rules.get("bond_amount_rial") and not card.bond_amount_rial:
        card.bond_amount_rial = rules["bond_amount_rial"]
    return card.fill_computed()


def extract(notice: str, chain=None, **kw) -> dict:
    """notice text -> {'card': {...}, 'seconds': float, 'ok': bool, 'error': str|None}"""
    chain = chain or build_chain(**kw)
    text = normalize(notice)
    t0 = time.time()
    try:
        raw = chain.invoke({"notice": text})
        card = postprocess(raw, text)
        return {"card": card.model_dump(), "seconds": round(time.time() - t0, 2), "ok": True, "error": None}
    except Exception as e:  # keep batch runs alive; the error is part of the result table
        rules = rule_extract(text)
        card = TenderCard(**rules).fill_computed()
        return {"card": card.model_dump(), "seconds": round(time.time() - t0, 2), "ok": False, "error": repr(e)[:300]}


def extract_batch(notices: List[str], chain=None, max_concurrency: int = 2, **kw) -> List[dict]:
    """LCEL chain.batch (Course 1 M2) with return_exceptions=True: one bad notice does not kill the run.
    Failed items fall back to the regex baseline, exactly like extract(). 'seconds' = batch time / n."""
    chain = chain or build_chain(**kw)
    texts = [normalize(n) for n in notices]
    t0 = time.time()
    raws = chain.batch([{"notice": t} for t in texts], config={"max_concurrency": max_concurrency},
                       return_exceptions=True)
    per_item = round((time.time() - t0) / max(len(texts), 1), 2)
    out = []
    for raw, text in zip(raws, texts):
        try:
            if isinstance(raw, Exception):
                raise raw
            card = postprocess(raw, text)
            out.append({"card": card.model_dump(), "seconds": per_item, "ok": True, "error": None})
        except Exception as e:
            card = TenderCard(**rule_extract(text)).fill_computed()
            out.append({"card": card.model_dump(), "seconds": per_item, "ok": False, "error": repr(e)[:300]})
    return out


# --------------------------------------------------------------------------- self-consistency
def deadline_self_consistency(notice: str, model: str = DEFAULT_MODEL, n: int = 5, temperature: float = 0.8) -> dict:
    """Ask n times at higher temperature; majority vote on the ANSWER line (Lesson: self-consistency)."""
    from langchain_core.output_parsers import StrOutputParser
    from .prompts import DEADLINE_SC
    chain = DEADLINE_SC | get_llm(model, temperature) | StrOutputParser()
    votes = []
    for _ in range(n):
        out = chain.invoke({"notice": normalize(notice)})
        m = re.search(r"ANSWER:\s*(\S+)", out)
        p = parse_jalali(m.group(1)) if m else None
        votes.append(format_jalali(*p) if p else "null")
    best, count = Counter(votes).most_common(1)[0]
    return {"answer": best, "agreement": count / n, "votes": votes}
