import json,shutil
from playwright.sync_api import sync_playwright
url='file:///data/work/tenderyar/html/RAG_C3_Guide_v1.html';out={}
with sync_playwright() as pw:
  b=pw.chromium.launch(executable_path=shutil.which('chromium'))
  def mk(vp):
    ctx=b.new_context(viewport=vp);p=ctx.new_page();errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
    p.route(__import__('re').compile(r'^https?:'),lambda r:r.abort());p.goto(url);p.wait_for_timeout(500);return ctx,p,errs
  ctx,p,errs=mk({'width':1280,'height':900})
  cbs=p.locator('.skt input[type=checkbox]');out['skInputs']=cbs.count()
  sk={'before':p.locator('#skprog').inner_text()}
  cbs.nth(0).scroll_into_view_if_needed()
  for i in (0,3,7): cbs.nth(i).check()
  sk['after']=p.locator('#skprog').inner_text();sk['stored']=p.evaluate('localStorage.c3m_sk9')
  p.reload();p.wait_for_timeout(400)
  sk['afterReload']=p.locator('#skprog').inner_text()
  sk['checkedAfterReload']=p.evaluate("[...document.querySelectorAll('.skt input')].filter(c=>c.checked).length");out['sk']=sk
  p.fill('#dbgq','dimension');p.wait_for_timeout(200)
  out['dbg']=p.evaluate("(()=>{const r=[...document.querySelectorAll('#dbgt tbody tr')];return [r.length,r.filter(x=>x.offsetParent!==null).length]})()")
  p.fill('#dbgq','')
  out['kitIds']=p.evaluate("[...document.querySelectorAll('#kit article')].map(a=>a.id)")
  out['navKit']=p.evaluate("[...document.querySelectorAll('nav a[href^=\"#kit\"], aside a[href^=\"#kit\"]')].length")
  def shot(prefix,ids):
    for i in ids:
      e=p.locator('#'+i)
      if e.count(): e.scroll_into_view_if_needed();p.wait_for_timeout(150);p.screenshot(path=f'/data/run106/{prefix}_{i}.png')
      else: out.setdefault('missing',[]).append(i)
  shot('light',['kit-skills','kit-p3','kit-p7'])
  p.evaluate("try{theme()}catch(e){}");p.wait_for_timeout(200)
  out['darkAttr']=p.evaluate("document.documentElement.className+'|'+document.body.className+'|'+(document.documentElement.dataset.theme||'')")
  shot('dark',['kit-p5','kit-debug','kit-proj'])
  out['errs']=errs;ctx.close()
  ctx,p,errs=mk({'width':420,'height':860});p.evaluate("try{theme()}catch(e){}")
  out['mobileSvgOverflow']=p.evaluate("(()=>{const W=document.documentElement.clientWidth;return [...document.querySelectorAll('#kit svg')].filter(s=>s.getBoundingClientRect().right>W+1).map(s=>s.closest('article')?.id)})()")
  out['mobilePageOverflow']=p.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
  shot('mobile',['kit-p2','kit-p6'])
  out['mobErrs']=errs;ctx.close();b.close()
print(json.dumps(out,indent=1,ensure_ascii=False))
