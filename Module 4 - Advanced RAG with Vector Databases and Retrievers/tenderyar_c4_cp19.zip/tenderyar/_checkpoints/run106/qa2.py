import shutil,re,sys
from playwright.sync_api import sync_playwright
with sync_playwright() as pw:
  b=pw.chromium.launch(executable_path=shutil.which('chromium'))
  for f in ['RAG_C3_Guide_v1.html','RAG_C3_Guide_input.html','RAG_C2_Guide_v1.html']:
    p=b.new_page(viewport={'width':420,'height':860});p.route(re.compile(r'^https?:'),lambda r:r.abort())
    p.goto('file:///data/work/tenderyar/html/'+f);p.wait_for_timeout(400)
    print(f,p.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth"),
      p.evaluate("(()=>{const W=document.documentElement.clientWidth;return [...document.querySelectorAll('body *')].filter(e=>{const r=e.getBoundingClientRect();return r.right>W+1&&r.width>0&&getComputedStyle(e).position!=='fixed'}).slice(0,6).map(e=>e.tagName+'#'+e.id+'.'+e.className+' '+Math.round(e.getBoundingClientRect().right)+' in '+(e.closest('[id]')?.id))})()"))
    if f.endswith('v1.html') and 'C3' in f:
      p.fill('#dbgq','dimension');p.wait_for_timeout(200)
      print(p.evaluate("[...document.querySelectorAll('#dbgt tbody tr')].filter(x=>x.offsetParent!==null).map(x=>x.innerText.slice(0,80))"))
    p.close()
  b.close()
