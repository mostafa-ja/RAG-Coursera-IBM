# P6 cell A
import json, collections
foods = json.load(open("FoodDataSet.json"))                        # from the 2.4 lab (wget cell)
dup = [k for k, n in collections.Counter(str(f["food_id"]) for f in foods).items() if n > 1]
print("rows", len(foods), "duplicate food_id", len(dup), dup)

def doc(f):
    return (f"{f['food_name']}. {f['food_description']} Ingredients: {', '.join(f['food_ingredients'])}. "
            f"Cuisine: {f['cuisine_type']}. Method: {f['cooking_method']}. Taste: {f['food_features'].get('taste', '')}.")

ids, docs, metas, seen = [], [], [], collections.Counter()
for f in foods:
    base = str(f["food_id"]); seen[base] += 1
    ids.append(base if seen[base] == 1 else f"{base}#{seen[base]}")   # keep duplicates distinct
    docs.append(doc(f))
    metas.append({"name": f["food_name"].strip(), "cuisine": f["cuisine_type"],
                  "calories": int(f["food_calories_per_serving"]),       # int, so $lte works (P4)
                  "ingredients": ", ".join(i.lower() for i in f["food_ingredients"])})
coll = client.get_or_create_collection("food_" + MODE, embedding_function=ef,
                                       configuration={"hnsw": {"space": "cosine"}})
for i in range(0, len(ids), 100):                                  # batches of ≤ 100 (Gemini ef limit)
    coll.upsert(ids=ids[i:i + 100], documents=docs[i:i + 100], metadatas=metas[i:i + 100])
print("count", coll.count())
# P7 A
# after P6 Cell A (coll = food_{MODE}, 185 dishes, cosine)
def retrieve(question, k=3, max_dist=0.70, where=None):
    r = coll.query(query_texts=[question], n_results=k, where=where,
                   include=["documents", "metadatas", "distances"])
    hits = [{"id": i, "doc": d, "meta": m, "dist": round(x, 3)}
            for i, d, m, x in zip(r["ids"][0], r["documents"][0], r["metadatas"][0], r["distances"][0])]
    kept = [h for h in hits if h["dist"] <= max_dist]                 # weak hits never reach the LLM
    return kept, hits

def build_context(hits):
    return "\n".join(f"[{h['id']}] {h['meta']['name']} ({h['meta']['cuisine']}, {h['meta']['calories']} kcal): "
                     f"{h['doc'][:160]}" for h in hits)

PROMPT = """You are a food assistant. Answer ONLY from the CONTEXT.
Cite every dish you mention with its id in square brackets, e.g. [pizza_1].
If the CONTEXT does not contain the answer, reply exactly: NOT_FOUND
CONTEXT:
{context}
QUESTION: {question}
ANSWER:"""

for q in ["a light vegetarian curry with lentils", "spicy Indian chicken dish", "how do I fix my car battery?"]:
    kept, hits = retrieve(q)
    print(q, "->", [(h["id"], h["dist"]) for h in hits], "kept", len(kept))
q = "spicy Indian chicken dish"
print(PROMPT.format(context=build_context(retrieve(q)[0]), question=q)[:700])
# P7 B
import re
def offline_answer(question, kept):                                   # deterministic stand-in for the LLM
    if not kept: return "NOT_FOUND"
    top = kept[0]
    return f"Try {top['meta']['name']} [{top['id']}] ({top['meta']['calories']} kcal)."

def check_citations(answer, kept):
    cited = set(re.findall(r"\[([^\]]+)\]", answer)); allowed = {h["id"] for h in kept}
    return {"cited": sorted(cited), "unknown": sorted(cited - allowed),
            "ok": answer == "NOT_FOUND" or (bool(cited) and cited <= allowed)}

def rag(question, llm=offline_answer, **kw):
    kept, _ = retrieve(question, **kw)
    if not kept: return {"answer": "NOT_FOUND", "sources": [], "cited": [], "unknown": [], "ok": True}   # no LLM call
    ans = llm(question, kept)
    return {"answer": ans, "sources": [h["id"] for h in kept], **check_citations(ans, kept)}

for q in ["spicy Indian chicken dish", "how do I fix my car battery?"]: print(rag(q))
print(check_citations("Try Butter Chicken [chicken_99].", retrieve("spicy Indian chicken dish")[0]))
print(rag("spicy Indian chicken dish", where={"calories": {"$lte": 300}}))   # rule first (P4/P6)

# needs key: the real generator (Colab, GOOGLE_API_KEY)
# from google import genai; g = genai.Client()
# def gemini_answer(q, kept):
#     return g.models.generate_content(model="gemini-2.5-flash",
#         contents=PROMPT.format(context=build_context(kept), question=q)).text.strip()
# print(rag("spicy Indian chicken dish", llm=gemini_answer))
