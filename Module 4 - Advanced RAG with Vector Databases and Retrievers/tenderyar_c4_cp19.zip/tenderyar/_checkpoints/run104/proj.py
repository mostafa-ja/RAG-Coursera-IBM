import sys, json, re, shutil, chromadb
sys.path.insert(0,"/data/work/tenderyar")
from chromadb import Documents, EmbeddingFunction, Embeddings
from tenderyar.rag.index import HashEmbeddings
class LCEmbeddingFunction(EmbeddingFunction):
    def __init__(self, lc): self.lc = lc
    def __call__(self, input: Documents) -> Embeddings: return self.lc.embed_documents(list(input))
    @staticmethod
    def name(): return "langchain-wrapper"
    def get_config(self): return {}
    @staticmethod
    def build_from_config(c): return LCEmbeddingFunction(HashEmbeddings())
ef = LCEmbeddingFunction(HashEmbeddings())
D = json.load(open("course_data.json"))
# ---- M1 grocery search (persistent)
shutil.rmtree("/tmp/m1db", ignore_errors=True)
def build():
    cl = chromadb.PersistentClient(path="/tmp/m1db")
    co = cl.get_or_create_collection("grocery_offline", embedding_function=ef, configuration={"hnsw":{"space":"cosine"}})
    co.upsert(ids=[f"food_{i+1}" for i in range(len(D["grocery"]))], documents=D["grocery"])
    return co
co = build(); co = build()
print("M1 count after 2 runs", co.count())
for q in ["red apple", "bread for breakfast", "car battery"]:
    r = co.query(query_texts=[q], n_results=3)
    print("M1", q, [(i,d,round(1-x,3)) for i,d,x in zip(r["ids"][0], r["documents"][0], r["distances"][0])])
co2 = chromadb.PersistentClient(path="/tmp/m1db").get_collection("grocery_offline", embedding_function=ef)
print("M1 reopen", co2.count())
# ---- M2 employee finder
cl = chromadb.EphemeralClient()
emp = cl.get_or_create_collection("employees_offline", embedding_function=ef, configuration={"hnsw":{"space":"cosine"}})
E_ = D["employees"]
emp.upsert(ids=[e["id"] for e in E_],
  documents=[f"{e['role']} with {e['experience']} years of experience in {e['department']}. Skills: {e['skills']}. Located in {e['location']}. Employment type: {e['employment_type']}." for e in E_],
  metadatas=[{k:e[k] for k in ("name","experience","department","role","location","employment_type")} for e in E_])
print("M2 depts", sorted({e['department'] for e in E_}), "locs", sorted({e['location'] for e in E_}))
q="Python developer"
r=emp.query(query_texts=[q], n_results=3)
print("M2 semantic", [(i,m["department"],m["experience"]) for i,m in zip(r["ids"][0],r["metadatas"][0])])
w={"$and":[{"department":"Engineering"},{"experience":{"$gte":5}}]}
r=emp.query(query_texts=[q], n_results=3, where=w)
print("M2 where", [(i,m["name"],m["department"],m["experience"]) for i,m in zip(r["ids"][0],r["metadatas"][0])])
w2={"$and":[{"department":"Engineering"},{"experience":{"$gte":30}}]}
print("M2 strict", emp.query(query_texts=[q], n_results=3, where=w2)["ids"])
w3={"$or":[{"location":"San Francisco"},{"location":"Seattle"}]}
print("M2 or", emp.get(where=w3)["ids"])
# ---- M3 book recommender
B = D["books"]
bk = cl.get_or_create_collection("books_offline", embedding_function=ef, configuration={"hnsw":{"space":"cosine"}})
bk.upsert(ids=[b["id"] for b in B], documents=[f"{b['title']} by {b['author']}. {b['description']}. Themes: {b['themes']}. Setting: {b['setting']}." for b in B],
  metadatas=[{k:b[k] for k in ("title","author","genre","year","rating","pages")} for b in B])
print("M3 books", [(b["id"],b["title"],b["genre"],b["rating"]) for b in B])
def recommend(book_id, k=3, min_rating=None):
    me = bk.get(ids=[book_id], include=["documents","metadatas"])
    where = {"rating":{"$gte":min_rating}} if min_rating else None
    r = bk.query(query_texts=me["documents"], n_results=k+1, where=where)
    out=[]
    for i,m,d in zip(r["ids"][0], r["metadatas"][0], r["distances"][0]):
        if i==book_id: continue
        why = "same genre" if m["genre"]==me["metadatas"][0]["genre"] else "similar description"
        out.append((i, m["title"], round(1-d,3), why))
    return out[:k]
print("M3 like book_3", recommend("book_3"))
print("M3 like book_3 rating>=4.2", recommend("book_3", min_rating=4.2))
