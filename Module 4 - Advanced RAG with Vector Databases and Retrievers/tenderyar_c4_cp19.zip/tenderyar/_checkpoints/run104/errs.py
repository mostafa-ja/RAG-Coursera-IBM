import sys, warnings, chromadb, numpy as np
sys.path.insert(0,"/data/work/tenderyar")
from chromadb import Documents, EmbeddingFunction, Embeddings
from tenderyar.rag.index import HashEmbeddings
class LCEmbeddingFunction(EmbeddingFunction):
    def __init__(self, lc): self.lc = lc
    def __call__(self, input: Documents) -> Embeddings: return self.lc.embed_documents(list(input))
    @staticmethod
    def name(): return "langchain-wrapper"
ef = LCEmbeddingFunction(HashEmbeddings())
c = chromadb.EphemeralClient()
def t(label, f):
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        try: r=f(); print(f"[{label}] OK ->", repr(r)[:200])
        except Exception as e: print(f"[{label}] {type(e).__name__}: {str(e)[:220]}")
        for x in w: print(f"   warn: {str(x.message)[:200]}")
t("name<3", lambda: c.create_collection("ab"))
t("get missing", lambda: c.get_collection("nope"))
co = c.get_or_create_collection("dbg", embedding_function=ef, metadata={"hnsw:space":"cosine"})
co.add(ids=["a","b","c"], documents=["apple pie","banana bread","carrot cake"])
t("create twice", lambda: c.create_collection("dbg", embedding_function=ef))
t("add dup id existing", lambda: (co.add(ids=["a"], documents=["NEW"]), co.get(ids=["a"])["documents"]))
t("dup ids in batch", lambda: co.upsert(ids=["x","x"], documents=["1","2"]))
t("int ids", lambda: co.add(ids=[1], documents=["z"]))
t("n_results>count", lambda: co.query(query_texts=["apple"], n_results=10)["ids"])
t("lists of lists", lambda: co.query(query_texts=["apple"], n_results=1)["ids"])
t("wrong dim query", lambda: co.query(query_embeddings=[[0.1]*32], n_results=1))
t("wrong dim add", lambda: co.add(ids=["w"], embeddings=[[0.1]*32], documents=["w"]))
t("meta None", lambda: co.upsert(ids=["m1"], documents=["m"], metadatas=[{"k": None}]))
t("meta dict", lambda: co.upsert(ids=["m2"], documents=["m"], metadatas=[{"k": {"a":1}}]))
t("meta list", lambda: co.upsert(ids=["m3"], documents=["m"], metadatas=[{"k": [1,2]}]))
t("meta empty", lambda: co.upsert(ids=["m4"], documents=["m"], metadatas=[{}]))
t("where 2 keys", lambda: co.get(where={"k":1,"j":2}))
t("where empty", lambda: co.get(where={}))
t("bad op", lambda: co.get(where={"k":{"$like":"a"}}))
t("modify space", lambda: co.modify(configuration={"hnsw":{"space":"l2"}}))
t("get include default", lambda: co.get(ids=["a"]).get("embeddings"))
t("include emb", lambda: np.array(co.get(ids=["a"], include=["embeddings"])["embeddings"]).shape)
t("update missing", lambda: co.update(ids=["zz"], documents=["q"]))
t("delete missing", lambda: co.delete(ids=["zz"]))
t("delete no args", lambda: co.delete())
t("ef conflict reopen", lambda: c.get_collection("dbg").count())
t("get_or_create no ef", lambda: c.get_or_create_collection("dbg").query(query_texts=["apple"], n_results=1))
t("query empty coll", lambda: c.get_or_create_collection("empty1", embedding_function=ef).query(query_texts=["x"], n_results=3)["ids"])
t("where on missing key", lambda: co.get(where={"nokey":1})["ids"])
t("where_document contains case", lambda: (co.get(where_document={"$contains":"Apple"})["ids"], co.get(where_document={"$contains":"apple"})["ids"]))
t("bool meta $eq int", lambda: (co.upsert(ids=["b1"], documents=["b"], metadatas=[{"flag": True}]), co.get(where={"flag":1})["ids"], co.get(where={"flag":True})["ids"]))
t("float vs int", lambda: (co.upsert(ids=["f1"], documents=["f"], metadatas=[{"n": 5.0}]), co.get(where={"n":5})["ids"]))
