import sys, chromadb
sys.path.insert(0,"/data/work/tenderyar")
from chromadb import Documents, EmbeddingFunction, Embeddings
from tenderyar.rag.index import HashEmbeddings
class LCEmbeddingFunction(EmbeddingFunction):
    def __init__(self, lc): self.lc = lc
    def __call__(self, input: Documents) -> Embeddings: return self.lc.embed_documents(list(input))
    @staticmethod
    def name(): return "langchain-wrapper"
ef = LCEmbeddingFunction(HashEmbeddings()); MODE="offline"; client=chromadb.EphemeralClient()
exec(open("food_cells.py").read())
print("=== M4")
calls={"n":0}
def counted(q,kept): calls["n"]+=1; return offline_answer(q,kept)
for q,w in [("how do I fix my car battery?",None),("spicy Indian chicken dish",None),("an Italian dish",{"$and":[{"cuisine":"Italian"},{"calories":{"$lte":400}}]})]:
    r=rag(q, llm=counted, where=w); print("M4",q,"->",r["answer"],"| sources",r["sources"],"ok",r["ok"],"llm calls so far",calls["n"])
history=[]
def chat(msg, history):
    r=rag(msg); history.append((msg,r["answer"])); return r["answer"]+("" if not r["sources"] else "\nSources: "+", ".join(r["sources"]))
print(repr(chat("spicy Indian chicken dish",history)))
print("cuisines", sorted({m["cuisine"] for m in metas}))
