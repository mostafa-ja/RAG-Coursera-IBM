"""Element screenshots + JS errors. Usage: python shots.py HTML OUTDIR id[:dark][:mobile] ..."""
import sys, shutil, re, os
from playwright.sync_api import sync_playwright
html, out, ids = sys.argv[1], sys.argv[2], sys.argv[3:]
errs = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=shutil.which("chromium"))
    for spec in ids:
        i, *fl = spec.split(":")
        pg = b.new_page(viewport={"width": 390 if "mobile" in fl else 1300, "height": 900})
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.route(re.compile(r"^https?:"), lambda r: r.abort())
        pg.goto("file://" + os.path.abspath(html)); pg.wait_for_timeout(400)
        if "dark" in fl: pg.evaluate("theme()"); pg.wait_for_timeout(150)
        el = pg.locator(f"#{i}"); el.scroll_into_view_if_needed()
        ov = pg.evaluate(f"""[...document.querySelectorAll('#{i} svg')].filter(s=>s.getBoundingClientRect().right>document.documentElement.clientWidth+1).length""")
        el.screenshot(path=f"{out}/{i}_{'_'.join(fl) or 'light'}.png"); print(spec, "svg overflow:", ov)
        pg.close()
    b.close()
print("JS errors:", len(errs)); [print(" ", e) for e in errs[:10]]
