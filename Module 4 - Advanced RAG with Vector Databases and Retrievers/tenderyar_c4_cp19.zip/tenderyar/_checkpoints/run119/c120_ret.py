"""CP120 real offline outputs for w1-ret: companypolicies.txt, chunk 200/20, Chroma + HashEmbeddings stand-in."""
import sys; sys.path.insert(0, "."); import warnings; warnings.filterwarnings("ignore")
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from tenderyar.rag.index import HashEmbeddings
docs = TextLoader("/data/work/m4/companypolicies.txt").load()
chunks = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20).split_documents(docs)
print("chunks:", len(chunks))
vs = Chroma.from_documents(chunks, HashEmbeddings(), collection_name="pol", collection_metadata={"hnsw:space": "cosine"})
q = "email policy"
def show(tag, ds):
    print(f"--- {tag}: {len(ds)}")
    for d in ds: print("  ", repr(d.page_content[:70]))
show("similarity k=4 (default)", vs.as_retriever().invoke(q))
show("k=1", vs.as_retriever(search_kwargs={"k": 1}).invoke(q))
show("mmr", vs.as_retriever(search_type="mmr").invoke(q))
show("mmr k=4 fetch_k=20 lambda=0.5", vs.as_retriever(search_type="mmr", search_kwargs={"k":4,"fetch_k":20,"lambda_mult":0.5}).invoke(q))
for th in (0.4, 0.2):
    show(f"threshold {th}", vs.as_retriever(search_type="similarity_score_threshold", search_kwargs={"score_threshold": th}).invoke(q))
print("scores:", [round(s,3) for _, s in vs.similarity_search_with_relevance_scores(q, k=6)])
show("Ex1 smoking k=2", vs.as_retriever(search_kwargs={"k": 2}).invoke("smoking policy"))
print(type(vs.as_retriever()).__name__, vs.as_retriever().search_type)
