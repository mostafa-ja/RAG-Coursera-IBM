# CP126a: writes html/parts_c4/w1_F_sum_quiz.html part 1 (w1-pick 1.9). Numbers = earlier measured runs (run124/125/126, RESULTS v0.4).
def box(x,y,w,h,cls,t1,t2=""):
    s=f'<rect class="{cls}" height="{h}" rx="10" width="{w}" x="{x}" y="{y}"></rect>'
    cy=y+h/2+(-3 if t2 else 4)
    s+=f'<text font-size="11.5" font-weight="700" text-anchor="middle" x="{x+w/2}" y="{cy}">{t1}</text>'
    if t2: s+=f'<text class="mt" font-size="10" text-anchor="middle" x="{x+w/2}" y="{cy+14}">{t2}</text>'
    return s
def ln(x1,y1,x2,y2): return f'<path class="ln" d="M{x1},{y1} L{x2},{y2}"></path>'
rows=[("General Q&amp;A?","Vector + BM25 · QueryFusion","1.6 + 1.8 · semantic + keyword vote"),
("Exact terms matter (technical, legal)?","BM25 first, vector second","1.6 · fusion keeps terms on top"),
("Long documents, context cut by chunks?","Auto-merging (or Parent Doc)","1.7 / 1.4 · merge only when earned"),
("Documents point to other documents?","Recursive + IndexNode","1.7 · follow citations / refs"),
("Many diverse documents?","Doc Summary → Vector","1.6 · narrow docs, then search inside"),
("Filters hidden in the question?","Self-Query (metadata filter)","1.3 · rating, year, genre, date")]
svg='<div class="svgw"><svg aria-label="Decision guide: pick a retriever by use case; six questions, each leads to a recommended retriever and the lesson" role="img" style="max-width:1000px" viewBox="0 0 920 410">'
svg+='<text font-size="12" font-weight="800" x="10" y="20">Which retriever? Ask the questions top to bottom; first “yes” wins, combine when several apply</text>'
y=40
for i,(q,a,n) in enumerate(rows):
    svg+=box(10,y,330,46,"n4",q)
    svg+=ln(340,y+23,380,y+23)+'<text class="mt" font-size="10" x="346" y="%d">yes</text>'%(y+17)
    svg+=box(380,y,270,46,"n2" if i<2 else "n",a)
    svg+=box(670,y,240,46,"n3",n.split(" · ")[0],n.split(" · ")[1])
    if i<5: svg+=ln(175,y+46,175,y+60)+'<text class="mt" font-size="10" x="182" y="%d">no</text>'%(y+57)
    y+=60
svg+='<text class="mt" font-size="10.5" x="10" y="%d">Default when unsure: dense + BM25 with RRF (row 1). TenderYar = rows 1 + 2 (Persian tender text: exact clause words + meaning).</text>'%(y+8)
svg+='</svg></div><p class="cap">Decision guide built from the lab’s “Recommended retrievers by use case” (L-2) and the cheat sheet (R-2). Purple = TenderYar uses it (rows 1 + 2).</p>'
html=f'''<article class="lesson" data-track="" id="w1-pick"><div class="secnum">Week 1 · 1.9 <span class="tag t-green">⭐ Key for projects</span></div><h2>Picking a retriever by use case: one decision guide for Week 1</h2><div class="meta"><span>⏱ ~8 min</span><span>🧭 1 diagram</span><span>💻 0 code cells</span><span>🧠 3 recall Qs</span></div>
<div class="tldr"><span class="nut">In a nutshell</span>You have now met nine retrievers. The lab ends with five recommendations: <b>general Q&amp;A</b> → vector + BM25 fused; <b>technical documents</b> → BM25 first, vector second; <b>long documents</b> → auto-merging; <b>research papers</b> → recursive; <b>large collections</b> → document summary first, then vector. Add Self-Query when the question carries filters. When unsure, start with the cheap, robust hybrid (dense + BM25 + RRF) and <b>measure</b> before adding LLM calls.</div>
<div class="obj"><div class="objl"><b>🎯 After this lesson you can</b><ul><li>Match each of the five lab use cases to its retriever and give the reason.</li><li>Say what each choice costs (LLM calls at build or query time).</li><li>Defend a default for a new project and say what you would measure.</li></ul></div></div>
{svg}
<h3>The lab’s five recommendations, with costs</h3>
<div class="tw"><table><thead><tr><th>Use case</th><th>Primary</th><th>Add</th><th>Why</th><th>Extra LLM calls</th><th>Lesson</th></tr></thead><tbody>
<tr><td>General Q&amp;A</td><td>Vector index retriever</td><td>BM25 via <code>QueryFusionRetriever</code></td><td>meaning + exact words vote</td><td>0 (with <code>num_queries=1</code>)</td><td><a href="#w1-fus">1.8</a></td></tr>
<tr><td>Technical / legal documents</td><td>BM25</td><td>vector as secondary</td><td>exact terms (model numbers, clause names) must win</td><td>0</td><td><a href="#w1-lir">1.6</a></td></tr>
<tr><td>Long documents</td><td>Auto-merging</td><td>—</td><td>returns the parent only when &gt; half its children were hit</td><td>0</td><td><a href="#w1-am">1.7</a></td></tr>
<tr><td>Research papers</td><td>Recursive</td><td><code>IndexNode</code> references</td><td>follows citations into other nodes / retrievers</td><td>0 (but needs reference data)</td><td><a href="#w1-am">1.7</a></td></tr>
<tr><td>Large document collections</td><td>Document summary retriever</td><td>vector search inside the chosen docs</td><td>narrow first, then search detail</td><td>1 per document at build (10 for the lab’s 10 docs) + 1 per query (LLM mode)</td><td><a href="#w1-lir">1.6</a></td></tr>
</tbody></table></div>
<p>Two LangChain retrievers complete the picture: <b>Self-Query</b> (<a href="#w1-sq">1.3</a>) when the question contains a filter (“after 2010”, “rating above 8.5”), 1 LLM call per query; <b>Multi-Query</b> (<a href="#w1-mq">1.2</a>) when users phrase things badly, 1 LLM call per query plus k × variants searches. <b>MMR</b> (<a href="#w1-ret">1.1</a>) is not a separate retriever but a search type: use it when the top-k are near-duplicates.</p>
<div class="box why"><b class="t">Rule of thumb</b><p>Cheap and robust first: a hybrid (vector + BM25 + RRF) costs no LLM calls and beat dense-only on TenderQA v0 (MRR 0.870 → 0.946). Add an LLM-powered retriever only when a benchmark says it pays. In TenderYar, Multi-Query reached MRR 0.938 &lt; hybrid 0.946, so it stays OFF.</p></div>
<div class="box pit"><b class="t">Traps</b><ul><li>Choosing by fashion: auto-merging and recursive retrievers need the right data (a node tree, real references); the lab cells “work” without it but do nothing special (<a href="#w1-am">1.7</a>).</li><li>Fusing raw scores with <code>simple</code> mode: cosine and BM25 live on different scales (<a href="#w1-fus">1.8</a>).</li><li>Document summary on 10 000 docs: 10 000 LLM calls before the first question.</li><li>No test set: without one you cannot tell which row of the guide fits your data.</li></ul></div>
<div class="prs"><b class="t">🏗 TenderYar</b><p>Persian tender documents are both “general Q&amp;A” and “technical/legal” (clause words such as «ماده ۳۰», amounts, dates). So TenderYar uses rows 1 + 2: <code>Hybrid([dense, bm25], weights=[0.5, 0.5])</code> with weighted RRF (<a href="#w1-fus">1.8</a>), BM25 on <code>clean.tokens</code>. TenderQA v0 offline: dense recall@1 0.796 → BM25 0.907 → hybrid 0.907, MRR 0.870 → 0.946, recall@5 0.963 → 1.000. Dates are parsed by a Jalali pre-parser (the Self-Query idea, <a href="#w1-sq">1.3</a>); ماده sections act as parents for the answer context (<a href="#w1-pd">1.4</a>).</p></div>
<div class="take"><h4>Key takeaways</h4><div class="tgrid"><div class="box why"><b class="t">Why it matters</b><ul><li>The data shape decides the retriever: terms, length, references, collection size, filters.</li><li>Hybrid + RRF is the safe default; the others solve specific problems.</li></ul></div><div class="box pit"><b class="t">Common pitfalls</b><ul><li>Adding LLM calls before measuring.</li><li>Using a structure-based retriever on data without that structure.</li></ul></div></div></div>
<div class="recall"><b class="t">🧠 Active recall: answer before you open</b><details><summary>A support bot answers questions about 300 product manuals full of model numbers. Which retriever(s)?</summary><div>Technical documentation: <b>BM25 primary</b> (exact model numbers) with a vector retriever as secondary, fused with RRF.</div></details><details><summary>Why is the document summary retriever a bad fit for 50 000 short emails?</summary><div>It needs one LLM summary per document at build time (50 000 calls) and is meant for long documents whose meaning is lost by chunking; short emails can be embedded directly.</div></details><details><summary>You must choose a default before you have any test data. What do you pick and what do you build next?</summary><div>Dense + BM25 with RRF (0 LLM calls, robust to score scales). Next build a small labelled question set (like TenderQA) and measure recall@k / MRR before adding Multi-Query, rerankers or other LLM steps.</div></details></div></article>
'''
open("html/parts_c4/w1_F_sum_quiz.html","w",encoding="utf-8").write(html)
