# CP126b: appends w1-sum + w1-quiz to html/parts_c4/w1_F_sum_quiz.html and closes section#w1.
import re
P="html/parts_c4/w1_F_sum_quiz.html"; s=open(P,encoding="utf-8").read()
s=s[:s.index('<article class="lesson summ"')] if 'id="w1-sum"' in s else s.replace("</section>","")
T={"w1-ret":"1.1","w1-mq":"1.2","w1-sq":"1.3","w1-pd":"1.4","w1-li":"1.5","w1-lir":"1.6","w1-am":"1.7","w1-fus":"1.8","w1-pick":"1.9"}
SUM=[("A LangChain <b>retriever</b> is an interface that returns documents for an unstructured query.","w1-ret"),
("There are several LangChain retriever types (vector store, multi-query, self-query, parent document, …).","w1-ret"),
("The <b>vector store-based retriever</b> retrieves documents from a vector database.","w1-ret"),
("It is created from the vector store with <code>.as_retriever()</code>, using similarity search or MMR.","w1-ret"),
("<b>Similarity search</b>: the retriever takes a query and returns the most similar data.","w1-ret"),
("<b>MMR</b> balances relevance and diversity of the retrieved results.","w1-ret"),
("The <b>multi-query retriever</b> uses an LLM to write different versions of the query → a richer set of documents.","w1-mq"),
("The <b>self-query retriever</b> splits the query into a string for semantic lookup + a metadata filter.","w1-sq"),
("The <b>parent document retriever</b> has two splitters: a parent splitter (large chunks to return) and a child splitter (small chunks for meaningful embeddings).","w1-pd"),
("Core LlamaIndex index types: <code>VectorStoreIndex</code>, <code>DocumentSummaryIndex</code>, <code>KeywordTableIndex</code>.","w1-li"),
("<code>VectorStoreIndex</code> stores an embedding per chunk, suits semantic retrieval, common in LLM pipelines.","w1-li"),
("<code>DocumentSummaryIndex</code> generates and stores document summaries used to filter documents before retrieving full content; useful for large, diverse document sets.","w1-li"),
("<code>KeywordTableIndex</code> maps extracted keywords to chunks; useful in hybrid or rule-based search.","w1-li"),
("The <b>Vector Index Retriever</b> finds semantically related content; ideal for general-purpose search and RAG.","w1-lir"),
("The <b>BM25 Retriever</b> ranks by keywords: exact matches, not semantic similarity.","w1-lir"),
("The <b>Document Summary Index Retriever</b> uses summaries instead of the documents to find content.","w1-lir"),
("It has two versions: one uses an LLM, the other uses semantic (embedding) similarity.","w1-lir"),
("The <b>Auto Merging Retriever</b> preserves context in long documents with hierarchical chunking into parent and child nodes.","w1-am"),
("The <b>Recursive Retriever</b> follows relationships between nodes using references (citations, metadata links).","w1-am"),
("The <b>Query Fusion Retriever</b> combines results from different retrievers with fusion strategies.","w1-fus"),
("Fusion strategies: <b>Reciprocal Rank Fusion</b>, <b>Relative Score Fusion</b>, <b>Distribution-Based Fusion</b>.","w1-fus"),
("Cheat sheet: BM25 improves TF-IDF with term-frequency saturation (k1 ≈ 1.2) and length normalisation (b ≈ 0.75).","w1-lir"),
("Lab: pick by use case: general Q&amp;A → vector + BM25 fusion; technical → BM25 first; long → auto-merging; papers → recursive; large sets → summary then vector.","w1-pick")]
li="".join(f'<li><label><input class="sumchk" data-k="w1s{i}" type="checkbox"/> {t}</label> <a class="goto" href="#{a}">→ {T[a]}</a></li>' for i,(t,a) in enumerate(SUM))
summ=f'''<article class="lesson summ" data-track="" id="w1-sum"><div class="secnum">Week 1 · Review</div><h2>Week 1 summary checklist</h2>
<p>Every official point from the module’s <i>Lesson summary</i> (R-1) plus two from the cheat sheet (R-2) and the lab. Tick each one only if you can <b>explain it aloud without looking</b>. If you can’t, use the → link to go back to that lesson.</p>
<ul class="chk">{li}</ul><div class="sumbar"><i></i></div><small class="sumtxt"></small></article>
'''
L="ABCD"
def quiz(qid,title,qs):
    h=f'<div class="quiz" id="qz-{qid}"><span class="score"></span><h3>📝 {title}</h3><button class="btn o reset">Reset quiz</button>'
    for i,(q,opts,a,ex,rv) in enumerate(qs):
        t=[2,0,3,1,1,3,0,2,3,1,0,2][(i+(5 if qid.endswith("2") else 0))%12]; o=list(opts); c=o.pop(a); o.insert(t,c); opts,a=o,t   # spread correct letters
        h+=f'<div class="q" data-a="{a}" id="{qid}-{i}"><p><b>Q{i+1}.</b> {q}</p>'+"".join(f'<button class="opt">{L[j]}. {o}</button>' for j,o in enumerate(opts))
        h+=f'<div class="ex">✅ <b>Answer {L[a]}.</b> {ex} <span class="rv">📖 Review → <a href="#{rv}">{T[rv]} {RT[rv]}</a></span></div></div>'
    return h+'</div>'
RT={"w1-ret":"Retrievers &amp; the vector-store retriever","w1-mq":"Multi-Query retriever","w1-sq":"Self-Query retriever","w1-pd":"Parent Document retriever","w1-li":"LlamaIndex index types","w1-lir":"Vector, BM25 &amp; Document-Summary retrievers","w1-am":"Auto-merging &amp; Recursive retrievers","w1-fus":"Query fusion","w1-pick":"Picking a retriever by use case"}
Q1=[("What does a LangChain retriever return for a query?",["A generated answer string","A list of documents","A single embedding vector","A SQL filter"],1,"A retriever is an interface: unstructured query in, list of <code>Document</code>s out. Generating the answer is the LLM’s job.","w1-ret"),
("Your top-4 results are four near-identical paragraphs. Which search type helps?",["similarity with a higher k","similarity_score_threshold","mmr","BM25 with b = 0"],2,"MMR picks documents that are relevant <b>and</b> unlike the ones already selected, removing near-duplicates.","w1-ret"),
("How does the Multi-Query retriever get a richer set of documents?",["It raises k for every query","An LLM writes several versions of the question; results are merged as a unique union","It re-ranks with a cross-encoder","It splits documents into smaller chunks"],1,"One LLM call writes variants; each is searched; the union (duplicates removed) is returned.","w1-mq"),
("“Sci-fi movies rated above 8.5” goes into a Self-Query retriever. What does it produce?",["Only a longer query string","A query string plus a metadata filter (rating &gt; 8.5 AND genre = sci-fi)","A summary of every movie","A BM25 keyword table"],1,"The LLM builds a structured query: a semantic string and a filter that a translator (e.g. <code>ChromaTranslator</code>) turns into the store’s <code>where</code> syntax.","w1-sq"),
("In the Parent Document retriever, which chunks are embedded in the vector store?",["Parent chunks","Child chunks","Whole documents","Summaries"],1,"Small child chunks give precise embeddings; their <code>doc_id</code> points to the larger parent in the docstore, which is what is returned.","w1-pd"),
("Which LlamaIndex index calls the LLM once per document at build time?",["VectorStoreIndex","DocumentSummaryIndex","BM25Retriever","None of them"],1,"Each document is summarised by the LLM when the index is built (10 calls for the lab’s 10 documents). VectorStoreIndex only embeds. (KeywordTableIndex also calls the LLM per chunk for keywords; SimpleKeywordTableIndex uses regex.)","w1-li"),
("Which retriever finds a document by an exact part number such as “X-2049” most reliably?",["Vector Index Retriever","BM25 Retriever","Document Summary (embedding mode)","Recursive retriever without references"],1,"BM25 scores exact term matches; embeddings may treat rare codes as noise.","w1-lir"),
("Which three fusion modes does the QueryFusionRetriever offer besides “simple”?",["RRF, relative score, distribution-based score","MMR, BM25, cosine","Max, min, mean","Auto-merge, recursive, parent"],0,"<code>reciprocal_rerank</code>, <code>relative_score</code>, <code>dist_based_score</code>; the default is <code>simple</code> (max score per node).","w1-fus")]
Q2=[("Similarity scores of the top-6 are 0.41, 0.32, 0.31, 0.31, 0.31, 0.28. With <code>search_type=\"similarity_score_threshold\"</code> and threshold 0.4, how many documents come back?",["0","1","4","6"],1,"Only scores ≥ 0.4 pass: one document (measured in 1.1; threshold 0.2 returned 4 with k = 4).","w1-ret"),
("You build a ParentDocumentRetriever but reopen the Chroma collection later with a fresh <code>InMemoryStore</code>. What happens on a query?",["It raises KeyError","It returns child chunks instead","It returns 0 documents without an error","It rebuilds the parents automatically"],2,"Children are found, but their parent ids are missing from the new empty docstore, so nothing is returned, silently. Persist the docstore (e.g. <code>LocalFileStore</code> + <code>create_kv_docstore</code>).","w1-pd"),
("BM25 term-frequency saturation means…",["a term counts only once","each extra occurrence adds less to the score (controlled by k1)","long documents are always preferred","rare terms get lower weight"],1,"Repetition helps with diminishing returns (k1); length normalisation is the separate b parameter.","w1-lir"),
("The Document Summary Index Retriever finds a match. What text does it return?",["The summary","The original document (nodes)","The keywords","The query"],1,"Summaries are only used for selection; the original text is returned.","w1-lir"),
("In AutoMergingRetriever, when are retrieved leaves replaced by their parent?",["Always","When more than half of the parent’s children are retrieved","When at least one child is retrieved","When the parent’s score exceeds 0.5"],1,"The rule is ratio &gt; 0.5 (strict). Merges can cascade up to the root.","w1-am"),
("A RecursiveRetriever is built over ordinary TextNodes with no IndexNode references. What does it behave like?",["A BM25 retriever","A plain vector retriever: nothing is followed","An auto-merging retriever","It raises an error"],1,"Recursion needs <code>IndexNode</code>s that point to other nodes or retrievers; without them the result equals the base retriever.","w1-am"),
("A document is 1st in one list and absent from two others; another is 2nd in all three. With LlamaIndex RRF (k = 60, rank from 0), which ranks higher?",["The first one (1/60)","The second one (3/61)","They tie","It depends on the raw scores"],1,"1/60 ≈ 0.0167 vs 3/61 ≈ 0.0492: RRF rewards agreement between lists and ignores raw scores.","w1-fus"),
("You fuse vector (cosine 0–1) and BM25 (0–20+) results. Which mode is the poor choice?",["reciprocal_rerank","relative_score","dist_based_score","simple"],3,"<code>simple</code> keeps the maximum raw score, so BM25’s larger scale wins regardless of quality. RRF ignores scales; the other two normalise.","w1-fus"),
("With <code>mode=\"reciprocal_rerank\"</code> you set <code>retriever_weights=[0.7, 0.3]</code>. Effect?",["Vector counts 70 %","BM25 counts 70 %","No effect, and no warning","A ValueError"],2,"LlamaIndex’s RRF does not read the weights (measured in 1.8). Weights only change <code>relative_score</code> / <code>dist_based_score</code>.","w1-fus"),
("According to the lab, which setup fits a large collection of diverse long documents?",["Recursive retriever alone","Document summary retriever to pick documents, then vector search inside them","BM25 only","Multi-query with k = 50"],1,"Narrow down documents by summary, then search detail with a vector retriever.","w1-pick")]
quizart=f'''<article class="lesson quizblock" data-track="" id="w1-quiz"><div class="secnum">Week 1 · Assessment</div><h2>Week 1 quizzes</h2>
<p>Own questions written for Module 4 (Q-1), covering every lesson of Week 1 and the cheat sheet (R-2). Practice first, then the graded-style quiz with scenario and measured-behaviour questions.</p>
{quiz("week1_quiz1","Practice Quiz: Advanced Retrievers in LangChain and LlamaIndex",Q1)}{quiz("week1_quiz2","Graded Quiz: Choosing and Combining Retrievers",Q2)}</article>
'''
open(P,"w",encoding="utf-8").write(s+summ+quizart+"</section>\n")
print(len(SUM),len(Q1),len(Q2))
