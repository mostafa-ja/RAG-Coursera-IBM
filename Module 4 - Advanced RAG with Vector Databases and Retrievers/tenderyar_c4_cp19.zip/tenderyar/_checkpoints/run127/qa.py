import re, sys, collections
part = open("html/parts_c4/w1_F_sum_quiz.html").read(); g = open("html/RAG_C4_Guide_v1.html").read()
print("part hex:", len(re.findall(r"#[0-9a-fA-F]{3,6}\b(?![\w-])", re.sub(r'href="#[^"]*"', "", part))))
for t in ("article", "svg", "table", "div", "details", "pre", "ul", "p", "tr"):
    o, c = len(re.findall(rf"<{t}[\s>]", part)), part.count(f"</{t}>")
    if o != c: print("UNBALANCED", t, o, c)
ids = re.findall(r'\sid="([^"]+)"', g); d = [k for k, v in collections.Counter(ids).items() if v > 1]; print("dup ids:", d)
bad = sorted({h for h in re.findall(r'href="#([^"]+)"', g) if h not in set(ids)}); print("unresolved links:", bad)
print("theme last:", g.rfind("v14-theme") > g.rfind("<style") - 1 if "v14-theme" in g else "n/a")
