"""Smoke test of a built guide: JS errors + light/dark screenshot of the top. Usage: python smoke.py HTML OUTPREFIX"""
import sys, shutil, re
from playwright.sync_api import sync_playwright
html, out = sys.argv[1], sys.argv[2]
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=shutil.which("chromium"))
    pg = b.new_page(viewport={"width": 1300, "height": 900}); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("console", lambda m: m.type == "error" and errs.append(m.text))
    pg.route(re.compile(r"^https?:"), lambda r: r.abort())
    pg.goto("file://" + __import__("os").path.abspath(html)); pg.wait_for_timeout(600)
    pg.screenshot(path=out + "_light.png")
    pg.evaluate("theme()"); pg.wait_for_timeout(200); pg.screenshot(path=out + "_dark.png")
    print("theme stored:", pg.evaluate("localStorage.getItem('c4m_th')"), "| pct:", pg.inner_text("#pct"))
    b.close()
errs = [e for e in errs if "ERR_FAILED" not in e and "net::" not in e]
print("JS errors:", len(errs)); [print(" ", e) for e in errs[:10]]
