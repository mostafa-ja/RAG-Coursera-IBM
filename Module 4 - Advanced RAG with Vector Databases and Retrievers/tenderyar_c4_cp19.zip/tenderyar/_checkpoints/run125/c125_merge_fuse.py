"""CP125 offline run of L-2 lab sections 4-6 (lessons 1.7/1.8) with REAL llama-index-core classes.
Stand-ins as run124: HashEmb (char 3-grams) for Gemini embeddings; scripted LLM (query generation) for Gemini."""
import sys, re, io, contextlib, collections; sys.path.insert(0, ".")
src = open("_checkpoints/run124/c124_llama.py").read()
g = {}; exec(src.split("SAMPLE_DOCUMENTS = [")[0], g)
exec("SAMPLE_DOCUMENTS = [" + src.split("SAMPLE_DOCUMENTS = [")[1].split("Q = {")[0], g)
from typing import Any
from llama_index.core import VectorStoreIndex, Document, Settings, StorageContext
from llama_index.core.node_parser import HierarchicalNodeParser, SentenceSplitter, get_leaf_nodes, get_root_nodes
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.retrievers import AutoMergingRetriever, RecursiveRetriever, QueryFusionRetriever
from llama_index.core.schema import IndexNode
from llama_index.core.llms import CustomLLM, CompletionResponse, LLMMetadata
from llama_index.core.llms.callbacks import llm_completion_callback
from llama_index.retrievers.bm25 import BM25Retriever
CALLS = collections.Counter()
VARS = {"What are the main approaches to machine learning?": ["machine learning approaches and methods", "different ML techniques and algorithms"]}
class GenLLM(CustomLLM):
    @property
    def metadata(self): return LLMMetadata(context_window=8000, num_output=256, model_name="scripted-gen")
    @llm_completion_callback()
    def complete(self, prompt: str, formatted: bool = False, **kw: Any) -> CompletionResponse:
        CALLS["query_gen"] += 1
        q = prompt.split("Query: ")[1].split("\n")[0]
        n = int(re.search(r"Generate (\d+) search queries", prompt).group(1))
        v = VARS.get(q, [q.lower() + " explained", "examples of " + q.lower().rstrip("?")])
        return CompletionResponse(text="1. " + v[0] + "\n2. " + v[1] if n >= 2 else v[0])
    @llm_completion_callback()
    def stream_complete(self, prompt, formatted=False, **kw): yield self.complete(prompt)
Settings.llm = GenLLM(); Settings.embed_model = g["HashEmb"]()
SAMPLE = g["SAMPLE_DOCUMENTS"]
DEMO_QUERIES = {"advanced": "How do neural networks work in deep learning?", "applications": "What are the applications of AI?",
                "comprehensive": "What are the main approaches to machine learning?"}
documents = [Document(text=t) for t in SAMPLE]
vector_index = VectorStoreIndex.from_documents(documents)
def cap(fn):
    b = io.StringIO()
    with contextlib.redirect_stdout(b): r = fn()
    return r, b.getvalue()
def depth_levels(ns):
    byid = {n.node_id: n for n in ns}; lv = {}
    for n in ns:
        d, p = 0, n
        while p.parent_node is not None: d += 1; p = byid[p.parent_node.node_id]
        lv.setdefault(d, []).append(len(n.text))
    return lv

print("== 1.7 A: lab cell 23 as written (10 one-sentence docs, ALL levels indexed)")
hier = HierarchicalNodeParser.from_defaults(chunk_sizes=[512, 256, 128]).get_nodes_from_documents(documents)
print("hier_nodes:", len(hier), "| leaf", len(get_leaf_nodes(hier)), "| root", len(get_root_nodes(hier)), "| levels", {d: len(v) for d, v in depth_levels(hier).items()})
ds = SimpleDocumentStore(); ds.add_documents(hier); sc = StorageContext.from_defaults(docstore=ds)
base_index = VectorStoreIndex(hier, storage_context=sc)
amr = AutoMergingRetriever(base_index.as_retriever(similarity_top_k=6), sc, verbose=True)
nodes, log = cap(lambda: amr.retrieve(DEMO_QUERIES["advanced"]))
print("verbose log:", log.strip().replace("\n", " | ")[:400])
print("Auto-merged to", len(nodes), "nodes")
for n in nodes: print(f"  {n.score:.4f} {n.text[:60]}")
print("unique texts:", len({n.text for n in nodes}))
print("defaults: simple_ratio_thresh", amr._simple_ratio_thresh)

print("== 1.7 B: long document, leaf nodes indexed (docs pattern)")
policy = open("/data/work/m4/companypolicies.txt").read()
pdoc = [Document(text=policy)]
hn = HierarchicalNodeParser.from_defaults(chunk_sizes=[2048, 512, 128]).get_nodes_from_documents(pdoc); leaves = get_leaf_nodes(hn)
for d, v in sorted(depth_levels(hn).items()): print(f"level {d}: {len(v)} nodes, chars {min(v)}-{max(v)}")
print("chars:", len(policy), "| all", len(hn), "leaves", len(leaves))
ds2 = SimpleDocumentStore(); ds2.add_documents(hn); sc2 = StorageContext.from_defaults(docstore=ds2)
leaf_index = VectorStoreIndex(leaves, storage_context=sc2)
for q, k in (("What is the smoking policy?", 12), ("What does the company say about mobile phones and laptops?", 12), ("What is the smoking policy?", 4)):
    br = leaf_index.as_retriever(similarity_top_k=k)
    am = AutoMergingRetriever(br, sc2, verbose=True)
    bn = br.retrieve(q); mn, log = cap(lambda: am.retrieve(q))
    print(f"Q {q!r} k={k}: base {len(bn)} leaves ({sum(len(n.text) for n in bn)} chars) -> merged {len(mn)} nodes ({sum(len(n.text) for n in mn)} chars); sizes {[len(n.text) for n in mn]}")
    print("   log:", log.strip().replace("\n", " | ")[:300])
    print("   top:", [(round(n.score, 3), n.text[:40].replace("\n", " ")) for n in mn[:3]])
am9 = AutoMergingRetriever(leaf_index.as_retriever(similarity_top_k=12), sc2, simple_ratio_thresh=0.9)
print("ratio 0.9:", len(am9.retrieve("What is the smoking policy?")), "nodes")
ds3 = SimpleDocumentStore(); ds3.add_documents(leaves); sc3 = StorageContext.from_defaults(docstore=ds3)
try:
    r = AutoMergingRetriever(VectorStoreIndex(leaves, storage_context=sc3).as_retriever(similarity_top_k=12), sc3).retrieve("What is the smoking policy?")
    print("docstore without parents:", len(r), "nodes")
except Exception as e: print("docstore without parents ->", type(e).__name__, str(e)[:120])

print("== 1.7 C: lab cell 25 recursive as written")
docs_with_refs = [Document(text=d.text, metadata={"doc_id": f"doc_{i}", "references": [f"doc_{j}" for j in range(10) if j != i][:2]}) for i, d in enumerate(documents)]
ref_index = VectorStoreIndex.from_documents(docs_with_refs)
rd = {f"doc_{i}": ref_index.as_retriever(similarity_top_k=1) for i in range(10)}
base = ref_index.as_retriever(similarity_top_k=2); rd["vector"] = base
rr = RecursiveRetriever("vector", retriever_dict=rd, query_engine_dict={}, verbose=True)
nodes, log = cap(lambda: rr.retrieve(DEMO_QUERIES["applications"]))
print("log:", log.strip().replace("\n", " | ")[:300])
print("Recursively retrieved", len(nodes), "nodes:", [(round(n.score, 4), n.text[:40]) for n in nodes])
print("same as base:", [n.node_id for n in nodes] == [n.node_id for n in base.retrieve(DEMO_QUERIES["applications"])])
print("metadata embedded in text?", "references" in docs_with_refs[0].get_content(metadata_mode="embed"))

print("== 1.7 D: recursive with IndexNode chunk references (docs pattern)")
parents = SentenceSplitter(chunk_size=1024, chunk_overlap=0).get_nodes_from_documents(pdoc)
for i, p in enumerate(parents): p.id_ = f"node-{i}"
subs = []
for p in parents:
    for c in SentenceSplitter(chunk_size=128, chunk_overlap=20).get_nodes_from_documents([Document(text=p.text)]):
        subs.append(IndexNode.from_text_node(c, p.node_id))
    subs.append(IndexNode.from_text_node(p, p.node_id))
all_nodes = {p.node_id: p for p in parents}
child_index = VectorStoreIndex(subs)
rr2 = RecursiveRetriever("vector", retriever_dict={"vector": child_index.as_retriever(similarity_top_k=4)}, node_dict=all_nodes, verbose=True)
for q in ("What is the smoking policy?", "Can I use my phone during meetings?"):
    nodes, log = cap(lambda: rr2.retrieve(q))
    print(f"Q {q!r}: {len(parents)} parents / {len(subs)} index nodes -> {len(nodes)} parent nodes {[n.node_id for n in nodes]} sizes {[len(n.text) for n in nodes]}")
    print("   log:", log.strip().replace("\n", " | ")[:260])

print("== 1.8 fusion modes, lab cells 29/31/33 (base vector, num_queries=3)")
q = DEMO_QUERIES["comprehensive"]
for mode, k in (("reciprocal_rerank", 5), ("relative_score", 5), ("dist_based_score", 8), ("simple", 5)):
    c0 = CALLS["query_gen"]
    fr = QueryFusionRetriever([vector_index.as_retriever(similarity_top_k=k)], similarity_top_k=3, num_queries=3, mode=mode, use_async=False, verbose=(mode == "reciprocal_rerank"))
    nodes, log = cap(lambda: fr.retrieve(q))
    if log.strip(): print("verbose:", log.strip().replace("\n", " | "))
    print(f"{mode} (base k={k}): LLM calls {CALLS['query_gen'] - c0}:", [(round(n.score, 4), n.text[:32]) for n in nodes])
d = QueryFusionRetriever([vector_index.as_retriever()])
print("default mode:", d.mode, "| default num_queries", d.num_queries, "| default top_k", d.similarity_top_k)
vr = vector_index.as_retriever(similarity_top_k=5)
for qq in [q] + VARS[q]:
    print("raw", repr(qq), [(round(n.score, 4), n.text[:24]) for n in vr.retrieve(qq)])
print("lab manual top RRF contribution 1/61 =", round(1/61, 4), "| library 1/60 =", round(1/60, 4))
print("== 1.8 hybrid fusion: vector + BM25, num_queries=1")
nodes = SentenceSplitter().get_nodes_from_documents(documents)
bm = BM25Retriever.from_defaults(nodes=nodes, similarity_top_k=5)
for qq in ("What is machine learning?", "neural networks deep learning", "supervised learning techniques"):
    print(qq)
    for mode in ("reciprocal_rerank", "relative_score", "dist_based_score"):
        c0 = CALLS["query_gen"]
        fr = QueryFusionRetriever([vector_index.as_retriever(similarity_top_k=5), bm], similarity_top_k=3, num_queries=1, mode=mode, use_async=False)
        ns = fr.retrieve(qq)
        print("  ", mode, "calls", CALLS["query_gen"] - c0, [(round(n.score, 4), n.text[:22]) for n in ns])
fr = QueryFusionRetriever([vector_index.as_retriever(similarity_top_k=5), bm], retriever_weights=[0.7, 0.3], similarity_top_k=3, num_queries=1, mode="relative_score", use_async=False)
print("weights 0.7/0.3 relative 'What is machine learning?':", [(round(n.score, 4), n.text[:22]) for n in fr.retrieve("What is machine learning?")])
try:
    r = QueryFusionRetriever([vector_index.as_retriever(), bm], retriever_weights=[0.7, 0.3], mode="reciprocal_rerank", num_queries=1, use_async=False).retrieve("What is machine learning?"); print("weights with RRF: accepted", [(round(n.score, 4), n.text[:22]) for n in r])
except Exception as e: print("weights with RRF:", type(e).__name__, str(e)[:100])
print("TOTAL LLM calls:", dict(CALLS))
