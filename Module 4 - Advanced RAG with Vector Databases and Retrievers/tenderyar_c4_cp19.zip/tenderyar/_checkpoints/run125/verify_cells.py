"""Extract Cells 13 (w1_D) + 19.. (w1_E) and run them offline (Settings = HashEmb + ScriptedLLM; GenLLM for fusion)."""
import sys, re, html, os; sys.path.insert(0, ".")
src = open("_checkpoints/run124/c124_llama.py").read().split("SAMPLE_DOCUMENTS = [")[0]
g = {}; exec(src, g)
os.chdir("/data/work/m4")
def cells(f): return [html.unescape(re.sub(r"<[^>]+>", "", c)) for c in re.findall(r"<pre><code>(.*?)</code></pre>", open(f).read(), re.S)]
H = "/data/work/tenderyar/html/parts_c4/"
c13 = [c for c in cells(H + "w1_D_llama.html") if c.strip().startswith("# Cell 13")]
for c in c13 + cells(H + "w1_E_merge_fuse.html"):
    m = re.match(r"# (Cell \d+)", c.strip())
    if not m: continue
    n = int(m.group(1).split()[1])
    if n >= 23 and "GenLLM" not in g:
        exec(open("/data/work/tenderyar/_checkpoints/run125/c125_merge_fuse.py").read().split("Settings.llm = GenLLM()")[0].split('src = open')[0] + "\n", g)
    print("=====", m.group(1)); exec(c, g)
