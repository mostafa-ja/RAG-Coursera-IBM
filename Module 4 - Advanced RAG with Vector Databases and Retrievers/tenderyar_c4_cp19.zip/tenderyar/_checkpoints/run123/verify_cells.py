"""Extract Cells 9-12 from w1_C_parent.html and run them offline (embeddings = HashEmbeddings)."""
import sys, re, html, warnings, logging; sys.path.insert(0, "."); warnings.filterwarnings("ignore")
logging.getLogger("langchain_text_splitters.base").setLevel(logging.ERROR)
s = open("html/parts_c4/w1_C_parent.html").read()
cells = [html.unescape(re.sub(r"<[^>]+>", "", c)) for c in re.findall(r"<pre><code>(.*?)</code></pre>", s, re.S)]
from langchain_community.document_loaders import TextLoader
from tenderyar.rag.index import HashEmbeddings
embeddings = HashEmbeddings(); txt_data = TextLoader("/data/work/m4/companypolicies.txt").load()
g = dict(globals())
for i, c in enumerate(cells):
    print(f"===== cell {i+9}"); exec(c, g)
