"""CP123 extra facts: splitter warnings, child lengths, ids on add_documents, persistent docstore."""
import sys, warnings, logging, io, tempfile; sys.path.insert(0, "."); warnings.filterwarnings("ignore")
buf = io.StringIO(); h = logging.StreamHandler(buf); logging.getLogger("langchain_text_splitters.base").addHandler(h)
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from langchain_chroma import Chroma
from langchain_classic.retrievers import ParentDocumentRetriever
from langchain_classic.storage import InMemoryStore, LocalFileStore, create_kv_docstore
from tenderyar.rag.index import HashEmbeddings
txt = TextLoader("/data/work/m4/companypolicies.txt").load()
P = CharacterTextSplitter(chunk_size=1000, chunk_overlap=20, separator="\n")
C = CharacterTextSplitter(chunk_size=200, chunk_overlap=20, separator="\n")
vdb = Chroma(collection_name="pdr_x1", embedding_function=HashEmbeddings()); st = InMemoryStore()
r = ParentDocumentRetriever(vectorstore=vdb, docstore=st, child_splitter=C, parent_splitter=P)
r.add_documents(txt)
w = [l for l in buf.getvalue().splitlines() if "Created a chunk" in l]
print("warnings during add_documents", len(w), "e.g.", w[0] if w else None)
ch = vdb._collection.get()["documents"]; L = sorted(len(x) for x in ch)
print("children", len(ch), "len min/median/max", L[0], L[len(L)//2], L[-1], ">200:", sum(x > 200 for x in L))
try:
    r.add_documents(txt, ids=["policies"]); print("ids with parent_splitter: accepted")
except Exception as e: print("ids with parent_splitter:", type(e).__name__, str(e)[:120])
# no parent splitter + ids -> re-adding same id overwrites docstore, but children duplicate?
v2 = Chroma(collection_name="pdr_x2", embedding_function=HashEmbeddings()); s2 = InMemoryStore()
r2 = ParentDocumentRetriever(vectorstore=v2, docstore=s2, child_splitter=C)
r2.add_documents(txt, ids=["policies"]); r2.add_documents(txt, ids=["policies"])
print("no parent_splitter, same ids twice: parents", len(list(s2.yield_keys())), "children", v2._collection.count())
# persistent docstore
d = tempfile.mkdtemp()
ds = create_kv_docstore(LocalFileStore(d + "/parents"))
v3 = Chroma(collection_name="pdr_x3", embedding_function=HashEmbeddings(), persist_directory=d + "/chroma")
r3 = ParentDocumentRetriever(vectorstore=v3, docstore=ds, child_splitter=C, parent_splitter=P); r3.add_documents(txt)
ds2 = create_kv_docstore(LocalFileStore(d + "/parents"))
v4 = Chroma(collection_name="pdr_x3", embedding_function=HashEmbeddings(), persist_directory=d + "/chroma")
r4 = ParentDocumentRetriever(vectorstore=v4, docstore=ds2, child_splitter=C, parent_splitter=P)
g = r4.invoke("smoking policy")
print("reopened persistent: parents", len(list(ds2.yield_keys())), "children", v4._collection.count(), "returned", len(g), "len0", len(g[0].page_content))
r5 = ParentDocumentRetriever(vectorstore=v4, docstore=InMemoryStore(), child_splitter=C, parent_splitter=P)
print("reopened chroma + EMPTY InMemoryStore -> returned", len(r5.invoke("smoking policy")))
r6 = ParentDocumentRetriever(vectorstore=vdb, docstore=st, child_splitter=C, parent_splitter=P, search_kwargs={"k": 10})
print("k=10 children -> parents", len(r6.invoke("smoking policy")))
# vector store that already holds plain chunks (no doc_id) from 1.1
from langchain_text_splitters import RecursiveCharacterTextSplitter
pre = Chroma.from_documents(RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20).split_documents(txt), HashEmbeddings(), collection_name="pdr_pre")
r7 = ParentDocumentRetriever(vectorstore=pre, docstore=InMemoryStore(), child_splitter=C, parent_splitter=P)
r7.add_documents(txt)
try:
    g7 = r7.invoke("smoking policy"); print("mixed collection: returned", len(g7))
except Exception as e: print("mixed collection:", type(e).__name__, str(e)[:120])
hits = pre.similarity_search("smoking policy", k=4)
print("mixed collection top-4 hits with doc_id:", sum("doc_id" in h.metadata for h in hits), "of 4; total", pre._collection.count())
