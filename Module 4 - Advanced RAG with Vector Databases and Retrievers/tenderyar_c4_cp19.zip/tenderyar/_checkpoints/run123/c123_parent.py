"""CP123 real offline outputs for w1-pd: real LangChain ParentDocumentRetriever (langchain_classic) + InMemoryStore,
HashEmbeddings stand-in for Gemini embeddings, companypolicies.txt (lab data)."""
import sys, warnings, logging; sys.path.insert(0, "."); warnings.filterwarnings("ignore")
logging.getLogger("langchain_text_splitters.base").setLevel(logging.ERROR)
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from langchain_chroma import Chroma
from langchain_classic.retrievers import ParentDocumentRetriever
from langchain_core.stores import InMemoryStore
from tenderyar.rag.index import HashEmbeddings
txt = TextLoader("/data/work/m4/companypolicies.txt").load()
print("source docs", len(txt), "chars", len(txt[0].page_content))
parent_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=20, separator="\n")
child_splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=20, separator="\n")
vectordb = Chroma(collection_name="split_parents", embedding_function=HashEmbeddings())
store = InMemoryStore()
r = ParentDocumentRetriever(vectorstore=vectordb, docstore=store, child_splitter=child_splitter, parent_splitter=parent_splitter)
r.add_documents(txt)
keys = list(store.yield_keys())
print("parents in store", len(keys), "children in chroma", vectordb._collection.count())
pl = [len(store.mget([k])[0].page_content) for k in keys]
print("parent len min/avg/max", min(pl), round(sum(pl)/len(pl)), max(pl))
sub = vectordb.similarity_search("smoking policy")
print("sub_docs", len(sub), "len0", len(sub[0].page_content), "meta keys", list(sub[0].metadata))
print("SUB0:", repr(sub[0].page_content))
got = r.invoke("smoking policy")
print("retrieved", len(got), "len0", len(got[0].page_content))
print("GOT0 head:", repr(got[0].page_content[:300]))
print("child in parent:", sub[0].page_content in got[0].page_content)
print("search_kwargs default", r.search_kwargs, "id_key", r.id_key)
print("children per parent:", {k[:8]: n for k, n in __import__('collections').Counter(m['doc_id'] for m in vectordb._collection.get()['metadatas']).items()})
# variant: no parent_splitter -> whole document returned
v2 = Chroma(collection_name="full_docs", embedding_function=HashEmbeddings()); s2 = InMemoryStore()
r2 = ParentDocumentRetriever(vectorstore=v2, docstore=s2, child_splitter=child_splitter)
r2.add_documents(txt)
g2 = r2.invoke("smoking policy")
print("no parent_splitter: parents", len(list(s2.yield_keys())), "children", v2._collection.count(), "returned", len(g2), "len", len(g2[0].page_content))
# second query
for q in ["Can I use my work laptop for personal things?", "How many vacation days do I get?"]:
    s = vectordb.similarity_search(q); g = r.invoke(q)
    print("Q", q, "| children", len(s), "-> parents", len(g), [len(x.page_content) for x in g], "| first child:", repr(s[0].page_content[:60]))
# add_documents twice -> duplicates?
r.add_documents(txt)
print("after 2nd add_documents: parents", len(list(store.yield_keys())), "children", vectordb._collection.count())
