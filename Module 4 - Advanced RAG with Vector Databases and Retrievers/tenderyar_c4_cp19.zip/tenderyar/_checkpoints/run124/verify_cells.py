"""Extract code cells from w1_D_llama.html and run them offline (Settings = HashEmb + ScriptedLLM from c124_llama.py)."""
import sys, re, html; sys.path.insert(0, ".")
src = open("_checkpoints/run124/c124_llama.py").read().split("SAMPLE_DOCUMENTS = [")[0]
g = {}; exec(src, g)
s = open("html/parts_c4/w1_D_llama.html").read()
cells = [html.unescape(re.sub(r"<[^>]+>", "", c)) for c in re.findall(r"<pre><code>(.*?)</code></pre>", s, re.S)]
for c in cells:
    m = re.match(r"# (Cell \d+)", c.strip())
    if not m: continue
    print("=====", m.group(1)); exec(c, g)
