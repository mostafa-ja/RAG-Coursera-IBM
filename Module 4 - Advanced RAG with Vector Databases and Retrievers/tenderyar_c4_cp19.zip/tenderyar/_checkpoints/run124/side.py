"""Sidebar + w1-ret header screenshot (light/dark) for the tier-tag update. Usage: python side.py HTML OUTDIR"""
import sys, shutil, re, os
from playwright.sync_api import sync_playwright
html, out = sys.argv[1:3]; errs = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=shutil.which("chromium"))
    for dark in (0, 1):
        pg = b.new_page(viewport={"width": 1300, "height": 900}); pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.route(re.compile(r"^https?:"), lambda r: r.abort()); pg.goto("file://" + os.path.abspath(html)); pg.wait_for_timeout(400)
        if dark: pg.evaluate("theme()"); pg.wait_for_timeout(150)
        pg.locator("#side").screenshot(path=f"{out}/side_{'dark' if dark else 'light'}.png")
        pg.locator("#w1-ret .secnum").scroll_into_view_if_needed(); pg.screenshot(path=f"{out}/w1ret_head_{'dark' if dark else 'light'}.png")
        print("tags in sidebar:", pg.evaluate("[...document.querySelectorAll('#side .gh .tag')].map(t=>t.textContent+':'+getComputedStyle(t).backgroundColor).join(' | ')"))
        pg.close()
    b.close()
print("JS errors:", len(errs), errs[:5])
