"""CP124b offline run of the L-2 lab (lessons 1.5/1.6) with REAL llama-index-core classes.
Stand-ins: HashEmbeddings (char 3-grams, not semantic) instead of Gemini/bge; ScriptedLLM (deterministic rules) instead of Gemini/granite."""
import sys, re, json, warnings, collections; sys.path.insert(0, "."); warnings.filterwarnings("ignore")
from typing import Any, List
from llama_index.core import VectorStoreIndex, Document, Settings, DocumentSummaryIndex, KeywordTableIndex, SimpleKeywordTableIndex
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.indices.document_summary import DocumentSummaryIndexLLMRetriever, DocumentSummaryIndexEmbeddingRetriever
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.embeddings import BaseEmbedding
from llama_index.core.llms import CustomLLM, CompletionResponse, LLMMetadata
from llama_index.core.llms.callbacks import llm_completion_callback
from llama_index.retrievers.bm25 import BM25Retriever
import Stemmer, llama_index.core as lic
from tenderyar.rag.index import HashEmbeddings
from importlib.metadata import version
print("llama-index-core", lic.__version__, "| llama-index-retrievers-bm25", version("llama-index-retrievers-bm25"), "| bm25s", version("bm25s"))

STOP = set("a an the is of to and that can from in on with for are by its it this what how do does which about text also some questions answer provided describe".split())
CALLS = collections.Counter()

class HashEmb(BaseEmbedding):
    def _get_query_embedding(self, q): return HashEmbeddings()._vec(q)
    def _get_text_embedding(self, t): return HashEmbeddings()._vec(t)
    async def _aget_query_embedding(self, q): return self._get_query_embedding(q)

def words(s): return [w for w in re.findall(r"[a-z\-]+", s.lower()) if w not in STOP and len(w) > 2]

class ScriptedLLM(CustomLLM):
    @property
    def metadata(self): return LLMMetadata(context_window=8000, num_output=256, model_name="scripted")
    @llm_completion_callback()
    def complete(self, prompt: str, formatted: bool = False, **kw: Any) -> CompletionResponse:
        if "extract up to" in prompt:
            kind = "query_keywords" if "A question is provided" in prompt else "doc_keywords"; CALLS[kind] += 1
            body = prompt.split("---------------------\n")[1]
            return CompletionResponse(text="KEYWORDS: " + ", ".join(dict.fromkeys(words(body)))[:400])
        if "A list of documents is shown below" in prompt:
            CALLS["choice_select"] += 1
            q = set(words(prompt.rsplit("Question:", 1)[1].split("Answer:")[0]))
            docs = re.findall(r"Document (\d+):\n(.*?)(?=\n\nDocument \d+:|\n\nQuestion:)", prompt.split("Answer:", 1)[1] if prompt.count("Answer:") > 1 else prompt, re.S)
            scored = sorted(((len(q & set(words(t))), int(n)) for n, t in docs), reverse=True)
            out = [f"Doc: {n}, Relevance: {min(10, 4 + 2 * s)}" for s, n in scored if s > 0]
            return CompletionResponse(text="\n".join(out))
        CALLS["summary"] += 1   # DocumentSummaryIndex summary_query (tree_summarize)
        ctx = prompt.split("---------------------\n")[1].strip()
        first = re.split(r"(?<=\.)\s", ctx)[0]
        topic = first.split(" is ")[0].split(" uses ")[0].split(" enables ")[0].split(" allows ")[0].split(" can ")[0].split(" finds ")[0].split(" leverages ")[0].split(" are ")[0]
        return CompletionResponse(text=f"The text explains {topic.lower()}: {first} It can answer: What is {topic.lower()}?")
    @llm_completion_callback()
    def stream_complete(self, prompt, formatted=False, **kw):
        yield self.complete(prompt)

Settings.llm = ScriptedLLM(); Settings.embed_model = HashEmb()

SAMPLE_DOCUMENTS = [
    "Machine learning is a subset of artificial intelligence that focuses on algorithms that can learn from data.",
    "Deep learning uses neural networks with multiple layers to model and understand complex patterns in data.",
    "Natural language processing enables computers to understand, interpret, and generate human language.",
    "Computer vision allows machines to interpret and understand visual information from the world.",
    "Reinforcement learning is a type of machine learning where agents learn to make decisions through rewards and penalties.",
    "Supervised learning uses labeled training data to learn a mapping from inputs to outputs.",
    "Unsupervised learning finds hidden patterns in data without labeled examples.",
    "Transfer learning leverages knowledge from pre-trained models to improve performance on new tasks.",
    "Generative AI can create new content including text, images, code, and more.",
    "Large language models are trained on vast amounts of text data to understand and generate human-like text."]
Q = {"basic": "What is machine learning?", "technical": "neural networks deep learning", "learning_types": "different types of learning",
     "specific": "supervised learning techniques"}
R = {}
documents = [Document(text=t) for t in SAMPLE_DOCUMENTS]
nodes = SentenceSplitter().get_nodes_from_documents(documents)
print("== 1.5 lab init"); print(len(documents), "documents", len(nodes), "nodes")
vector_index = VectorStoreIndex.from_documents(documents); c0 = dict(CALLS)
document_summary_index = DocumentSummaryIndex.from_documents(documents); c1 = dict(CALLS)
keyword_index = KeywordTableIndex.from_documents(documents); c2 = dict(CALLS)
print("LLM calls after vector:", c0, "after summary:", c1, "after keyword:", c2)
print("vectors in vector index:", len(vector_index.vector_store.data.embedding_dict))
ds = document_summary_index
doc_ids = list(ds.index_struct.doc_id_to_summary_id.keys())
print("summary 0:", ds.get_document_summary(doc_ids[0]))
print("summary 5:", ds.get_document_summary(doc_ids[5]))
table = keyword_index.index_struct.table
print("keyword table size:", len(table), "keywords; 'learning' ->", len(table.get("learning", [])), "nodes; 'neural' ->", len(table.get("neural", [])))
print("sample keywords:", sorted(table)[:12])
simple = SimpleKeywordTableIndex.from_documents(documents)
print("SimpleKeywordTableIndex keywords:", len(simple.index_struct.table), "| LLM calls total now", dict(CALLS))
kr = keyword_index.as_retriever(); res = kr.retrieve("neural networks")
print("keyword retriever 'neural networks':", [r.text[:40] for r in res], "LLM calls", dict(CALLS))
R["init"] = dict(docs=len(documents), nodes=len(nodes), calls_vec=c0, calls_sum=c1, calls_kw=c2, kw=len(table))

print("== 1.6 Vector index retriever")
vector_retriever = VectorIndexRetriever(index=vector_index, similarity_top_k=3)
alt = vector_index.as_retriever(similarity_top_k=3)
for qk in ("basic", "technical"):
    ns = vector_retriever.retrieve(Q[qk]); print(Q[qk]); [print(f"  {n.score:.4f} {n.text[:60]}") for n in ns]
print("as_retriever same ids:", [n.node_id for n in alt.retrieve(Q["basic"])] == [n.node_id for n in vector_retriever.retrieve(Q["basic"])])
print("default similarity_top_k:", vector_index.as_retriever().similarity_top_k)

print("== 1.6 BM25")
bm25 = BM25Retriever.from_defaults(nodes=nodes, similarity_top_k=3, stemmer=Stemmer.Stemmer("english"), language="english")
for qk in ("technical", "basic", "specific"):
    ns = bm25.retrieve(Q[qk]); print(Q[qk]); [print(f"  {n.score:.4f} {n.text[:60]}") for n in ns]
ns = bm25.retrieve("neural nets"); print("'neural nets':", [(round(n.score, 4), n.text[:30]) for n in ns])
ns = bm25.retrieve("AI that writes pictures"); print("'AI that writes pictures':", [(round(n.score, 4), n.text[:30]) for n in ns])
ns = bm25.retrieve("quantum computing"); print("'quantum computing':", [(round(n.score, 4), n.text[:30]) for n in ns])
try:
    BM25Retriever.from_defaults(nodes=nodes, similarity_top_k=20).retrieve("learning"); print("top_k 20 > 10 nodes: ok")
except Exception as e: print("top_k 20 error:", type(e).__name__, str(e)[:120])

print("== 1.6 Doc summary retrievers")
n_before = CALLS["choice_select"]
llm_r = DocumentSummaryIndexLLMRetriever(ds, choice_top_k=3)
emb_r = DocumentSummaryIndexEmbeddingRetriever(ds, similarity_top_k=3)
for name, r in (("LLM", llm_r), ("EMB", emb_r)):
    ns = r.retrieve(Q["learning_types"]); print(name, len(ns)); [print(f"  {n.score} {n.text[:60]}") for n in ns]
print("choice_select calls for one query:", CALLS["choice_select"] - n_before, "(choice_batch_size default", llm_r._choice_batch_size, ")")
print("returns original text (not summary):", emb_r.retrieve(Q["learning_types"])[0].text in SAMPLE_DOCUMENTS)
print("defaults: LLM choice_top_k", DocumentSummaryIndexLLMRetriever(ds)._choice_top_k, "EMB similarity_top_k", DocumentSummaryIndexEmbeddingRetriever(ds)._similarity_top_k)

print("== Ex1 hybrid (lab solution, 0.7/0.3 max-normalised)")
vr = vector_index.as_retriever(similarity_top_k=10); br = BM25Retriever.from_defaults(nodes=nodes, similarity_top_k=10)
def hybrid_retrieve(query, top_k=5):
    v, b = vr.retrieve(query), br.retrieve(query)
    mv = max([r.score for r in v]) if v else 1; mb = max([r.score for r in b]) if b else 1
    vs = {r.text.strip(): r.score / mv for r in v}; bs = {r.text.strip(): r.score / mb for r in b}
    out = [(0.7 * vs.get(t, 0) + 0.3 * bs.get(t, 0), vs.get(t, 0), bs.get(t, 0), t) for t in set(vs) | set(bs)]
    return sorted(out, reverse=True)[:top_k]
for q in ("What is machine learning?", "neural networks deep learning", "supervised learning techniques"):
    print(q); [print(f"  {h:.3f} (v {a:.3f}, bm25 {b:.3f}) {t[:50]}") for h, a, b, t in hybrid_retrieve(q, 3)]
print("BM25 default top_k=10 on 'neural networks deep learning' returns", len(br.retrieve("neural networks deep learning")), "nodes")
print("TOTAL LLM calls:", dict(CALLS))
