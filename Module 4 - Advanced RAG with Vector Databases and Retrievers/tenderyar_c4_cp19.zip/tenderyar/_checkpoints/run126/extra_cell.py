# Cell 23 · QueryFusionRetriever, RRF mode (lab 6.1) — 1 retriever, 3 queries
from llama_index.core.retrievers import QueryFusionRetriever

query = "What are the main approaches to machine learning?"   # = DEMO_QUERIES["comprehensive"]
base_retriever = lab.vector_index.as_retriever(similarity_top_k=5)

rrf_fusion = QueryFusionRetriever(
    [base_retriever],
    similarity_top_k=3,       # final list length
    num_queries=3,            # 3 = the original + 2 written by the LLM (1 LLM call)
    mode="reciprocal_rerank",
    use_async=False,
    verbose=True)             # prints the generated queries

for i, n in enumerate(rrf_fusion.retrieve(query), 1):
    print(f"{i}. RRF {n.score:.4f}  {n.text[:45]}")
# Cell 24 · look inside: record the lists RRF fused, then recompute the scores by hand
from llama_index.core.retrievers import BaseRetriever

class Spy(BaseRetriever):                      # wraps a retriever, keeps (query, [(text, raw score)])
    def __init__(self, inner):
        super().__init__(); self.inner, self.log = inner, []
    def _retrieve(self, query_bundle):
        res = self.inner.retrieve(query_bundle)
        self.log.append((query_bundle.query_str, [(n.text, n.score) for n in res]))   # copy NOW:
        return res                             # fusion later overwrites n.score in place

spy = Spy(base_retriever)
fused = QueryFusionRetriever([spy], similarity_top_k=3, num_queries=3,
                             mode="reciprocal_rerank", use_async=False).retrieve(query)
for q, res in spy.log:
    print(repr(q[:40]), [t.split()[0] for t, s in res])

def manual_rrf(lists, k=60):                   # LlamaIndex counts rank from 0 → best = 1/60
    score = {}
    for lst in lists:
        for rank, (text, s) in enumerate(sorted(lst, key=lambda x: x[1], reverse=True)):
            score[text] = score.get(text, 0) + 1 / (rank + k)
    return sorted(score.items(), key=lambda x: -x[1])

for (t, s), n in zip(manual_rrf([res for _, res in spy.log]), fused):
    print(f"manual {s:.4f} | library {n.score:.4f}  {t[:40]}")
print("RAW LISTS")
for q, res in spy.log: print(repr(q[:40]), [(t.split()[0], round(s,4)) for t, s in res])
import statistics
ls=[res for _,res in spy.log]
def rel(ls, dist=False):
    out={}
    for lst in ls:
        sc=[s for _,s in lst]
        if dist:
            m=sum(sc)/len(sc); sd=(sum((x-m)**2 for x in sc)/len(sc))**.5; lo,hi=m-3*sd,m+3*sd
        else: lo,hi=min(sc),max(sc)
        for t,s in lst: out[t]=out.get(t,0)+(s-lo)/(hi-lo)/len(ls)
    return sorted(out.items(), key=lambda x:-x[1])[:3]
print("manual relative (k=5 lists)", [(t.split()[0], round(s,4)) for t,s in rel(ls)])
print("per-list min-max ML:", [round((dict(l)[next(t for t,_ in l if t.startswith('Machine'))]-min(s for _,s in l))/(max(s for _,s in l)-min(s for _,s in l)),3) for l in ls])
print("lab formula score/max, ML:", round(sum(dict(l).get(next(t for t,_ in ls[0] if t.startswith('Machine')),0)/max(s for _,s in l) for l in ls)/3,4))
a=base_retriever.retrieve(query); s0=a[0].score
QueryFusionRetriever([base_retriever], num_queries=1, mode="reciprocal_rerank", use_async=False)._reciprocal_rerank_fusion({("q",0): a})
print("score mutated in place:", round(s0,4), "->", round(a[0].score,4))
