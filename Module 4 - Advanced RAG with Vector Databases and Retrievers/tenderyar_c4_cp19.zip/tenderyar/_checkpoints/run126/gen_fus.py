"""Fill fus_template.html with Cells 23-26 (cells/*.py, comment-highlighted) + real outputs (cells_out.txt) → append to w1_E_merge_fuse.html."""
import html, re
R = "/data/work/tenderyar/"; D = R + "_checkpoints/run126/"
def hl(code):
    out = []
    for line in code.rstrip("\n").split("\n"):
        e = html.escape(line, quote=False); i = e.find("# ")
        if i == -1 and e.startswith("#"): i = 0
        out.append(e if i == -1 else e[:i] + '<span class="c">' + e[i:] + "</span>")
    return "\n".join(out)
outs = {}; cur = None
for line in open(D + "cells_out.txt").read().split("\n"):
    m = re.match(r"===== # Cell (\d+)", line)
    if m: cur = m.group(1); outs[cur] = []; continue
    if line.strip().startswith("[LLM query-gen calls") or cur is None: continue
    outs[cur].append(line)
t = open(D + "fus_template.html").read()
for n in ("23", "24", "25", "26"):
    t = t.replace("{c%s}" % n, hl(open(D + f"cells/c{n}.py").read()))
    t = t.replace("{o%s}" % n, '<span class="c"># output (offline run)</span>\n' + html.escape("\n".join(outs[n]).strip("\n"), quote=False))
assert "{c" not in t and "{o" not in t
P = R + "html/parts_c4/w1_E_merge_fuse.html"; p = open(P).read()
if 'id="w1-fus"' in p: p = p[:p.index('<article class="lesson" data-track="" id="w1-fus">')].rstrip("\n") + "\n"
open(P, "w").write(p + t); print("part", len(p + t), "bytes")
