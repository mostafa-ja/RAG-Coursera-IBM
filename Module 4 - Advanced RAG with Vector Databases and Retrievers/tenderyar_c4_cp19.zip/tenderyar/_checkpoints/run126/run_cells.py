"""CP125b: extract Cell 13 (w1_D) + Cells 23-26 (w1_E) from the HTML (or cells/*.py with --py) and run them offline:
HashEmb (run124) for Gemini embeddings, GenLLM (run125, scripted query generator, counts calls) for Gemini."""
import sys, re, html, os, glob; sys.path.insert(0, "."); R = "/data/work/tenderyar/"
g = {}; exec(open(R + "_checkpoints/run124/c124_llama.py").read().split("SAMPLE_DOCUMENTS = [")[0], g)
src = open(R + "_checkpoints/run125/c125_merge_fuse.py").read()
gen = src[src.index("CALLS = collections.Counter()"):src.index("Settings.llm = GenLLM()")]
exec("import re, collections\nfrom typing import Any\nfrom llama_index.core.llms import CustomLLM, CompletionResponse, LLMMetadata\n"
     "from llama_index.core.llms.callbacks import llm_completion_callback\n" + gen, g)
def cells(f): return [html.unescape(re.sub(r"<[^>]+>", "", c)) for c in re.findall(r"<pre><code>(.*?)</code></pre>", open(f).read(), re.S)]
c13 = [c for c in cells(R + "html/parts_c4/w1_D_llama.html") if c.strip().startswith("# Cell 13")]
if "--py" in sys.argv: new = [open(p).read() for p in sorted(glob.glob(R + "_checkpoints/run126/cells/c2*.py"))]
else: new = [c for c in cells(R + "html/parts_c4/w1_E_merge_fuse.html") if re.match(r"# Cell 2[3-9]", c.strip())]
os.chdir("/data/work/m4")
print("=====", "Cell 13"); exec(c13[0], g)
from llama_index.core import Settings
Settings.llm = g["GenLLM"]()
for c in new:
    print("=====", c.strip().split("\n")[0]); c0 = g["CALLS"]["query_gen"]; exec(c, g)
    print("   [LLM query-gen calls in this cell:", g["CALLS"]["query_gen"] - c0, "]")
