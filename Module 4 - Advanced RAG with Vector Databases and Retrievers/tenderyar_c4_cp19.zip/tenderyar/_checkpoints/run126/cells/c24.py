# Cell 24 · look inside: record the lists RRF fused, then recompute the scores by hand
from llama_index.core.retrievers import BaseRetriever

class Spy(BaseRetriever):                      # wraps a retriever, keeps (query, [(text, raw score)])
    def __init__(self, inner):
        super().__init__(); self.inner, self.log = inner, []
    def _retrieve(self, query_bundle):
        res = self.inner.retrieve(query_bundle)
        self.log.append((query_bundle.query_str, [(n.text, n.score) for n in res]))   # copy NOW:
        return res                             # fusion later overwrites n.score in place

spy = Spy(base_retriever)
fused = QueryFusionRetriever([spy], similarity_top_k=3, num_queries=3,
                             mode="reciprocal_rerank", use_async=False).retrieve(query)
for q, res in spy.log:
    print(repr(q[:40]), [t.split()[0] for t, s in res])

def manual_rrf(lists, k=60):                   # LlamaIndex counts rank from 0 → best = 1/60
    score = {}
    for lst in lists:
        for rank, (text, s) in enumerate(sorted(lst, key=lambda x: x[1], reverse=True)):
            score[text] = score.get(text, 0) + 1 / (rank + k)
    return sorted(score.items(), key=lambda x: -x[1])

for (t, s), n in zip(manual_rrf([res for _, res in spy.log]), fused):
    print(f"manual {s:.4f} | library {n.score:.4f}  {t[:40]}")
