# Cell 26 · hybrid = vector + BM25 in one QueryFusionRetriever, no LLM call (num_queries=1)
from llama_index.retrievers.bm25 import BM25Retriever

vector_r = lab.vector_index.as_retriever(similarity_top_k=5)
bm25_r = BM25Retriever.from_defaults(nodes=lab.nodes, similarity_top_k=5)

for q in ["What is machine learning?", "neural networks deep learning", "supervised learning techniques"]:
    print(q)
    for mode in ["reciprocal_rerank", "relative_score", "dist_based_score"]:
        hybrid = QueryFusionRetriever([vector_r, bm25_r], similarity_top_k=3,
                                      num_queries=1, mode=mode, use_async=False)
        print(f"  {mode:18}", [(round(n.score, 4), n.text[:16]) for n in hybrid.retrieve(q)])

# weights: used by relative_score / dist_based_score, IGNORED by reciprocal_rerank
for mode in ["relative_score", "reciprocal_rerank"]:
    w = QueryFusionRetriever([vector_r, bm25_r], retriever_weights=[0.7, 0.3], similarity_top_k=3,
                             num_queries=1, mode=mode, use_async=False)
    print("0.7/0.3", mode, [(round(n.score, 4), n.text[:16]) for n in w.retrieve("What is machine learning?")])
