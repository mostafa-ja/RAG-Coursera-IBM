# Cell 23 · QueryFusionRetriever, RRF mode (lab 6.1) — 1 retriever, 3 queries
from llama_index.core.retrievers import QueryFusionRetriever

query = "What are the main approaches to machine learning?"   # = DEMO_QUERIES["comprehensive"]
base_retriever = lab.vector_index.as_retriever(similarity_top_k=5)

rrf_fusion = QueryFusionRetriever(
    [base_retriever],
    similarity_top_k=3,       # final list length
    num_queries=3,            # 3 = the original + 2 written by the LLM (1 LLM call)
    mode="reciprocal_rerank",
    use_async=False,
    verbose=True)             # prints the generated queries

for i, n in enumerate(rrf_fusion.retrieve(query), 1):
    print(f"{i}. RRF {n.score:.4f}  {n.text[:45]}")
