# Cell 25 · the same query, the other 3 fusion modes (lab 6.2, 6.3 + the default)
for mode, k in [("relative_score", 5), ("dist_based_score", 8), ("simple", 5)]:
    fusion = QueryFusionRetriever(
        [lab.vector_index.as_retriever(similarity_top_k=k)],
        similarity_top_k=3, num_queries=3, mode=mode, use_async=False)
    print(mode, [(round(n.score, 4), n.text[:20]) for n in fusion.retrieve(query)])

d = QueryFusionRetriever([base_retriever])            # what you get with no arguments
print("defaults:", d.mode, "| num_queries", d.num_queries, "| similarity_top_k", d.similarity_top_k)
