"""Extract Cells 4-8 from w1_B_mq_sq.html and run them offline (llm = scripted chat model, embeddings = HashEmbeddings)."""
import sys, re, html, warnings; sys.path.insert(0, "."); warnings.filterwarnings("ignore")
s = open("html/parts_c4/w1_B_mq_sq.html").read()
cells = [html.unescape(re.sub(r"<[^>]+>", "", c)) for c in re.findall(r"<pre><code>(.*?)</code></pre>", s, re.S)]
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from tenderyar.rag.index import HashEmbeddings
embeddings = HashEmbeddings()
chunks = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20).split_documents(TextLoader("/data/work/m4/companypolicies.txt").load())
vectordb = Chroma.from_documents(chunks, embeddings, collection_metadata={"hnsw:space": "cosine"})
alts = "What is the policy on personal use of company computers?\nAre employees allowed to use company devices for private purposes?\nWhat are the rules for using the internet and email at work for personal reasons?"
def j(q, f): return '```json\n{"query": "%s", "filter": "%s"}\n```' % (q, f.replace('"', '\\"'))
llm = FakeListChatModel(responses=[alts, j(" ", 'gt("rating", 8.5)'), j("women", 'eq("director", "Greta Gerwig")'),
      j(" ", 'and(gt("rating", 8.5), eq("genre", "science fiction"))'), j(" ", 'eq("director", "Christopher Nolan")'), j(" ", 'eq("director", "Christopher Nolan")')])
g = dict(globals())
for i, c in enumerate(cells):
    c = "\n".join(l for l in c.splitlines() if not l.lstrip().startswith("!"))
    print(f"===== cell {i+4}"); exec(c, g)
