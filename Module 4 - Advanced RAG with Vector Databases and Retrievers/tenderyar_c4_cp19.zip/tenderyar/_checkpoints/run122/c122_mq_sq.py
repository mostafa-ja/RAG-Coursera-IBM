"""CP122 real offline outputs for w1-mq / w1-sq: real LangChain MultiQueryRetriever + SelfQueryRetriever,
LLM replaced by FakeListChatModel (scripted replies = what an LLM is asked to emit), HashEmbeddings stand-in."""
import sys, logging, warnings; sys.path.insert(0, "."); warnings.filterwarnings("ignore")
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_classic.retrievers.multi_query import MultiQueryRetriever
from langchain_classic.chains.query_constructor.base import AttributeInfo
from langchain_classic.retrievers.self_query.base import SelfQueryRetriever
from tenderyar.rag.index import HashEmbeddings
import langchain_classic, langchain_core, chromadb
print("versions", langchain_classic.__version__ if hasattr(langchain_classic,'__version__') else '?', langchain_core.__version__, chromadb.__version__)
docs = TextLoader("/data/work/m4/companypolicies.txt").load()
chunks = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20).split_documents(docs)
vs = Chroma.from_documents(chunks, HashEmbeddings(), collection_name="mq_pol", collection_metadata={"hnsw:space": "cosine"})
q = "Can I use my work laptop for personal things?"
base = vs.as_retriever()
b = base.invoke(q)
print("--- base", len(b)); [print("  ", repr(d.page_content[:60])) for d in b]
alts = "What is the policy on personal use of company computers?\nAre employees allowed to use company devices for private purposes?\nWhat are the rules for using the internet and email at work for personal reasons?"
llm = FakeListChatModel(responses=[alts])
logging.basicConfig(); logging.getLogger("langchain_classic.retrievers.multi_query").setLevel(logging.INFO)
mq = MultiQueryRetriever.from_llm(retriever=base, llm=llm)
m = mq.invoke(q)
print("--- mq", len(m)); [print("  ", repr(d.page_content[:60])) for d in m]
print("include_original default:", mq.include_original)
for a in alts.split("\n"):
    r = base.invoke(a); print("   per-query", len(r), [d.page_content[:25] for d in r])
print("prompt:", mq.llm_chain.first.template if hasattr(mq.llm_chain,'first') else '?')
# ---------- self-query
movies = [
 Document(page_content="A bunch of scientists bring back dinosaurs and mayhem breaks loose", metadata={"year": 1993, "rating": 7.7, "genre": "science fiction"}),
 Document(page_content="Leo DiCaprio gets lost in a dream within a dream within a dream within a ...", metadata={"year": 2010, "director": "Christopher Nolan", "rating": 8.2}),
 Document(page_content="A psychologist / detective gets lost in a series of dreams within dreams within dreams and Inception reused the idea", metadata={"year": 2006, "director": "Satoshi Kon", "rating": 8.6}),
 Document(page_content="A bunch of normal-sized women are supremely wholesome and some men pine after them", metadata={"year": 2019, "director": "Greta Gerwig", "rating": 8.3}),
 Document(page_content="Toys come alive and have a blast doing so", metadata={"year": 1995, "genre": "animated"}),
 Document(page_content="Three men walk into the Zone, three men walk out of the Zone", metadata={"year": 1979, "director": "Andrei Tarkovsky", "genre": "thriller", "rating": 9.9}),
]
info = [AttributeInfo(name="genre", description="The genre of the movie. One of ['science fiction', 'comedy', 'drama', 'thriller', 'romance', 'action', 'animated']", type="string"),
        AttributeInfo(name="year", description="The year the movie was released", type="integer"),
        AttributeInfo(name="director", description="The name of the movie director", type="string"),
        AttributeInfo(name="rating", description="A 1-10 rating for the movie", type="float")]
mv = Chroma.from_documents(movies, HashEmbeddings(), collection_name="movies")
def j(query, flt): return '```json\n{"query": "%s", "filter": "%s"}\n```' % (query, flt.replace('"', '\\"'))
replies = [j(" ", 'gt("rating", 8.5)'),
           j("women", 'eq("director", "Greta Gerwig")'),
           j(" ", 'and(gt("rating", 8.5), eq("genre", "science fiction"))'),
           j(" ", 'eq("director", "Christopher Nolan")'),
           j(" ", 'eq("director", "Chris Nolan")')]
try:
    SelfQueryRetriever.from_llm(FakeListChatModel(responses=["x"]), mv, "Brief summary of a movie.", info)
    print("auto translator OK")
except ImportError as e:
    print("auto translator ImportError:", str(e)[:90])
from langchain_community.query_constructors.chroma import ChromaTranslator
sq = SelfQueryRetriever.from_llm(FakeListChatModel(responses=replies), mv, "Brief summary of a movie.", info, structured_query_translator=ChromaTranslator())
for uq in ["I want to watch a movie rated higher than 8.5", "Has Greta Gerwig directed any movies about women",
           "What's a highly rated (above 8.5) science fiction film?", "I want to watch a movie directed by Christopher Nolan",
           "a Chris Nolan movie (LLM shortens name)"]:
    sq_struct = sq.query_constructor  # just to show it exists
    r = sq.invoke(uq)
    print("--- sq", uq, "->", len(r), [(d.metadata.get("year"), d.metadata.get("director"), d.metadata.get("rating")) for d in r])
# show translated filter
from langchain_classic.chains.query_constructor.base import StructuredQueryOutputParser
p = StructuredQueryOutputParser.from_components()
sqobj = p.parse(j(" ", 'and(gt("rating", 8.5), eq("genre", "science fiction"))'))
print("structured:", sqobj)
print("chroma kwargs:", sq.structured_query_translator.visit_structured_query(sqobj))
sqobj = p.parse(j("women", 'eq("director", "Greta Gerwig")'))
print("chroma kwargs2:", sq.structured_query_translator.visit_structured_query(sqobj))
print("prompt head:", sq.query_constructor.first.format(query="QQ")[:600] if hasattr(sq.query_constructor,'first') else '?')
