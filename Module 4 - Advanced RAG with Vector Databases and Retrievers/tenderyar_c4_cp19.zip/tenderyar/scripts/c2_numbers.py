"""Numbers for proj-s1..s3 (offline, no key) -> docs/results_c2_numbers.json. Same code as notebook cells marked 'offline'.
python scripts/c2_numbers.py"""
import json, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from tenderyar.normalize import report
from tenderyar.rag.loaders import load_pdf, load_pdf_pypdf, rtl_order_score, unshape
from tenderyar.rag.splitter import split_docs, persian_splitter, fixed_splitter, plain_recursive
from tenderyar.rag.index import HashEmbeddings, build_index

out = {}
P = "data/packages/P01.pdf"
mu_raw = load_pdf(P, fix=False); mu = load_pdf(P); py = load_pdf_pypdf(P)
rows = []
for a, b, c in zip(mu_raw, mu, py):
    r = report(b.page_content)
    rows.append({"page": b.metadata["page"], "chars": len(b.page_content), "arabic_yeh_kaf_raw": report(unshape(c.page_content)).get("arabic_yeh_kaf"),
                 "zwnj": r.get("zwnj"), "rtl_pypdf": rtl_order_score(c.page_content),
                 "rtl_pymupdf_raw": a.metadata["rtl_score_raw"], "rtl_pymupdf_fixed": rtl_order_score(b.page_content)})
out["s1_table"] = rows
out["s1_report_keys"] = list(report("ي").keys())
out["s1_pypdf_bond_line"] = next(l for l in py[1].page_content.splitlines() if "ریال" in l)
out["s1_pymupdf_bond_line"] = next(l for l in mu[1].page_content.splitlines() if "ریال" in l)
out["s1_pymupdf_raw_bond_line"] = next(l for l in unshape(mu_raw[1].page_content).splitlines() if "ریال" in l)

docs = mu
# synthetic pages are short (128-282 chars), so the splitter comparison is scaled down: 150/200 chars (at 800 every page = 1 chunk)
import re as _re
S = {"fixed150": fixed_splitter(150, 0), "fixed200": fixed_splitter(200, 0), "recursive200": plain_recursive(200, 30), "madde200": persian_splitter(200, 30), "madde800": persian_splitter(800, 120)}
s2 = {}
for k, sp in S.items():
    ch = split_docs(docs, sp)
    L = [len(c.page_content) for c in ch]
    cut = 0
    for c in ch:
        t = next(d.page_content for d in docs if d.metadata["page"] == c.metadata["page"])
        i = t.find(c.page_content); j = i + len(c.page_content)
        if i >= 0 and j < len(t) and _re.match(r"\w", t[j]) and _re.match(r"\w", t[j - 1]): cut += 1
    p2 = [c.page_content for c in ch if c.metadata["page"] == 2]
    s2[k] = {"chunks": len(ch), "avg_len": round(sum(L) / len(L)), "max_len": max(L), "words_cut": cut, "p2_chunks": len(p2),
             "amount_with_heading": any("ماده ۵" in c and "۵,۵۵۰,۰۰۰,۰۰۰" in c for c in p2),
             "starts_with_madde": any(c.startswith("ماده ۵") for c in p2), "clause_whole": any("ماده ۵" in c and "سه ماه" in c for c in p2),
             "p2_split": [c.replace(chr(10), " / ") for c in p2]}
out["s2"] = s2

ch = split_docs(docs, persian_splitter())
def rank(store, q):
    hits = store.similarity_search(q, k=10); pg = [h.metadata["page"] for h in hits]
    return (pg.index(2) + 1 if 2 in pg else None), pg[:5]
vs = build_index(ch, embeddings=HashEmbeddings(normalise=True))
vs_raw = build_index(ch, embeddings=HashEmbeddings(normalise=False))
q = "مبلغ تضمین شرکت در مناقصه چقدر است؟"; q_ar = "مبلغ تضمين شركت در مناقصه چقدر است؟"; q_en = "How much is the bid bond?"
out["s3"] = {"chunks": len(ch), "fa_norm": rank(vs, q), "ar_norm": rank(vs, q_ar), "ar_raw": rank(vs_raw, q_ar), "en": rank(vs, q_en)}
json.dump(out, open("docs/results_c2_numbers.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "s1_table"}, ensure_ascii=False, indent=1))
for r in rows: print(r)
