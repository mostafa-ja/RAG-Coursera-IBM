"""Offline baseline for v0.2 (no API key): HashEmbeddings + offline_llm over the grid chunker × k.
python scripts/eval_c2_offline.py  -> prints a table + writes docs/results_c2_offline.json. In Colab use model/embeddings = Gemini."""
import json, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from tenderyar.rag.loaders import load_pdf
from tenderyar.rag.splitter import split_docs, persian_splitter, fixed_splitter
from tenderyar.rag.index import HashEmbeddings, build_index, retriever
from tenderyar.rag.qa import build_qa_chain
from tenderyar.rag.eval_qa import eval_qa, load_rows

rows = load_rows()
pages = {p: load_pdf(f"data/packages/{p}.pdf") for p in ("P01", "P02")}
CHUNKERS = {"fixed200": lambda: fixed_splitter(200, 0), "madde800": lambda: persian_splitter(800, 120)}
res = []
for cname, mk in CHUNKERS.items():
    vss = {p: build_index(split_docs(d, mk()), embeddings=HashEmbeddings()) for p, d in pages.items()}
    for k in (1, 3, 5, 8):
        chains = {p: build_qa_chain(retriever(vs, k=k), model="offline") for p, vs in vss.items()}
        m = eval_qa(lambda p: chains[p], rows)
        res.append({"chunker": cname, "k": k, **{x: m[x] for x in ("answer_acc", "n", "citation_acc", "refusal_ok", "n_oos", "s_per_q")}})
        print(res[-1])
# retrieval rank of the bond page (P01 p.2), normalised vs un-normalised query (Arabic ي/ك)
vs = build_index(split_docs(pages["P01"], persian_splitter()), embeddings=HashEmbeddings(normalise=True))
raw = build_index(split_docs(pages["P01"], persian_splitter()), embeddings=HashEmbeddings(normalise=False))
def rank(store, q):
    hits = store.similarity_search(q, k=10); pg = [h.metadata["page"] for h in hits]
    return pg.index(2) + 1 if 2 in pg else None
q_fa, q_ar = "مبلغ تضمین شرکت در مناقصه چقدر است؟", "مبلغ تضمين شركت در مناقصه چقدر است؟"
ranks = {"normalised_query": rank(vs, q_fa), "arabic_query_no_normalise": rank(raw, q_ar)}
print(ranks)
json.dump({"grid": res, "bond_rank": ranks}, open("docs/results_c2_offline.json", "w"), ensure_ascii=False, indent=1)
