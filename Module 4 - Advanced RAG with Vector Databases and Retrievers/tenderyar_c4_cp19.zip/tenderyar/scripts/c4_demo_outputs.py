"""Real offline outputs for the C4 notebook demo cells (7–15) -> docs/c4_demo_outputs.json (quoted in the guide)."""
import json, pathlib, sys, time
R = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(R))
from tenderyar.rag.index import HashEmbeddings, build_index
from tenderyar.rag import retrievers as T, bench as B
from tenderyar.rag.clean import search_normalize, tokens

qa = B.load_tenderqa(R / "data/tenderqa/v0.jsonl")
pages, chunks = B.load_package("P01", R)
emb = HashEmbeddings(); vs = build_index(chunks, "demo", emb)
bm, de = T.BM25(chunks, k=5), T.dense_retriever(vs, k=5)
pg = lambda docs: [d.metadata["page"] for d in docs]
out = {}
# Cell 7: three hard examples
hard = ["تضمين شركت در مناقصه", "پیش‌پرداخت چند درصد است؟", "۵,۵۵۰,۰۰۰,۰۰۰ ریال"]
out["c7"] = [{"text": h, "split": h.split(), "normalized": search_normalize(h), "tokens": tokens(h)} for h in hard]
# Cell 8: BM25 vs dense on number / paraphrase questions
probe = [q for q in qa if q["package"] == "P01" and q["gold_pages"]]
rows = []
for q in probe:
    rows.append({"id": q["id"], "type": q["type"], "q": q["question"], "gold": q["gold_pages"],
                 "bm25": pg(bm.invoke(q["question"]))[:3], "dense": pg(de.invoke(q["question"]))[:3]})
hit1 = lambda l, g: bool(l) and l[0] in g
out["c8"] = [r for r in rows if hit1(r["bm25"], r["gold"]) != hit1(r["dense"], r["gold"])][:8]
# Cell 10–11: paraphrases + MQ
out["c10"] = T.offline_paraphrases("جریمه تأخیر چقدر است؟", 3)
# Cell 12: parent retriever
pr = T.parent_retriever(pages, k=3)
kids = T.BM25([d for pdoc in pages for d in T.split_articles(pdoc)], k=1)
ans = pr.invoke("جریمه تأخیر چقدر است؟")
out["c12"] = {"n_parents": len(pr.parents) if hasattr(pr, "parents") else None,
              "top_parent_page": ans[0].metadata.get("page"), "top_parent_text": ans[0].page_content[:400],
              "len_parent": len(ans[0].page_content)}
# Cell 15: rerank demo
hy = T.hybrid(T.BM25(chunks, k=20), T.dense_retriever(vs, k=20), weights=(0.5, 0.5), k=20)
q = "سقف جریمه تاخیر چند درصد مبلغ پیمان است؟"
top20 = hy.invoke(q); rr = T.rerank(top20, q, top_n=5)
out["c15"] = {"q": q, "before": pg(top20)[:5], "after": pg(rr), "n_in": len(top20)}
# Cell 14: LLM-alone vs pre-parser
out["c14"] = []
for ph in ["مناقصه‌های راه‌سازی اصفهان با مهلت قبل از ۱۵ آبان ۱۴۰۵", "مناقصه آب بعد از ۱۵ آبان", "مناقصه‌های برق تا ۱۵ آبان",
           "مناقصه‌های همین هفته", "مناقصه‌های ماه آینده", "مهلت ۱۴۰۵/۰۸/۱۵"]:
    out["c14"].append({"q": ph, "preparser": T.jalali_filter(ph)[0], "naive": T.naive_date_filter(ph)})
(R / "docs/c4_demo_outputs.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps(out, ensure_ascii=False, indent=0)[:6000])
