"""Reproducible offline numbers for v0.4 (no key: HashEmbeddings + own BM25 + offline paraphraser/re-ranker)
    python scripts/eval_c4_offline.py   -> docs/results_c4_offline.json + docs/img/v0_4_recall.png
In Colab the notebook runs the same bench with Gemini embedding-2, Gemini paraphrases and bge-reranker-v2-m3."""
import json, pathlib, sys, tempfile
R = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(R))
from tenderyar.rag.index import HashEmbeddings
from tenderyar.rag import retrievers as T, bench as B
from tenderyar.rag.clean import search_normalize, tokens

raw_tok = B.raw_tok


def configs():
    return B.standard_configs(HashEmbeddings(), HashEmbeddings(normalise=False))


SQ_PHRASES = ["مناقصه‌های راه‌سازی اصفهان با مهلت قبل از ۱۵ آبان ۱۴۰۵", "مناقصه آب بعد از ۱۵ آبان",
              "مناقصه‌های برق تا ۱۵ آبان", "مناقصه‌های همین هفته", "مناقصه‌های ماه آینده", "مهلت ۱۴۰۵/۰۸/۱۵"]


def self_query_check():
    from tenderyar.library import store
    from tenderyar.library.cards import load_cards
    from tenderyar.rag.splitter import persian_splitter
    emb = HashEmbeddings(); out = []
    with tempfile.TemporaryDirectory() as dd:
        coll = store.get_collection(store.get_client(dd)); sp = persian_splitter()
        for c in load_cards(R / "data/cards.jsonl"):
            store.upsert_tender(coll, c, sp.split_text((R / c["text_path"]).read_text(encoding="utf-8")), emb)
        sq = T.self_query(coll, embeddings=emb, k=5)
        for ph in SQ_PHRASES:
            s = sq.structured(ph); hits = sq.invoke(ph)
            out.append({"q": ph, "query": s["query"], "filter": s["filter"],
                        "hits": [(h["tender_id"], h["meta"]["province"], h["meta"]["category"], h["meta"]["deadline_jalali"]) for h in hits]})
    return out


def main():
    qa = B.load_tenderqa(R / "data/tenderqa/v0.jsonl")
    cache = {}
    df = B.run(configs(), qa, root=R, cache=cache)
    B.plot(df[df.config.str.match(r"^\d")].reset_index(drop=True), R / "docs/img/v0_4_recall.png")
    base = df.attrs["detail"]["1 dense (v0.3 baseline)"]
    worst = sorted(base, key=lambda r: (r["mrr"], r["id"]))[:10]
    qid = {q["id"]: q for q in qa}
    out = {"table": df.drop(columns=[]).to_dict("records"),
           "by_type": {c: B.by_type(df, c).to_dict() for c in ("1 dense (v0.3 baseline)", "2 BM25 (clean tokens)", "5 hybrid + MQ + re-rank", "parent (BM25 children → article)")},
           "worst10_baseline": [{**w, "question": qid[w["id"]]["question"], "why": B.why_fails(qid[w["id"]])} for w in worst],
           "tokens_demo": {t: {"raw": raw_tok(t), "clean": tokens(t)} for t in ["مناقصه‌گزار", "تضمين شركت", "۵,۵۵۰,۰۰۰,۰۰۰ ریال", "پیش‌پرداخت"]},
           "paraphrases": T.offline_paraphrases("جریمه تأخیر چقدر است؟", 3),
           "self_query": self_query_check(), "n_questions": len(qa), "n_answerable": sum(bool(q["gold_pages"]) for q in qa)}
    (R / "docs/results_c4_offline.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(df.drop(columns=["n"]).to_string(index=False))
    for w in out["worst10_baseline"]:
        print(w["id"], w["got"], w["gold"], w["why"], w["question"])
    print(json.dumps(out["by_type"]["1 dense (v0.3 baseline)"], ensure_ascii=False))
    print(json.dumps(out["by_type"]["5 hybrid + MQ + re-rank"], ensure_ascii=False))
    print(json.dumps(out["tokens_demo"], ensure_ascii=False)); print(out["paraphrases"])
    for s in out["self_query"]:
        print(s["q"], "|", s["query"], "|", json.dumps(s["filter"], ensure_ascii=False), "|", s["hits"][:3])


if __name__ == "__main__":
    main()
