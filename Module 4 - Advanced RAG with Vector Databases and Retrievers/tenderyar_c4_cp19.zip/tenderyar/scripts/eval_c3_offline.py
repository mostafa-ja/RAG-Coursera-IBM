"""Reproducible offline numbers for v0.3 (HashEmbeddings stand-in, no key) -> docs/results_c3_offline.json.
    python scripts/eval_c3_offline.py
In Colab the notebook re-runs the same code with Gemini embedding-2 / Tooka-SBERT / bge-m3."""
import json, pathlib, sys, tempfile
R = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(R))
from tenderyar.rag.index import HashEmbeddings
from tenderyar.rag.splitter import persian_splitter
from tenderyar.library import store, search as S, match as M
from tenderyar.library.cards import load_cards
from tenderyar.library.embed_bench import bench


def build(path, emb):
    cards = load_cards(R / "data/cards.jsonl")
    coll = store.get_collection(store.get_client(path))
    sp = persian_splitter()
    for c in cards:
        store.upsert_tender(coll, c, sp.split_text((R / c["text_path"]).read_text(encoding="utf-8")), emb)
    return coll, cards


def main():
    emb = HashEmbeddings(); out = {}
    pairs = [json.loads(l) for l in open(R / "data/embed_pairs.jsonl", encoding="utf-8")]
    lb = bench({"offline HashEmbeddings (normalised)": emb, "offline HashEmbeddings (raw text)": HashEmbeddings(normalise=False)}, pairs)
    out["bench"] = lb.drop(columns=["ms/emb"]).to_dict("records")
    with tempfile.TemporaryDirectory() as d:
        coll, cards = build(d, emb)
        out["stats"] = store.stats(coll)
        w = S.build_where(province="اصفهان", category="راه و ساختمان", after="1405/08/15", max_bond=5_000_000_000)
        out["where"] = w
        q = "روکش آسفالت محور"
        out["semantic_only"] = [(h["tender_id"], h["meta"]["province"]) for h in S.search(coll, emb, q, k=5)]
        out["filtered"] = [(h["tender_id"], h["meta"]["province"], h["meta"]["deadline_jalali"]) for h in S.search(coll, emb, q, where=w, k=5)]
        gold = {g["profile"]: set(g["relevant"]) for g in map(json.loads, open(R / "data/match_gold.jsonl", encoding="utf-8"))}
        prec, top = {}, {}
        for v in ("semantic", "filter", "full"):
            ps = []
            for key, rel in gold.items():
                p = json.load(open(R / f"data/profiles/{key}.json", encoding="utf-8"))
                rows = M.match(p, coll, emb, cards, k=5, variant=v)
                ps.append(M.precision_at_k([r["tender_id"] for r in rows], rel))
                if v == "full":
                    top[key] = rows
            prec[v] = {"per_profile": dict(zip(gold, ps)), "avg": round(sum(ps) / len(ps), 3)}
        out["precision@5"], out["top5_full"] = prec, top
        n0 = coll.count(); store.update_meta(coll, "S001", deadline_jalali="1405/09/01"); dn = store.delete_tender(coll, "S002")
        out["crud"] = {"before": n0, "deleted_chunks": dn, "after": coll.count()}
    (R / "docs/results_c3_offline.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({k: out[k] for k in ("bench", "stats", "precision@5", "crud", "filtered", "semantic_only")}, ensure_ascii=False))
    print(json.dumps(out["top5_full"]["zagros"][:2], ensure_ascii=False))


if __name__ == "__main__":
    main()
