"""Build RAG_C3_Guide_v1.html from the C3 input: v13 theme + v1 title + c3m_ storage prefix
+ Appendix C (parts_c3, notebook cells filled by c3_cells.py) + sidebar group + Appendix B toolkit (parts_c3_kit, step 2c).
Usage: python html/build_c3_v1.py      + CSS/JS, bridges, hero stats, coverage P-1, cmp row (same order as build_c2_v1.py)"""
import os, subprocess, sys, re, glob
H = os.path.dirname(os.path.abspath(__file__))
src, out = f"{H}/RAG_C3_Guide_input.html", f"{H}/RAG_C3_Guide_v1.html"
subprocess.run([sys.executable, f"{H}/build_v13.py", src, out], check=True)
s = open(out, encoding="utf-8").read()
s, n = re.subn(r"<title>[^<]*</title>", "<title>Course 3 Revision Guide (v1) · Vector Databases for RAG · RAG &amp; Agentic AI</title>", s, count=1)
nkeys = s.count("c3_")
s = s.replace("c3_", "c3m_")   # input keys: c3_qs c3_kn c3_sk* c3_sum c3_prog (only storage keys use 'c3_')
assert n == 1 and nkeys > 0 and "c3_" not in s and s.rstrip().endswith("</html>")
head = s[:s.find("</head>")]
assert head.rfind("<style") == head.find('<style id="v13-theme">')  # theme = last <head> style

# 1) Appendix C · TenderYar v0.3 project section (parts_c3 A..D)
sys.path.insert(0, H); from c3_cells import fill
proj = fill("".join(open(p, encoding="utf-8").read() for p in sorted(glob.glob(f"{H}/parts_c3/*.html"))))
assert proj.count("<section") == proj.count("</section>") == 1
proj = proj.replace('<ul class="pdone">', '<p id="pdn" class="cap" style="text-align:left"></p><ul class="pdone">', 1)
anchor = '<section class="week" id="cover">'
assert s.count(anchor) == 1; s = s.replace(anchor, proj + anchor, 1)

# 2) sidebar group (before the #cover link)
subs = re.findall(r'<article class="lesson"[^>]*id="(proj-[^"]+)"><div class="secnum">([^<]*)</div><h2>(.*?)</h2>', proj)
def short(secnum, h2): return secnum.split("·")[1].strip() + " " + re.sub(r"<[^>]+>", "", h2)
grp = '<a class="gh" href="#proj">Appendix C · 🏗 Project: TenderYar v0.3</a><div class="grp">' + "".join(
    f'<a class="sub" href="#{i}">{short(n, h)}</a>' for i, n, h in subs) + "</div>"
nav_anchor = '<a class="" href="#cover">'
assert s.count(nav_anchor) == 1; s = s.replace(nav_anchor, grp + nav_anchor, 1)

# 2b) week-end bridges (TenderYar checkpoint boxes) before the </section> that precedes the next section
from bridges_c3 import BRIDGES
for nxt, box in BRIDGES.items():
    i = s.find(f'<section class="week" id="{nxt}">') if nxt != "cmp" else s.find('<section data-track="" id="cmp">'); assert i > 0, nxt
    j = s.rfind("</section>", 0, i); s = s[:j] + box + s[j:]

# 2c) Appendix B · Builder's toolkit (parts_c3_kit A..E) after #w2, before #cmp — AFTER 2b, so the w2 bridge box
#     (inserted before the </section> preceding #cmp) stays at the end of Week 2, not at the end of the kit
kit = "".join(open(p, encoding="utf-8").read() for p in sorted(glob.glob(f"{H}/parts_c3_kit/*.html")))
assert kit.count("<section") == kit.count("</section>") == 1 and not re.search(r"(?<![_a-z])c3_", kit)  # storage keys already c3m_ (file names *_c3_offline ok)
cmp_anchor = '<section data-track="" id="cmp">'
assert s.count(cmp_anchor) == 1; s = s.replace(cmp_anchor, kit + cmp_anchor, 1)
kit_ids = re.findall(r'<article class="lesson"[^>]*id="(kit-[^"]+)"', kit)
KIT_NAV = {"kit-skills": "K.1 The 10 practical skills", "kit-p1": "P1 Starter: client + ef", "kit-p2": "P2 Similarity by hand",
  "kit-p3": "P3 Collections + CRUD", "kit-p4": "P4 Metadata + where", "kit-p5": "P5 Space + HNSW knobs",
  "kit-p6": "P6 Recommender pattern", "kit-p7": "P7 Vector DB as RAG retriever", "kit-p8": "P8 Measure retrieval",
  "kit-debug": "K.2 Debugging playbook", "kit-proj": "K.3 Mini-projects"}
assert kit_ids == list(KIT_NAV), kit_ids
kgrp = '<a class="gh" href="#kit">Appendix B · 🛠 Builder\'s toolkit</a><div class="grp">' + "".join(
    f'<a class="sub" href="#{i}">{t}</a>' for i, t in KIT_NAV.items()) + "</div>"
nav_cmp = '<a class="gh" href="#cmp">Comparison tables</a>'
assert s.count(nav_cmp) == 1; s = s.replace(nav_cmp, kgrp + nav_cmp, 1)

# 3) CSS (before the v13 theme so the theme stays the last <head> style) + done-when checklist JS (same as C2 v1, key c3m_pd)
css = """<style>/* C3 v1 TenderYar v0.3 */
.prs{font-family:Vazirmatn,Tahoma,"Noto Sans Arabic",sans-serif;direction:rtl;unicode-bidi:isolate}
.rtl{direction:rtl;text-align:right;font-family:Vazirmatn,Tahoma,sans-serif;background:var(--soft);border:1px solid var(--bd);border-radius:10px;padding:10px 14px;line-height:1.9}
td.prs{text-align:right}
.pdone{list-style:none;padding-left:0}.pdone li{margin:7px 0}.pdone input{margin-right:8px;transform:scale(1.2);accent-color:var(--ok)}
.pdone li.ok label{color:var(--ok)}
.bridge{border-left:4px solid var(--ac2)!important}
svg text.prs{font-family:Vazirmatn,Tahoma,sans-serif}
</style>"""
js = """<script>/* C3 v1 TenderYar done-when checklist */
(function(){const K='c3m_pd';let S={};try{S=JSON.parse(localStorage.getItem(K)||'{}')}catch(e){}
function draw(){const b=[...document.querySelectorAll('.pdone input')];const n=b.filter(x=>x.checked).length;
 b.forEach(x=>x.closest('li').classList.toggle('ok',x.checked));const p=document.getElementById('pdn');
 if(p)p.textContent='Project checklist: '+n+'/'+b.length+' done'+(n==b.length?' — 🎉 v0.3 is ready to tag!':'')}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.pdone input').forEach(x=>{x.checked=!!S[x.dataset.k];
 x.addEventListener('change',()=>{S[x.dataset.k]=x.checked;try{localStorage.setItem(K,JSON.stringify(S))}catch(e){}draw()})});draw()})})();
</script>"""
th = '<style id="v13-theme">'
assert s.count(th) == 1; s = s.replace(th, css + th, 1)
assert s.count("</body>") == 1; s = s.replace("</body>", js + "</body>", 1)
head = s[:s.find("</head>")]; assert head.rfind("<style") == head.find(th)

# 4) hero (stats recount + Appendix C study line), coverage row P-1, cmp IBM→Colab row for the project (same order as build_c2_v1.py)
def rep1(s, a, b):
    assert s.count(a) == 1, a; return s.replace(a, b, 1)
src_s = open(src, encoding="utf-8").read()
nles, nadd = s.count('<article class="lesson"'), s.count("<svg") - src_s.count("<svg")  # 16+8 lessons; input hero says 19 diagrams
s = rep1(s, '<b>16</b><p>across 2 weeks</p>', f'<b>{nles}</b><p>2 weeks + {len(kit_ids)} toolkit cards + {len(subs)} project steps</p>')
s = rep1(s, '<b>19</b><p>concepts, pipelines &amp; code flows</p>', f'<b>{19 + nadd}</b><p>concepts, pipelines &amp; code flows</p>')
s = rep1(s, '<div class="box tip"><b class="t">Reading controls</b>',
  '<div class="box try"><b class="t">🏗 Optional project · 3–5 sessions</b><p><a href="#proj">Appendix C · TenderYar v0.3 — Tender library + company matching</a>: 60 Persian tenders in one persistent Chroma library with metadata filters, and a company profile → top-5 tenders with Persian reasons. It re-uses every week (C.0–C.4 after Week 1, C.5–C.7 after Week 2). Runs offline without a key; add <code>GOOGLE_API_KEY</code> for Gemini embeddings.</p></div>'
  '<div class="box tip"><b class="t">Reading controls</b>')
s = rep1(s, "<b>196/196 items covered.</b>", "<b>198/198 items covered.</b>")
s = rep1(s, '</table></div></section>\n<section data-track="" id="exam">',
  '<tr><th colspan="3" style="background:var(--soft2)">Appendix B toolkit · 1 item</th></tr>'
  '<tr><td>K-1 · Builder\'s toolkit: 10 practical skills tracker, 8 code patterns (client + ef, similarity, CRUD, where, space + HNSW, recommender, RAG retriever, measuring), vector-DB debugging playbook, 4 mini-projects</td>'
  '<td><a href="#kit-skills">K.1 Skills</a> · <a href="#kit-p1">P1</a>–<a href="#kit-p8">P8</a> · <a href="#kit-debug">K.2 Debugging</a> · <a href="#kit-proj">K.3 Mini-projects</a></td><td>✅</td></tr>'
  '<tr><th colspan="3" style="background:var(--soft2)">Appendix C project · 1 item</th></tr>'
  '<tr><td>P-1 · TenderYar v0.3 (kit/courses/C03.md): metrics + embedding leaderboard, persistent Chroma library, metadata filters, company matching with reasons, Gradio app</td>'
  '<td><a href="#proj-why">C.0 Why</a> · <a href="#proj-s1">C.2 Similarity</a> · <a href="#proj-s4">C.5 Matching</a> · <a href="#proj-done">C.7 Done</a></td><td>✅</td></tr>'
  '</table></div></section>\n<section data-track="" id="exam">')
s = rep1(s, '<tr><td>Backup chat provider</td>',
  '<tr><td>Embedding model choice (project)</td><td><code>SentenceTransformerEmbeddingFunction("all-MiniLM-L6-v2")</code> / watsonx embeddings</td><td>Measured, not assumed: 20 Persian query–passage pairs → leaderboard of Gemini, offline <code>HashEmbeddings</code> (<code>tenderyar/rag/index.py</code>) and optional <code>STEmbeddings</code> (<code>tenderyar/library/embed_bench.py</code>) → <a href="#proj-s1">Appendix C · C.2</a></td></tr>'
  '<tr><td>Backup chat provider</td>')

open(out, "w", encoding="utf-8").write(s); print("ok", out, len(s), "storage keys renamed:", nkeys, "project articles:", len(subs), "kit cards:", len(kit_ids), "lessons:", nles)
