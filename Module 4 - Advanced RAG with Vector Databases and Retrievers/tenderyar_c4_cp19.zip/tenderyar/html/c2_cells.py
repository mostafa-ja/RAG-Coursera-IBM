"""Fill <!--CELL:n--> placeholders in html/parts_c2/*.html with code cell n of notebooks/C2_TenderYar_v0_2.ipynb
(HTML-escaped, '# …' comments wrapped in <span class="c">). Keeps guide and notebook in sync."""
import json, re, html, os
H = os.path.dirname(os.path.abspath(__file__))
def cells():
    nb = json.load(open(f"{H}/../notebooks/C2_TenderYar_v0_2.ipynb", encoding="utf-8"))
    out = {}
    for c in nb["cells"]:
        if c["cell_type"] != "code": continue
        src = "".join(c["source"]); m = re.match(r"# Cell (\d+) · [^\n]*\n", src)
        out[int(m.group(1))] = src[m.end():]
    return out
def esc(code):
    lines = []
    for ln in html.escape(code, quote=False).split("\n"):
        m = re.search(r"(^|\s)(#[^\"']*)$", ln)          # trailing comment with no quotes after '#'
        if m: ln = ln[:m.start(2)] + f'<span class="c">{m.group(2)}</span>'
        lines.append(ln)
    return "\n".join(lines)
def fill(s):
    C = cells()
    s2 = re.sub(r"<!--CELL:(\d+)-->", lambda m: esc(C[int(m.group(1))]), s)
    assert "<!--CELL:" not in s2; return s2
if __name__ == "__main__":
    import glob
    for p in sorted(glob.glob(f"{H}/parts_c2/*.html")):
        n = len(re.findall(r"<!--CELL:\d+-->", open(p, encoding="utf-8").read())); fill(open(p, encoding="utf-8").read()); print("ok", os.path.basename(p), n, "cells")
