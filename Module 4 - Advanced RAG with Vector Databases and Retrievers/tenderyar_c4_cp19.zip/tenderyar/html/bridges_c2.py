"""Week-end 'TenderYar checkpoint' boxes inserted into the Course 2 guide. Key = id of the NEXT section."""
from bridges import box
BRIDGES = {
 "w2": box("after Week 1 (what RAG is, encoders, similarity)",
   "You now know why an LLM needs retrieved context and how text becomes vectors. Start v0.2: restore the v0.1 repo, "
   "load a Persian tender PDF and check what the computer really reads (pypdf vs PyMuPDF, reversed RTL lines). "
   "Result to see: the s1 table — PyMuPDF + <code>fix_reversed_lines</code> = 1.0 on page 2.",
   [("proj-why", "C.0 Why v0.2"), ("proj-setup", "C.1 Setup"), ("proj-s1", "C.2 Load the package")]),
 "w3": box("after Week 2 (LangChain RAG, Gradio)",
   "You now know splitters, vector stores, retrievers, the QA chain and Gradio. Build the whole v0.2 pipeline: "
   "clause-aware splitter, Chroma retriever, an LCEL chain that cites <span class=\"prs\">[ص n]</span>, and the "
   "«Ask the package» app. Result to see: the bond question answered from page 2 with a citation, a refusal for "
   "an out-of-scope question, and a running Gradio link.",
   [("proj-s2", "C.3 Split"), ("proj-s3", "C.4 Retrieve"), ("proj-s4", "C.5 Cited answers"), ("proj-s6", "C.7 Gradio app")]),
 "kit": box("after Week 3 (LlamaIndex, query engines)",
   "You now know a second framework (documents → nodes → index → query engine). Now measure your own pipeline on the 15-question "
   "test set (chunker × k), paste the best row into <code>docs/RESULTS.md</code>, tick the Done-when list and tag "
   "<code>v0.2</code>. Result to see: X/15 answers, citation accuracy, 3/3 refusals.",
   [("proj-s5", "C.6 Measure it"), ("proj-done", "C.8 Done when")]),
}
