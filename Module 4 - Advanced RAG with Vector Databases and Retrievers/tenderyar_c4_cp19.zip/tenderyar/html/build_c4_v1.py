"""build_c4_v1.py — Course 4 guide 'Advanced RAG with Vector Databases and Retrievers' (v1), built from scratch
on the C1 v14 shell (html/RAG_C1_Guide_v14.html): same <head> styles, top bar, sidebar, engines (quiz, exam,
flashcards, focus mode, toolkit tracker, done-when checklist) — content comes from html/parts_c4/<section>_*.html.
Usage: python html/build_c4_v1.py   -> html/RAG_C4_Guide_v1.html
Steps: 0 shell (head/title/c4m_ keys/tail scripts) · 1 sections from parts (placeholder if a part is missing)
       · 2 sidebar auto-built from section/article headings · 3 hero stats counted · 4 v14 theme last (build_v14.py)."""
import os, re, sys, glob, subprocess
H = os.path.dirname(os.path.abspath(__file__))
SRC, OUT, PARTS = f"{H}/RAG_C1_Guide_v14.html", f"{H}/RAG_C4_Guide_v1.html", f"{H}/parts_c4"
TITLE = "Course 4 Revision Guide (v1) · RAG &amp; Agentic AI"
c1 = open(SRC, encoding="utf-8").read()

def cut(s, a, b, start=0):
    i = s.index(a, start); j = s.index(b, i); return i, j

# ---- 0) shell pieces from C1 v14 ----
bi = c1.index("<body"); ni, nj = cut(c1, '<nav id="side">', "</nav>")
mi = c1.index("<main>"); me = c1.index("</main>")
head = re.sub(r"<title>[^<]*</title>", f"<title>{TITLE}</title>", c1[:bi], count=1)
pre = c1[bi:ni]                       # <body> + svg marker defs + readbar + top bar
tail = c1[me:]                         # </main> + all engine scripts
def c1sec(i):                          # verbatim C1 section (exam engine markup etc.)
    a = c1.index(f'id="{i}">'); a = c1.rindex("<section", 0, a); return c1[a:c1.index("</section>", a) + 10]
exam = c1sec("exam").replace('<option value="3">Week 3</option>', "")
# engine shells whose CONTENT comes from parts: gloss_*.html = <tr> rows, fcards_*.html = <div class="fc"> cards
_g, _f = c1sec("gloss"), c1sec("fcards")
GLOSS = _g[:_g.index('<table id="gt">') + 15] + "{}</table></div></section>"
FCARDS = _f[:_f.index('<div class="fc-wrap">') + 21] + "{}</div></section>"
assert GLOSS.count("{}") == FCARDS.count("{}") == 1

# ---- 1) sections in guide order: (id, eyebrow, h1, class) ----
SECTIONS = [
 ("start", "Start here", "Orientation: Course 4 on one screen", "week"),
 ("w1", "Week 1", "Advanced Retrievers: LangChain &amp; LlamaIndex", "week"),
 ("w2", "Week 2", "Vector Databases: FAISS, Chroma &amp; HNSW", "week"),
 ("cmp", "Appendix A", "Comparison tables, IBM → Colab mapping &amp; troubleshooting", ""),
 ("kit", "Appendix B · Builder's toolkit", "🛠 Practical retrieval skills for your next projects", "week"),
 ("proj", "Appendix C · Portfolio project (optional)", "🏗 Project: TenderYar v0.4 — advanced retrieval + TenderQA benchmark", "week"),
 ("cover", "Appendix", "✅ Source coverage matrix", "week"),
 ("exam", "", "", ""),
 ("gloss", "", "Glossary", ""),
 ("fcards", "", "Flashcards", ""),
 ("cheat", "", "One-page cheat sheet", ""),
 ("ex", "", "Colab-ready practice exercises", ""),
]
def placeholder(i, eb, h1, cls):
    c = f' class="{cls}"' if cls else ""
    e = f'<div class="eyebrow">{eb}</div>' if eb else ""
    return (f'<section{c} data-track="" id="{i}">{e}<h1>{h1}</h1><div class="box rem"><b class="t">🚧 Being written</b>'
            f'<p>This part is added in a later build step (see <code>_checkpoints/PROGRESS.md</code>).</p></div></section>')
body, missing = [], []
for i, eb, h1, cls in SECTIONS:
    parts = sorted(glob.glob(f"{PARTS}/{i}_*.html"))
    shell = {"gloss": GLOSS, "fcards": FCARDS}.get(i)
    if shell:                                   # rows/cards only (may be empty in early builds)
        sec = shell.replace("{}", "".join(open(p, encoding="utf-8").read() for p in parts))
        if not parts: missing.append(i)
    elif parts:
        sec = "".join(open(p, encoding="utf-8").read() for p in parts)
        if sec.count("<section") == 1 and "</section>" not in sec:   # section still being written: close it for now
            sec += "</section>"; missing.append(i + "(open)")
        assert sec.count("<section") == sec.count("</section>") == 1, i
    elif i == "exam": sec = exam
    else: sec = placeholder(i, eb, h1, cls); missing.append(i)
    assert f'id="{i}"' in sec, i
    body.append(sec)
main_body = "\n".join(body)

# ---- 2) sidebar: one group per section, one sub-link per article (secnum short + h2 text) ----
def strip(x): return re.sub(r"<[^>]+>", "", x).strip()
NAV_GH = {"start": "Start here · Orientation", "w1": "Week 1 · Advanced retrievers", "w2": "Week 2 · Vector databases",
          "cmp": "Appendix A · Comparisons &amp; IBM → Colab", "kit": "Appendix B · 🛠 Builder's toolkit",
          "proj": "Appendix C · 🏗 Project: TenderYar v0.4"}
# tier tags = C1 v14 guide map (CORE read first · APPLY when building · REF look-ups); markup copied from C1 v14 sidebar
NAV_TAG = {"start": "t-green\">CORE", "w1": "t-green\">CORE", "w2": "t-green\">CORE", "cmp": "\">REF",
           "kit": "t-orange\">APPLY", "proj": "t-orange\">APPLY"}
assert '<a class="gh" href="#start"><span class="tag t-green">CORE</span>' in c1.replace("\n", ""), "C1 v14 has no tier tags"
nav = ['<nav id="side"><h2>IBM RAG &amp; Agentic AI</h2><div class="sb-sub">Course 4 · Advanced RAG with Vector Databases and Retrievers</div>',
       c1[c1.index('<div class="bar">', ni):c1.index('<a class="gh"', ni)]]   # bar, pct, qtot, search, hr (verbatim)
for (i, eb, h1, cls), sec in zip(SECTIONS, body):
    arts = re.findall(r'<article class="lesson[^"]*"[^>]*id="([^"]+)"><div class="secnum">([^<]*)(?:<span class="tag[^"]*">[^<]*</span>)?</div><h2>(.*?)</h2>', sec)
    if i in NAV_GH:
        nav.append(f'<a class="gh" href="#{i}"><span class="tag {NAV_TAG[i]}</span>{NAV_GH[i]}</a><div class="grp">' + "".join(
            f'<a class="sub" href="#{a}">{(n.split("·")[-1].strip() + " ") if "·" in n else ""}{strip(t)}</a>' for a, n, t in arts) + "</div>")
    else:
        nav.append(f'<a class="" href="#{i}">{strip(re.search(r"<h1>(.*?)</h1>", sec).group(1))}</a>')
nav.append("</nav>")

# ---- 3) hero (stats counted from the built body) ----
cnt = dict(les=main_body.count('<article class="lesson"'), q=len(re.findall(r'<div class="q" data-a=', main_body)),
           svg=main_body.count("<svg"), fc=main_body.count('class="fc"'), gl=main_body.count("<tr><td><b>"))
hero_p = f"{PARTS}/00_hero.html"
hero = open(hero_p, encoding="utf-8").read() if os.path.exists(hero_p) else (
 '<section class="hero" id="top"><div class="eyebrow">Revision guide · IBM RAG &amp; Agentic AI · Course 4</div>'
 '<h1>Advanced RAG with Vector Databases<br/>and Retrievers</h1><p class="lead">Two weeks — advanced retrievers in LangChain '
 'and LlamaIndex, then vector databases (FAISS, Chroma, HNSW) — rewritten for <b>Google Colab</b> with the free <b>Gemini</b> models '
 '(<code>gemini-3.8-flash</code> + <code>models/gemini-embedding-2</code>) instead of watsonx.</p>'
 '<div class="hstats"><div class="card"><span class="tag">Lessons</span><b>{les}</b><p>2 weeks + toolkit + project</p></div>'
 '<div class="card"><span class="tag t-green">Quiz questions</span><b>{q}</b><p>practice + graded-style checks</p></div>'
 '<div class="card"><span class="tag t-orange">Diagrams</span><b>{svg}</b><p>retrievers, indexes &amp; pipelines</p></div>'
 '<div class="card"><span class="tag t-purple">Flashcards</span><b>{fc}</b><p>{gl} glossary terms</p></div></div>'
 '<h3>🧠 Quiz dashboard</h3><div class="qdash" id="qdash"></div></section>')
hero = hero.format(**cnt)

foot = '<p style="text-align:center;color:var(--mut)">Built from the Module 4 slides, summaries, cheat sheets, lab notebooks and the TenderYar v0.4 code.</p>'
s = head + pre + "".join(nav) + "<main>" + hero + main_body + foot + tail

# ---- 0b) storage prefix + project version strings in the engine scripts ----
nk = s.count("c1m13_"); s = s.replace("c1m13_", "c4m_")
s = s.replace("v0.1 is ready to tag!", "v0.4 is ready to tag!")
assert nk > 0 and "c1m13_" not in s and not re.search(r"c1m\d*_", s)
open(OUT, "w", encoding="utf-8").write(s)

# ---- 4) v14 theme = last <head> style ----
subprocess.run([sys.executable, f"{H}/build_v14.py", OUT, OUT], check=True, stdout=subprocess.DEVNULL)
s = open(OUT, encoding="utf-8").read(); hd = s[:s.index("</head>")]
# C1 v14 (tier-tag update) keeps one tiny .tag block AFTER the theme: it uses only theme variables (0 hex) → allowed
last = hd[hd.rfind("<style"):]
theme_last = hd.rfind("<style") == hd.find('<style id="v14-theme">')
tag_after = (hd.rfind("<style", 0, hd.rfind("<style")) == hd.find('<style id="v14-theme">')
             and "#side a.gh{display:block}" in last and not re.search(r"[:\s]#[0-9a-fA-F]{3,6}\b", last))
assert (theme_last or tag_after) and s.rstrip().endswith("</html>")
ids = re.findall(r'\sid="([^"]+)"', s); dup = sorted({x for x in ids if ids.count(x) > 1})
assert not dup, dup
nart = s.count('<article class="lesson'); nsub = s[:s.index("</nav>")].count('class="sub"')
assert nart == nsub, (nart, nsub)            # every lesson (also ⭐-tagged ones) has a sidebar link
print(f"{OUT}: {len(s)/1024:.1f} KB · {cnt} · storage keys renamed {nk} · placeholders {missing}")
