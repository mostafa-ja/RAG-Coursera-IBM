"""Week-end 'TenderYar checkpoint' boxes inserted into the Course 3 guide. Key = id of the NEXT section."""
from bridges import box
BRIDGES = {
 "w2": box("after Week 1 (vector DBs, similarity, Chroma, filters)",
   "You now know cosine / L2 / dot product, how Chroma stores documents + embeddings + metadata, and how "
   "<code>where</code> filters work. Start v0.3: compute similarity by hand, then build a persistent Chroma "
   "library of 60 tender cards on Drive and filter it by province, category, Jalali deadline and bond. "
   "Result to see: the embedding leaderboard row (offline recall@1 0.60) and the funnel 60 → 6 → 2 → 2.",
   [("proj-why", "C.0 Why v0.3"), ("proj-setup", "C.1 Setup"), ("proj-s1", "C.2 Similarity"),
    ("proj-s2", "C.3 Chroma library"), ("proj-s3", "C.4 Filters")]),
 "cmp": box("after Week 2 (CRUD, recommendation, RAG over a collection)",
   "You now know CRUD on a collection and the recommender pattern “filter by rule, rank by similarity”. Turn it "
   "into company matching: profile → hard filters → semantic score + deadline room → top-5 with Persian reasons, "
   "then wrap it in a two-tab Gradio app and tag <code>v0.3</code>. Result to see: precision@5 "
   "semantic 0.2 / filter 0.8 / full 0.933 (offline).",
   [("proj-s4", "C.5 Matching"), ("proj-s5", "C.6 Gradio app"), ("proj-done", "C.7 Done when")]),
}
