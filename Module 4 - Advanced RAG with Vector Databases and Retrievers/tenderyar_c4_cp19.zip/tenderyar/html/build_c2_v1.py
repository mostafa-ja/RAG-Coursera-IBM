"""Build RAG_C2_Guide_v1.html from the v10 C2 input: v13 theme + v1 title + c2m_ storage prefix.
Usage: python html/build_c2_v1.py   + Appendix C (parts_c2) + sidebar group; later CPs: CSS/JS, bridges, hero, coverage"""
import os, subprocess, sys, re
H = os.path.dirname(os.path.abspath(__file__))
src, out = f"{H}/RAG_C2M2_Guide_v10_input.html", f"{H}/RAG_C2_Guide_v1.html"
subprocess.run([sys.executable, f"{H}/build_v13.py", src, out], check=True)
s = open(out, encoding="utf-8").read()
s, n = re.subn(r"<title>[^<]*</title>", "<title>Course 2 Revision Guide (v1) · RAG &amp; Agentic AI</title>", s, count=1)
s = s.replace("c2m2_", "c2m_")
assert n == 1 and "c2m2_" not in s and s.rstrip().endswith("</html>")
head = s[:s.find("</head>")]
assert head.rfind("<style") == head.find('<style id="v13-theme">')  # last <head> style (body widget CSS uses vars only, as in C1 v13)

# 1) Appendix C · TenderYar v0.2 project section (parts_c2 A..D, notebook cells filled by c2_cells.py)
import glob
sys.path.insert(0, H); from c2_cells import fill
proj = fill("".join(open(p, encoding="utf-8").read() for p in sorted(glob.glob(f"{H}/parts_c2/*.html"))))
assert proj.count("<section") == proj.count("</section>") == 1
proj = proj.replace('<ul class="pdone">', '<p id="pdn" class="cap" style="text-align:left"></p><ul class="pdone">', 1)
anchor = '<section class="week" id="cover">'
assert s.count(anchor) == 1; s = s.replace(anchor, proj + anchor, 1)

# 2) sidebar group (before the #cover link)
subs = re.findall(r'<article class="lesson"[^>]*id="(proj-[^"]+)"><div class="secnum">([^<]*)</div><h2>(.*?)</h2>', proj)
def short(secnum, h2): return secnum.split("·")[1].strip() + " " + re.sub(r"<[^>]+>", "", h2)
grp = '<a class="gh" href="#proj">Appendix C · 🏗 Project: TenderYar v0.2</a><div class="grp">' + "".join(
    f'<a class="sub" href="#{i}">{short(n, h)}</a>' for i, n, h in subs) + "</div>"
nav_anchor = '<a class="" href="#cover">'
assert s.count(nav_anchor) == 1; s = s.replace(nav_anchor, grp + nav_anchor, 1)

# 2b) week-end bridges (TenderYar checkpoint boxes) before the </section> that precedes the next section
from bridges_c2 import BRIDGES
for nxt, box in BRIDGES.items():
    i = s.find(f'<section class="week" id="{nxt}">'); assert i > 0, nxt
    j = s.rfind("</section>", 0, i); s = s[:j] + box + s[j:]

# 3) CSS (before the v13 theme so the theme stays the last <head> style) + done-when checklist JS
css = """<style>/* C2 v1 TenderYar v0.2 */
.prs{font-family:Vazirmatn,Tahoma,"Noto Sans Arabic",sans-serif;direction:rtl;unicode-bidi:isolate}
.rtl{direction:rtl;text-align:right;font-family:Vazirmatn,Tahoma,sans-serif;background:var(--soft);border:1px solid var(--bd);border-radius:10px;padding:10px 14px;line-height:1.9}
td.prs{text-align:right}
.pdone{list-style:none;padding-left:0}.pdone li{margin:7px 0}.pdone input{margin-right:8px;transform:scale(1.2);accent-color:var(--ok)}
.pdone li.ok label{color:var(--ok)}
.bridge{border-left:4px solid var(--ac2)!important}
svg text.prs{font-family:Vazirmatn,Tahoma,sans-serif}
</style>"""
js = """<script>/* C2 v1 TenderYar done-when checklist */
(function(){const K='c2m_pd';let S={};try{S=JSON.parse(localStorage.getItem(K)||'{}')}catch(e){}
function draw(){const b=[...document.querySelectorAll('.pdone input')];const n=b.filter(x=>x.checked).length;
 b.forEach(x=>x.closest('li').classList.toggle('ok',x.checked));const p=document.getElementById('pdn');
 if(p)p.textContent='Project checklist: '+n+'/'+b.length+' done'+(n==b.length?' — 🎉 v0.2 is ready to tag!':'')}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.pdone input').forEach(x=>{x.checked=!!S[x.dataset.k];
 x.addEventListener('change',()=>{S[x.dataset.k]=x.checked;try{localStorage.setItem(K,JSON.stringify(S))}catch(e){}draw()})});draw()})})();
</script>"""
th = '<style id="v13-theme">'
assert s.count(th) == 1; s = s.replace(th, css + th, 1)
s = s.replace("</body>", js + "</body>", 1)
head = s[:s.find("</head>")]; assert head.rfind("<style") == head.find(th)

# 4) hero (stats recount + Appendix C study line), coverage row P-1, cmp IBM→Colab row for the project
def rep1(s, a, b):
    assert s.count(a) == 1, a; return s.replace(a, b, 1)
nles, nsvg = s.count('<article class="lesson"'), s.count("<svg")  # 46 lessons; svgs incl. 1 non-diagram in v10 (27-1=26)
s = rep1(s, '<b>37</b><p>across 3 weeks</p>', f'<b>{nles}</b><p>3 weeks + 9 project steps</p>')
s = rep1(s, '<b>26</b><p>architectures &amp; pipelines</p>', f'<b>{nsvg - 1}</b><p>architectures &amp; pipelines</p>')
s = rep1(s, '<div class="box tip"><b class="t">Reading controls</b>',
  '<div class="box try"><b class="t">🏗 Optional project · 3–5 sessions</b><p><a href="#proj">Appendix C · TenderYar v0.2 — Ask the package</a>: a Persian tender-PDF question-answering bot that re-uses every week (C.0–C.2 after Week 1, C.3–C.5 + C.7 after Week 2, C.6 + C.8 after Week 3). Runs offline without a key; add <code>GOOGLE_API_KEY</code> for Gemini.</p></div>'
  '<div class="box tip"><b class="t">Reading controls</b>')
s = rep1(s, "<b>164/164 items covered.</b>", "<b>165/165 items covered.</b>")
s = rep1(s, '</table></div></section>\n<section data-track="" id="exam">',
  '<tr><th colspan="3" style="background:var(--soft2)">Appendix C project · 1 item</th></tr>'
  '<tr><td>P-1 · TenderYar v0.2 (kit/courses/C02.md): load Persian PDFs, split, index, cited answers, eval, Gradio app</td>'
  '<td><a href="#proj-why">C.0 Why</a> · <a href="#proj-s1">C.2 Load</a> · <a href="#proj-s4">C.5 Answer</a> · <a href="#proj-done">C.8 Done</a></td><td>✅</td></tr>'
  '</table></div></section>\n<section data-track="" id="exam">')
s = rep1(s, '<tr><td>Alternative free provider</td>',
  '<tr><td><code>PyPDFLoader(path).load()</code> (W2 qabot.py)</td><td>PyMuPDF <code>fitz</code> + NFKC + <code>fix_reversed_lines</code> (<code>tenderyar/rag/loaders.py</code>) — pypdf reverses Persian numbers</td><td><a href="#proj-s1">Appendix C · C.2</a></td></tr>'
  '<tr><td>Alternative free provider</td>')

open(out, "w", encoding="utf-8").write(s); print("ok", out, len(s), "project articles:", len(subs))
