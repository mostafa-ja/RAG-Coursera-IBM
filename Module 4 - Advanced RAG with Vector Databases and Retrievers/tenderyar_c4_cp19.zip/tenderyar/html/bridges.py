"""Week-end 'TenderYar checkpoint' boxes inserted into the Course 1 guide. Key = id of the NEXT section."""
def box(title, body, links):
    a = " · ".join(f'<a href="#{i}">{t}</a>' for i, t in links)
    return (f'<div class="box try bridge" style="margin-top:28px"><b class="t">🏗 TenderYar checkpoint — {title}</b>'
            f'<p>{body}</p><p><b>Go to:</b> {a}</p></div>')
BRIDGES = {
 "w2": box("after Week 1 (prompt engineering)",
   "You now know zero-shot, few-shot, chain-of-thought and self-consistency. Use them on real Persian text: "
   "set up the repo, clean Persian letters/digits, then compare zero-shot vs few-shot and add CoT + voting. "
   "Result to see: an accuracy table for 10 notices, before and after few-shot.",
   [("proj-why","C.0 Why"),("proj-setup","C.1 Setup"),("proj-s1","C.2 Clean-up"),("proj-s2","C.3 Zero/few-shot"),("proj-s3","C.4 CoT + voting")]),
 "w3": box("after Week 2 (LangChain)",
   "You now know prompt templates, LCEL, output parsers and fallbacks. Turn the prompt into a typed chain: "
   "<code>prompt | llm | PydanticOutputParser</code> with a fallback model and a rule cross-check. "
   "Result to see: 10 valid <code>TenderCard</code> JSON files.",
   [("proj-s4","C.5 Pydantic + LCEL")]),
 "cmp": box("after Week 3 (choosing a model, Flask)",
   "You now know how to compare models and serve them. Compare 3 Gemini models on your 10 notices, then ship a "
   "Flask <code>/extract</code> API and a Gradio RTL app; finish with the Guard-the-Secret side quest and the Done-when list. "
   "Result to see: <code>model_comparison.csv</code>, a running app, a GitHub tag <code>v0.1</code>.",
   [("proj-s5","C.6 Model choice"),("proj-s6","C.7 Flask + Gradio"),("proj-guard","C.8 Guard the Secret"),("proj-done","C.9 Done when")]),
}
