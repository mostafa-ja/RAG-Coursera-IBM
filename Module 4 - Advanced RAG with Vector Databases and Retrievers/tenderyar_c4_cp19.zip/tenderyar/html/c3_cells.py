"""Fill <!--CELL:n--> placeholders in html/parts_c3/*.html with code cell n of notebooks/C3_TenderYar_v0_3.ipynb
(same escaping as c2_cells.py). Keeps guide and notebook in sync."""
import json, re, os, glob
from c2_cells import esc
H = os.path.dirname(os.path.abspath(__file__))
NB = f"{H}/../notebooks/C3_TenderYar_v0_3.ipynb"
def cells():
    out = {}
    for c in json.load(open(NB, encoding="utf-8"))["cells"]:
        if c["cell_type"] != "code": continue
        src = "".join(c["source"]); m = re.match(r"# Cell (\d+) · [^\n]*\n", src)
        out[int(m.group(1))] = src[m.end():]
    return out
def fill(s):
    C = cells(); s2 = re.sub(r"<!--CELL:(\d+)-->", lambda m: esc(C[int(m.group(1))]), s)
    assert "<!--CELL:" not in s2; return s2
if __name__ == "__main__":
    for p in sorted(glob.glob(f"{H}/parts_c3/*.html")):
        t = open(p, encoding="utf-8").read(); n = len(re.findall(r"<!--CELL:\d+-->", t)); fill(t); print("ok", os.path.basename(p), n, "cells")
