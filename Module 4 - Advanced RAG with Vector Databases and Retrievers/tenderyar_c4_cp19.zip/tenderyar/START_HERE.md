# ▶ Start here — TenderYar (مناقصه‌یار)

## Now (Course 3 · v0.3)
1. Open `html/RAG_C3_Guide_v1.html` → sidebar **Appendix C · 🏗 Project: TenderYar v0.3** (green "TenderYar checkpoint" boxes end each week). Practise the vector-DB moves in **Appendix B · 🛠 Builder's toolkit** (K.1 skills tracker, P1–P8 runnable cards, K.2 debugging playbook, K.3 mini-projects).
2. Open `notebooks/C3_TenderYar_v0_3.ipynb` in Colab; Cell 1 mounts Drive and unzips this folder. `GOOGLE_API_KEY` in Colab Secrets (or `MODE="offline"`).
3. After Week 1 → Cells 1–4 (s1 similarity + leaderboard) · Week 2 → Cells 5–13 (s2 library, s3 filters, s4 matching, s5 Gradio).
4. Fill the Gemini rows in `docs/RESULTS.md`, screenshot → `docs/img/v0_3_gradio.png`, tick proj-done, `git tag v0.3`.
5. Next (Course 4 · v0.4): new chat + `kit/NEXT_UNIT_PROMPT.md` Prompt A with row 4 (spec `kit/courses/C04.md`), attach the newest ZIP.

## Before (Course 2 · v0.2)
1. Open `html/RAG_C2_Guide_v1.html` → sidebar **Appendix C · 🏗 Project: TenderYar v0.2** (green "TenderYar checkpoint" boxes end each week).
2. Open `notebooks/C2_TenderYar_v0_2.ipynb` in Colab, upload this folder as a ZIP (Cell 1). `GOOGLE_API_KEY` in Colab Secrets (or `MODE="offline"`).
3. After Week 1 → Cells 1–4 (s1) · Week 2 → Cells 5–12 (s2–s4) and 15 (Gradio) · Week 3 → Cells 13–14 (s5 measure).
4. Paste the Cell 14 row into `docs/RESULTS.md`, screenshot → `docs/img/v0_2_gradio.png`, tick proj-done, `git tag v0.2`.
5. Next (Course 3 · v0.3): new chat + `kit/NEXT_UNIT_PROMPT.md` Prompt A with row 3 (spec `kit/courses/C03.md`), attach the newest ZIP.

## Before (Course 1)
1. Open `html/RAG_C1_Guide_v13.html` in a browser → sidebar **Appendix C · 🏗 Project: TenderYar v0.1** (also: green "TenderYar checkpoint" boxes at the end of each week).
2. Upload this folder to Google Drive (or GitHub) and open `notebooks/C1_TenderYar_v0_1.ipynb` in Colab. Add `GOOGLE_API_KEY` in Colab Secrets.
3. Run the steps after the matching week: Week 1 → steps 1–3 · Week 2 → step 4 · Week 3 → steps 5–6 + Guard the Secret.
4. Fill `docs/RESULTS.md`, tick the ✅ Done-when list in the HTML (it is saved in your browser), `git tag v0.1`.

## Next courses
* `kit/NEXT_UNIT_PROMPT.md` — copy Prompt A into a new chat, attach the course ZIP + newest TenderYar ZIP.
* `kit/courses/C02.md … C10.md` — what to build in each course (the prompt tells the AI to read the right one).
* `kit/HTML_STYLE_GUIDE.md` + `kit/svg_helpers.py` — keep every course guide in the same design.

## Map of the folder
| Folder | What |
|---|---|
| `tenderyar/` | Python package (v0.1: normalize, jalali, money, schema, prompts, extractor, evaluate, apps · v0.2: `rag/` + `apps/gradio_rag.py`) |
| `data/` | 10 synthetic notices + `gold.jsonl` · 50 synthetic (`synth/`) · v0.2 `packages/` (2 PDFs + facts) + `qa_c2.jsonl` |
| `notebooks/` | Colab notebooks per version (+ `build_nb.py`) |
| `tests/` | `pytest -q` |
| `docs/` | `MASTER_PLAN.md` (10-course plan), `REFERENCES.md` (GitHub projects), `RESULTS.md`, `AUDIT.md` (consistency check) |
| `html/` | Course 3 guide v1 (`RAG_C3_Guide_v1.html` = attached C3 draft re-themed + Appendix B/C, built by `build_c3_v1.py` from `parts_c3/` + `parts_c3_kit/`, `c3_cells.py`, `bridges_c3.py`) · Course 2 guide v1 (`RAG_C2_Guide_v1.html` = v10 input re-themed + Appendix C, built by `build_c2_v1.py` from `parts_c2/`, `c2_cells.py`, `bridges_c2.py`) · Course 1 guide v13 (Claude-like theme; v12 = old theme) + build scripts, parts, diagrams |
| `kit/` | prompts, style guide, course specs for C2–C10 |
| `_checkpoints/PROGRESS.md` | build log (for resuming an interrupted AI run) |
