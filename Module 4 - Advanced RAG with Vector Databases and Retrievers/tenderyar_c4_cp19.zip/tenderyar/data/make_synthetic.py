"""Generate N synthetic Persian tender notices + gold labels (for C3 library / C4 tests).

    python data/make_synthetic.py --n 50 --seed 7      -> data/synth/notices/S001.txt … + data/synth/gold.jsonl

Every notice is built from random parts, so the gold label is known exactly. Each one mixes the Persian
difficulties of v0.1 at random: Persian/Arabic/Latin digits, Arabic ي/ك, textual vs numeric Jalali dates,
Rial vs Toman, amounts in words, a distractor date (opening / document sale) and a distractor amount (estimate).
SYNTHETIC: names and numbers are invented. Keep real public notices in data/notices/ (N11+).
"""
import argparse, json, pathlib, random, sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from tenderyar.jalali import MONTHS, format_jalali, is_valid_jalali  # noqa: E402

H = pathlib.Path(__file__).parent
FA, AR = "۰۱۲۳۴۵۶۷۸۹", "٠١٢٣٤٥٦٧٨٩"
# (organisation pattern, category, grade field)
ORGS = [("شرکت آب و فاضلاب استان {p}", "آب", "آب"), ("شرکت توزیع نیروی برق استان {p}", "برق و انرژی", "نیرو"),
        ("اداره کل راه و شهرسازی استان {p}", "راه و ساختمان", "راه و باند"), ("شرکت گاز استان {p}", "نفت و گاز", "تأسیسات و تجهیزات"),
        ("دانشگاه علوم پزشکی {c}", "تجهیزات و کالا", None), ("شهرداری {c}", "عمرانی", "ابنیه"),
        ("اداره کل نوسازی مدارس استان {p}", "عمرانی", "ابنیه"), ("شرکت مخابرات استان {p}", "فناوری اطلاعات", None)]
SUBJECTS = {"آب": ["اجرای شبکه توزیع آب روستاهای بخش مرکزی", "احداث مخزن ۵۰۰۰ مترمکعبی"],
            "برق و انرژی": ["خرید ۸۰۰ دستگاه کنتور هوشمند", "احداث پست ۶۳ کیلوولت"],
            "راه و ساختمان": ["روکش آسفالت محور اصلی", "احداث پل روگذر"],
            "نفت و گاز": ["تعمیر و نگهداری ایستگاه‌های تقلیل فشار", "گازرسانی به ۱۲ روستا"],
            "تجهیزات و کالا": ["خرید ۴ دستگاه سی‌تی‌اسکن", "خرید تجهیزات اتاق عمل"],
            "عمرانی": ["احداث پارک محله‌ای", "ساخت مدرسه ۱۲ کلاسه"],
            "فناوری اطلاعات": ["پیاده‌سازی سامانه مدیریت شبکه", "توسعه درگاه خدمات الکترونیک"]}
PLACES = [("اصفهان", "کاشان"), ("فارس", "شیراز"), ("گیلان", "رشت"), ("خوزستان", "اهواز"), ("یزد", "یزد"),
          ("کرمان", "سیرجان"), ("خراسان رضوی", "مشهد"), ("آذربایجان شرقی", "تبریز"), ("مازندران", "ساری"), ("تهران", "تهران")]
WORDS = {1: "یک", 2: "دو", 3: "سه", 4: "چهار", 5: "پنج", 6: "شش", 7: "هفت", 8: "هشت", 9: "نه"}
HUNDREDS = {1: "یکصد", 2: "دویست", 3: "سیصد", 4: "چهارصد", 5: "پانصد", 6: "ششصد", 7: "هفتصد", 8: "هشتصد", 9: "نهصد"}


def digits(s, style):
    return s.translate(str.maketrans("0123456789", FA if style == "fa" else AR)) if style in ("fa", "ar") else s


def amount_words(rial_millions, unit):
    """e.g. 2400 (million Rial) -> 'دو میلیارد و چهارصد میلیون ریال' ; Toman divides by 10 first."""
    m = rial_millions // 10 if unit == "تومان" else rial_millions
    b, r = divmod(m, 1000)
    parts = ([WORDS[b] + " میلیارد"] if b else []) + ([HUNDREDS[r // 100] + " میلیون"] if r else [])
    return " و ".join(parts) + " " + unit


def one(i, rnd):
    org_t, cat, field = rnd.choice(ORGS)
    prov, city = rnd.choice(PLACES)
    org = org_t.format(p=prov, c=city)
    subject = rnd.choice(SUBJECTS[cat])
    ttype = rnd.choice(["مناقصه عمومی"] * 3 + ["مناقصه محدود", "فراخوان ارزیابی کیفی"])
    num = f"1405/{rnd.randint(10, 450)}" if rnd.random() < 0.6 else f"2005{rnd.randint(10**11, 10**12 - 1)}"
    jm, jd = rnd.randint(8, 11), rnd.randint(1, 28)
    while not is_valid_jalali(1405, jm, jd):
        jd -= 1
    dl = format_jalali(1405, jm, jd)
    bond_m = rnd.choice([100, 300, 500]) * rnd.randint(1, 9) + rnd.choice([0, 0, 1000, 2000])  # million Rial, multiple of 100
    unit = rnd.choice(["ریال", "ریال", "تومان"])
    dstyle = rnd.choice(["fa", "fa", "ar", "latin"])
    if rnd.random() < 0.35:
        if unit == "تومان":
            bond_m = 1000 * rnd.randint(1, 9)                  # words in Toman need whole hundreds of millions
        bond_txt = amount_words(bond_m, unit)
    else:
        v = bond_m * 10**6 // (10 if unit == "تومان" else 1)
        bond_txt = digits(f"{v:,}", dstyle) + " " + unit
    dl_txt = (digits(f"{jd} {MONTHS[jm - 1]} 1405", dstyle) if rnd.random() < 0.3 else digits(dl, dstyle))
    grade = f"رتبه {rnd.randint(1, 5)} {field}" if field and rnd.random() < 0.8 else None
    lines = [f"آگهی {ttype} شماره {digits(num, dstyle)}",
             f"{org} در نظر دارد {subject} را به پیمانکار واجد شرایط واگذار نماید."]
    if grade:
        lines.append(f"صلاحیت مورد نیاز: {digits(grade, dstyle)}")
    lines.append(f"مبلغ برآورد: {digits(f'{bond_m * 20 * 10**6:,}', dstyle)} ریال")           # distractor amount
    lines.append(f"مبلغ تضمین شرکت در فرآیند ارجاع کار: {bond_txt}")
    lines.append(f"مهلت دریافت اسناد: تا {digits(format_jalali(1405, 7, rnd.randint(22, 30)), dstyle)}")  # distractor date
    lines.append(f"آخرین مهلت ارسال پیشنهاد: ساعت {digits(str(rnd.choice([10, 14, 19])), dstyle)} روز {dl_txt}")
    lines.append(f"بازگشایی پاکات: {digits(format_jalali(1405, jm + 1, 2), dstyle)}")              # distractor date
    text = "\n".join(lines)
    if rnd.random() < 0.3:                                                                          # Arabic letters
        text = text.replace("ی", "ي").replace("ک", "ك")
    gold = dict(organization=org, subject=subject, tender_number=num, tender_type=ttype, province=prov, city=city,
                category=cat, deadline_jalali=dl, bond_amount_rial=bond_m * 10**6,
                required_grade=grade)
    return f"S{i:03d}", text, gold


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=50)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default=str(H / "synth"))
    a = ap.parse_args(argv)
    rnd, out = random.Random(a.seed), pathlib.Path(a.out)
    (out / "notices").mkdir(parents=True, exist_ok=True)
    with open(out / "gold.jsonl", "w", encoding="utf-8") as g:
        for i in range(1, a.n + 1):
            nid, text, gold = one(i, rnd)
            (out / "notices" / f"{nid}.txt").write_text(text, encoding="utf-8")
            g.write(json.dumps({"id": nid, "tests": "synthetic", **gold}, ensure_ascii=False) + "\n")
    print("wrote", a.n, "notices to", out)


if __name__ == "__main__":
    main()
