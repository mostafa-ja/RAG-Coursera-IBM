# data/packages — tender packages for TenderYar v0.2
| File | Source | Licence |
|---|---|---|
| P01.pdf, P02.pdf | **SYNTHETIC** — `python data/make_packages.py --n 2 --seed 7` (fictional organisations) | CC0 / your own |
| facts.jsonl | generated with the PDFs: true bond, deadline, penalty, duration + page of each | CC0 |
Add real public packages here with their source URL and licence (keep them out of git if the licence is unclear).
