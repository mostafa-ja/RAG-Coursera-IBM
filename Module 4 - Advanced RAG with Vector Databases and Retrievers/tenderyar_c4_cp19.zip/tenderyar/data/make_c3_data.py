"""C3 data: data/cards.jsonl (60 tenders), data/profiles/*.json (3 fake companies), data/match_gold.jsonl, data/embed_pairs.jsonl.

    python data/make_c3_data.py

cards.jsonl  = the gold TenderCards of N01–N10 + S001–S050 (decision: the cache stands in for "run v0.1 once";
               in Colab you may re-extract with Gemini and compare). Each card also stores the notice text path.
match_gold   = rule-labelled relevance (SYNTHETIC): a tender is relevant for a company when a human checker would
               say "bid": province + field + grade + bond fit AND at least 7 days left at EVAL_TODAY. Hand-check in Colab.
"""
import json, pathlib, sys
H = pathlib.Path(__file__).parent
sys.path.insert(0, str(H.parent))
from tenderyar.library.match import hard_filter, DAY  # noqa: E402
from tenderyar.library.cards import jalali_to_ts, EVAL_TODAY  # noqa: E402

PROFILES = {
 "zagros": {"name": "راه‌سازان زاگرس", "fields": ["راه و ساختمان", "عمرانی"], "grade": {"راه و باند": 3, "ابنیه": 3},
            "provinces": ["اصفهان", "یزد", "فارس", "خراسان رضوی", "کرمان"], "max_bond_rial": 8_000_000_000,
            "about": "پیمانکار راه‌سازی، روکش آسفالت، پل و ساختمان‌های عمومی مثل مدرسه و پارک"},
 "kavir": {"name": "آب‌نیرو کویر", "fields": ["آب", "برق و انرژی", "نفت و گاز"], "grade": {"آب": 2, "نیرو": 2, "تأسیسات و تجهیزات": 2},
           "provinces": ["کرمان", "یزد", "آذربایجان شرقی", "تهران", "فارس", "اصفهان"], "max_bond_rial": 6_000_000_000,
           "about": "شبکه توزیع آب، مخزن، پست برق، کنتور هوشمند و گازرسانی"},
 "shomal": {"name": "داده‌پردازان شمال", "fields": ["فناوری اطلاعات", "تجهیزات و کالا"], "grade": {},
            "provinces": ["گیلان", "مازندران", "تهران", "فارس", "خوزستان"], "max_bond_rial": 3_000_000_000,
            "about": "توسعه سامانه و درگاه الکترونیک، شبکه، و تأمین تجهیزات پزشکی و اتاق عمل"},
}


def main():
    cards = []
    for path, folder in (("gold.jsonl", "notices"), ("synth/gold.jsonl", "synth/notices")):
        for l in (H / path).read_text(encoding="utf-8").splitlines():
            if l.strip():
                c = json.loads(l); c["text_path"] = f"data/{folder}/{c['id']}.txt"; cards.append(c)
    (H / "cards.jsonl").write_text("".join(json.dumps(c, ensure_ascii=False) + "\n" for c in cards), encoding="utf-8")
    now = jalali_to_ts(EVAL_TODAY); gold = []
    for key, p in PROFILES.items():
        (H / "profiles" / f"{key}.json").write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")
        rel = [c["id"] for c in cards if hard_filter(p, c)[0] and jalali_to_ts(c["deadline_jalali"]) - now >= 7 * DAY]
        gold.append({"profile": key, "relevant": rel})
    (H / "match_gold.jsonl").write_text("".join(json.dumps(g, ensure_ascii=False) + "\n" for g in gold), encoding="utf-8")
    pairs = []
    for c in cards[10:30]:
        q = f"دنبال پروژه «{c['subject']}» در {c['city']} هستیم؛ مهلتش کی است؟"
        pairs.append({"id": c["id"], "query": q, "passage": (H.parent / c["text_path"]).read_text(encoding="utf-8")})
    (H / "embed_pairs.jsonl").write_text("".join(json.dumps(p, ensure_ascii=False) + "\n" for p in pairs), encoding="utf-8")
    print(len(cards), "cards;", {g["profile"]: len(g["relevant"]) for g in gold}, "relevant;", len(pairs), "pairs")


if __name__ == "__main__":
    main()
