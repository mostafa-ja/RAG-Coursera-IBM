"""Synthetic Persian tender packages (PDF) + gold facts for TenderYar v0.2.

python data/make_packages.py --n 2 --seed 7      # C2  (C7 later: --n 5; same seed keeps the first files identical)

Each package = 12 pages: notice · general conditions · special conditions (bond, deadline, penalty) ·
bill of quantities · bond form · penalty clauses. Text is drawn the way many real Persian PDFs are produced:
shaped glyphs in *visual* order (arabic_reshaper + python-bidi), so extraction can come out reversed — that is
exactly what proj-s1 teaches you to detect and repair. Writes data/packages/facts.jsonl (true values + page).
All files are SYNTHETIC (no real organisation, no licence issues).
"""
import argparse, glob, json, os, random
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
import arabic_reshaper
from bidi.algorithm import get_display

FA = "۰۱۲۳۴۵۶۷۸۹"
def fa(n):            # 5550000000 -> '۵٬۵۵۰٬۰۰۰٬۰۰۰'
    s = f"{n:,}" if isinstance(n, int) else str(n)
    return "".join(FA[int(c)] if c.isdigit() else ("٬" if c == "," else c) for c in s)

ORGS = ["شرکت آب و فاضلاب استان یزد", "شهرداری منطقه ۴ مشهد", "اداره کل راه و شهرسازی استان گیلان",
        "دانشگاه علوم پزشکی شیراز", "شرکت توزیع برق استان کرمان"]
WORKS = ["اجرای خط انتقال آب به طول ۱۲ کیلومتر", "بهسازی و آسفالت معابر محلی", "احداث پل بتنی روی رودخانه",
         "تکمیل ساختمان درمانگاه ۲ طبقه", "اصلاح شبکه فشار ضعیف برق"]
BONDS = [5_550_000_000, 2_340_000_000, 8_120_000_000, 1_275_000_000, 3_900_000_000]
DEADLINES = ["۱۴۰۵/۰۸/۱۵", "۱۴۰۵/۰۹/۰۳", "۱۴۰۵/۰۸/۲۸", "۱۴۰۵/۱۰/۱۲", "۱۴۰۵/۰۹/۲۰"]
DURATIONS = [9, 6, 14, 12, 8]
PENALTY = ["یک دهم درصد", "دو دهم درصد", "یک دهم درصد", "پانزده صدم درصد", "دو دهم درصد"]
FILLER = [
    "پیمانکار موظف است کلیه عملیات را طبق نقشه‌ها و مشخصات فنی پیوست اجرا کند.",
    "رعایت مقررات ایمنی و بهداشت کار در تمام مدت اجرای پیمان الزامی است.",
    "هزینه تهیه اسناد بر عهده شرکت‌کنندگان است و مسترد نمی‌شود.",
    "کارفرما در رد یا قبول هر یک از پیشنهادها مختار است.",
    "پیشنهادهای مشروط، مخدوش و فاقد تضمین ترتیب اثر داده نخواهد شد.",
    "پرداخت صورت‌وضعیت‌ها پس از تایید دستگاه نظارت انجام می‌شود.",
    "پیمانکار حق واگذاری پیمان به غیر را ندارد.",
    "تمامی کسور قانونی از صورت‌وضعیت‌ها کسر خواهد شد.",
]

def font():
    for p in ["/usr/share/fonts/truetype/vazirmatn/Vazirmatn-Regular.ttf", "Vazirmatn-Regular.ttf",
              "/usr/share/fonts/google-noto/NotoSansArabic-Regular.ttf"] + glob.glob("/usr/share/fonts/**/*Arabic*Regular*.ttf", recursive=True):
        if os.path.exists(p):
            pdfmetrics.registerFont(TTFont("FA", p)); return p
    raise SystemExit("No Persian font found: in Colab run  !wget -q https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/Vazirmatn-Regular.ttf")

def pages_for(i, rnd):
    org, work, bond = ORGS[i % 5], WORKS[i % 5], BONDS[i % 5]
    num = f"{1405}-{rnd.randint(100, 999)}"
    P = []
    P.append(["آگهی مناقصه عمومی یک مرحله‌ای", f"دستگاه مناقصه‌گزار: {org}", f"موضوع مناقصه: {work}",
              f"شماره مناقصه: {fa(num)}", f"مهلت تحویل پیشنهادها: ساعت ۱۴ روز {DEADLINES[i % 5]}",
              "محل دریافت اسناد: سامانه تدارکات الکترونیکی دولت", "شرح کامل شرایط در صفحات بعد آمده است."])
    P.append(["شرایط خصوصی پیمان", "ماده ۵ - تضمین شرکت در فرایند ارجاع کار",
              f"بند الف - مبلغ تضمین شرکت در مناقصه {fa(bond)} ریال است.",
              "بند ب - تضمین باید به صورت ضمانت‌نامه بانکی یا واریز نقدی ارائه شود.",
              "بند ج - اعتبار تضمین باید حداقل سه ماه باشد.", rnd.choice(FILLER)])
    for k in range(3):
        P.append([f"شرایط عمومی پیمان - بخش {fa(k + 1)}"] + [f"ماده {fa(10 + 3 * k + j)} - {s}" for j, s in enumerate(rnd.sample(FILLER, 3))])
    P.append(["مدت و برنامه زمانی", f"ماده ۲۰ - مدت اجرای کار {fa(DURATIONS[i % 5])} ماه شمسی از تاریخ ابلاغ قرارداد است.",
              "ماده ۲۱ - برنامه زمانی تفصیلی ظرف پانزده روز به دستگاه نظارت تحویل می‌شود.", rnd.choice(FILLER)])
    P.append(["فهرست بها و مقادیر", "ردیف ۱ - عملیات خاکی", "ردیف ۲ - بتن ریزی", "ردیف ۳ - لوله گذاری",
              "ردیف ۴ - تجهیز و برچیدن کارگاه", "مبالغ به ریال و بدون مالیات بر ارزش افزوده است."])
    P.append(["فرم ضمانت‌نامه شرکت در مناقصه", "این ضمانت‌نامه تا پایان مدت اعتبار معتبر است.",
              "در صورت انصراف برنده از انعقاد قرارداد، مبلغ ضمانت‌نامه به نفع کارفرما ضبط می‌شود."])
    P.append(["تاخیرات و جرایم", f"ماده ۳۰ - برای هر روز تاخیر، جریمه معادل {PENALTY[i % 5]} مبلغ اولیه پیمان کسر می‌شود.",
              "ماده ۳۱ - سقف جریمه تاخیر ده درصد مبلغ پیمان است.", rnd.choice(FILLER)])
    P.append(["پیش‌پرداخت", "ماده ۴۰ - پیش‌پرداخت معادل ده درصد مبلغ پیمان در برابر ضمانت‌نامه پرداخت می‌شود.", rnd.choice(FILLER)])
    P.append(["تضمین انجام تعهدات", "ماده ۴۵ - تضمین انجام تعهدات معادل پنج درصد مبلغ قرارداد است.", rnd.choice(FILLER)])
    P.append(["مدارک لازم", "ماده ۵۰ - ارائه گواهی صلاحیت پیمانکاری با رتبه معتبر الزامی است.",
              "ماده ۵۱ - صورت‌های مالی حسابرسی‌شده سال قبل ضمیمه شود."])
    facts = {"package": f"P{i + 1:02d}", "file": f"P{i + 1:02d}.pdf", "synthetic": True, "organization": org,
             "work": work, "number": num, "bond_rial": bond, "bond_page": 2, "deadline_jalali": DEADLINES[i % 5],
             "deadline_page": 1, "penalty_rate": PENALTY[i % 5], "penalty_page": 9, "duration_months": DURATIONS[i % 5],
             "duration_page": 6, "pages": len(P)}
    return P, facts

def draw(path, pages):
    c = canvas.Canvas(path, pagesize=A4); W, H = A4
    for lines in pages:
        y = H - 80
        for j, line in enumerate(lines):
            c.setFont("FA", 16 if j == 0 else 12)
            c.drawRightString(W - 60, y, get_display(arabic_reshaper.reshape(line)))   # visual order, like many real PDFs
            y -= 34 if j == 0 else 26
        c.showPage()
    c.save()

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--n", type=int, default=2); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "packages")); a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True); print("font:", font())
    rows = []
    for i in range(a.n):
        rnd = random.Random(a.seed * 100 + i)          # per-package RNG -> --n 5 keeps P01/P02 identical
        pages, facts = pages_for(i, rnd); draw(os.path.join(a.out, facts["file"]), pages); rows.append(facts)
    with open(os.path.join(a.out, "facts.jsonl"), "w", encoding="utf-8") as f:
        for r in rows: f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"wrote {a.n} packages + facts.jsonl to {a.out}")
