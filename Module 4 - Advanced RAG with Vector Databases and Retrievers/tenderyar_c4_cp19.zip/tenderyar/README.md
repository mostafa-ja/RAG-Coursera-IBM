# مناقصه‌یار · TenderYar

**Persian tender assistant.** Reads Iranian tender notices and (from v0.2) full tender packages, and answers: *can we bid, what do we need, by when, how much bond, what are the risks* — with page references.

> Built step by step while studying the IBM *RAG and Agentic AI* Professional Certificate (10 courses → v0.1 … v1.0). See `docs/MASTER_PLAN.md`.

## v0.1 (Course 1) — tender card
Paste a notice → validated JSON:

```json
{"organization": "شرکت آب و فاضلاب استان اصفهان", "tender_number": "1405/127",
 "deadline_jalali": "1405/08/10", "deadline_iso": "2026-11-01",
 "bond_amount_rial": 5550000000, "required_grade": "رتبه ۴ رشته آب", "province": "اصفهان"}
```

Why Persian is hard (and handled): Arabic ي/ك vs Persian ی/ک · half-space (ZWNJ) · Persian/Arabic digits · Jalali dates (numeric, textual, two-digit year) · amounts in Rial vs Toman and in words · prompt-injection inside documents.

| Part | File |
|---|---|
| Persian normaliser | `tenderyar/normalize.py` |
| Jalali ⇄ Gregorian (no deps) | `tenderyar/jalali.py` |
| Rial/Toman + number words | `tenderyar/money.py` |
| Pydantic `TenderCard` | `tenderyar/schema.py` |
| Zero/few-shot, CoT, self-consistency prompts | `tenderyar/prompts.py` |
| LCEL chain + fallback + rule cross-check | `tenderyar/extractor.py` |
| Field accuracy + model comparison | `tenderyar/evaluate.py` |
| Flask `POST /extract` · Gradio RTL UI | `tenderyar/apps/` |
| Colab walkthrough | `notebooks/C1_TenderYar_v0_1.ipynb` |

## v0.2 (Course 2) — ask the package
Upload a Persian tender PDF → ask in Persian → answer with page citations, or «در اسناد نیامده است» when it is not there.

```
PDF ─► PyMuPDF pages (+page no.) ─► unshape + fix_reversed_lines + normalize ─► «ماده»-aware splitter
    ─► Gemini embeddings (task_type) ─► Chroma ─► retriever k=5 ─► "answer only from context + cite" ─► Gemini ─► [ص n]
```

| Part | File |
|---|---|
| PDF loader + RTL order check/repair | `tenderyar/rag/loaders.py` |
| Persian clause-aware splitter | `tenderyar/rag/splitter.py` |
| Gemini embeddings + Chroma + retriever (offline stand-in for tests) | `tenderyar/rag/index.py` |
| Grounded QA chain with `[ص n]` citations + refusal | `tenderyar/rag/qa.py` |
| 15-question evaluation (answer / citation / refusal) | `tenderyar/rag/eval_qa.py`, `data/qa_c2.jsonl` |
| Gradio «Ask the package» | `tenderyar/apps/gradio_rag.py` |
| Synthetic packages + gold facts | `data/make_packages.py --n 2 --seed 7` → `data/packages/` |
| Colab walkthrough | `notebooks/C2_TenderYar_v0_2.ipynb` (built by `notebooks/build_nb_c2.py`) |
| Study guide (Appendix C · C.0–C.8) | `html/RAG_C2_Guide_v1.html` (built by `html/build_c2_v1.py`) |

Offline baseline (no key): «ماده»-aware, k=5 → 15/15 answers, citation acc 1.00, 3/3 refusals (`docs/RESULTS.md`).

## v0.3 (Course 3) — tender library + company matching
Many tenders in one persistent Chroma library with metadata filters (province, category, Jalali deadline, bond) and a company profile → ranked top-5 with Persian reasons.

```
notices/*.txt ─► TenderCard (data/cards.jsonl) ─► chunks ─► Chroma "tenders" (cosine, persistent, metadata)
company profile ─► hard rules (province, field, grade, deadline, bond) ─► 0.6·semantic + 0.2·deadline room + 0.2·bond fit ─► top-5 + reasons
```

| Part | File |
|---|---|
| Card → Chroma metadata, Jalali → unix ts, grade parser | `tenderyar/library/cards.py` |
| Persistent client, idempotent upsert, update/delete, stats | `tenderyar/library/store.py` |
| `build_where` ($and/$in/$gte/$lte) + grouped search | `tenderyar/library/search.py` |
| Keyword (+LLM) category classifier | `tenderyar/library/categories.py` |
| Hard filter + soft score + precision@5 | `tenderyar/library/match.py` |
| Embedding leaderboard | `tenderyar/library/embed_bench.py`, `data/embed_pairs.jsonl` |
| Gradio «کتابخانه» + «پیشنهاد برای شرکت من» | `tenderyar/apps/gradio_library.py` |
| Data | `data/make_c3_data.py` → `cards.jsonl`, `profiles/*.json`, `match_gold.jsonl` |
| Colab walkthrough | `notebooks/C3_TenderYar_v0_3.ipynb` (built by `notebooks/build_nb_c3.py`) |
| Study guide (Appendix B toolkit + Appendix C project) | `html/RAG_C3_Guide_v1.html` (built by `html/build_c3_v1.py` from `html/parts_c3_kit/` + `html/parts_c3/`) |

Offline baseline (no key): precision@5 semantic 0.20 → filter 0.80 → full score 0.93 (`docs/RESULTS.md`).

## Run
```bash
pip install -r requirements.txt
pytest -q
export GOOGLE_API_KEY=...            # Colab: Secrets → GOOGLE_API_KEY
python -m tenderyar.apps.gradio_app
python -m tenderyar.apps.flask_api   # TENDERYAR_OFFLINE=1 for the no-LLM baseline
python -m tenderyar.apps.gradio_rag   # v0.2 (TY_MODEL=offline TY_EMBED=offline = no key)
python scripts/eval_c2_offline.py    # v0.2 offline grid
python -m tenderyar.apps.gradio_library   # v0.3 (TY_EMBED=offline = no key)
python scripts/eval_c3_offline.py    # v0.3 offline numbers
```

## Data
`data/notices/` contains **synthetic** notices written in the style of public notices (invented names and numbers); `data/gold.jsonl` are the labels. `python data/make_synthetic.py --n 50` creates 50 more random synthetic notices with exact labels in `data/synth/` (used from Course 3). Add real *public* notices (newspapers, aggregators) — never private documents.

## Release tags
```bash
git add -A && git commit -m "v0.3 Tender library + matching" && git tag v0.3 && git push origin main --tags
git checkout v0.1   # go back to Course 1 state at any time
```

## Results
See `docs/RESULTS.md`.

## Roadmap
| Version | Course | Status |
|---|---|---|
| v0.1 tender card | C1 Develop GenAI Apps | ✅ |
| v0.2 ask the package (RAG + page citations) | C2 Build RAG Applications | ✅ code + tests · fill Gemini rows |
| v0.3 tender library + matching | C3 Vector Databases for RAG | ✅ code + tests · fill Gemini rows |
| v0.4 hybrid Persian retrieval + TenderQA | C4 | next |

Later: v0.3 Chroma tender library + company matching · v0.4 hybrid Persian retrieval + TenderQA · v0.5 scans/tables/voice · v0.6 tools agent · v0.7 LangGraph bid/no-bid · v0.8 reviewer crew · v0.9 MCP server · v1.0 security, HF dataset + Spaces demo.

---
### فارسی
مناقصه‌یار متن آگهی یا اسناد مناقصه را می‌خواند و «کارت مناقصه» می‌سازد: دستگاه مناقصه‌گزار، شماره، مهلت (شمسی و میلادی)، مبلغ تضمین به ریال، رتبهٔ لازم و استان. نسخه‌های بعدی به پرسش‌وپاسخ روی کل اسناد با ذکر شمارهٔ صفحه، تصمیم شرکت/عدم شرکت و سرور MCP می‌رسند.
