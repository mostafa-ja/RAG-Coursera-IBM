import { chromium } from 'playwright';
const b = await chromium.launch({executablePath:'/usr/local/bin/chromium'}); const p = await b.newPage({viewport:{width:1280,height:900}});
const errs=[]; p.on('pageerror',e=>errs.push('pageerror: '+e.message)); p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text())});
await p.goto('file:///data/work/versions/RAG_C1_Guide_v16_r4.html'); await p.waitForTimeout(800);
const t = p.locator('#cmp-pairs + p + div.tw'); await t.scrollIntoViewIfNeeded(); await t.screenshot({path:'/tmp/r4.png'});
console.log('sidebar link visible-able:', await p.locator('a.sub[href="#cmp-pairs"]').count());
console.log('errors:',errs.length? errs.join('\n'):'none'); await b.close(); process.exit(0);
