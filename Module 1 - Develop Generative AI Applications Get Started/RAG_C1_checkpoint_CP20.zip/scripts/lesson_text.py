# usage: python3 scripts/lesson_text.py IN.html LESSON_ID  -> prints plain text of one lesson (to check existing content before adding)
import sys,re,html
h=open(sys.argv[1],encoding='utf-8').read(); lid=sys.argv[2]
m=re.search(rf'<article class="lesson"[^>]*id="{lid}".*?</article>',h,re.S); a=m.group(0)
a=re.sub(r'<svg.*?</svg>','[SVG]',a,flags=re.S); a=re.sub(r'<(br|/p|/li|/h\d|/tr|/pre|/div)[^>]*>','\n',a)
t=html.unescape(re.sub(r'<[^>]+>','',a)); t=re.sub(r'\n\s*\n+','\n',t); print(t)
