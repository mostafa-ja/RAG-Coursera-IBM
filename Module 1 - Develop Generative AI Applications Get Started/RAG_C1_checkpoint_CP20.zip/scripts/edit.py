# helper: exact, unique replacements with assertions
def rep(h, old, new, count=1):
    n = h.count(old)
    assert n == count, f"expected {count} got {n}: {old[:80]!r}"
    return h.replace(old, new)
def load(p): return open(p, encoding='utf-8').read()
def save(p, h): open(p, 'w', encoding='utf-8').write(h)
