# R2: Learn <-> Apply bridges.  usage: python3 scripts/r2_apply.py IN.html OUT.html
import sys,re,html as H
sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
src,dst=sys.argv[1:3]; h=load(src)
assert 'class="apply"' not in h, 'R2 already applied'
L={'kit-skills':'K.1 · The 15 practical skills','kit-p1':'P1 · Starter cell + model factory','kit-p2':'P2 · Core loop (invoke · batch · stream)',
 'kit-p3':'P3 · Structured output + validation','kit-p4':'P4 · Retries &amp; fallbacks','kit-p5':'P5 · Multi-step pipelines',
 'kit-p6':'P6 · Chat memory per session','kit-p7':'P7 · Tool calling','kit-p8':'P8 · Mini RAG with sources','kit-p9':'P9 · Model test harness',
 'kit-p10':'P10 · Flask API + Gradio UI','kit-p11':'P11 · Debugging &amp; safety','proj-why':'TenderYar C.0 · What v0.1 does',
 'proj-setup':'TenderYar C.1 · Setup','proj-s1':'TenderYar C.2 · Clean-up + rules baseline','proj-s2':'TenderYar C.3 · Zero- vs few-shot prompts',
 'proj-s3':'TenderYar C.4 · CoT + self-consistency','proj-s4':'TenderYar C.5 · Pydantic + LCEL chain','proj-s5':'TenderYar C.6 · Choose the model',
 'proj-s6':'TenderYar C.7 · Flask + Gradio','cmp-prompt':'Compare: prompting techniques','cmp-params':'Compare: watsonx → Gemini parameters',
 'cmp-lc':'Compare: which building blocks?','cmp-legacy':'Compare: legacy → modern API','cmp-arch':'Compare: chain vs agent vs LangGraph',
 'cmp-parsers':'Compare: which parser?','cmp-formats':'Compare: chat formats','adv-map':'D.0 · Which retriever?'}
CORE={
'start-map':("Every project in this course uses the same chain of skills: prompt → chain → structured output → app. TenderYar applies all of them to real Persian tender notices.",['proj-why','kit-skills']),
'start-colab':("Start every new project notebook with these two cells; P1 turns them into one reusable model factory.",['kit-p1','proj-setup']),
'w1-ai':("Use an LLM only where rules or a classic classifier are not enough — and measure a no-LLM baseline first, so you can prove the LLM really helps.",['proj-s1']),
'w1-pe':("Write every project prompt with the 4 elements: your rules = instructions, domain notes = context, the user's text = input data, the required format = output indicator.",['kit-p2','proj-s2']),
'w1-icl':("When the model keeps making the same mistake, first add 1–3 worked examples to the prompt; think about fine-tuning only if that is not enough.",['proj-s2']),
'w1-adv':("Use chain-of-thought only for fields that need reasoning, and self-consistency (ask N times, then vote) when you need a confidence score.",['proj-s3','kit-p5','cmp-prompt']),
'w1-tools':("Keep prompts as named templates in one file (TenderYar: <code>prompts.py</code>), not as f-strings scattered across cells — easier to test, compare and reuse.",['kit-p2','proj-s2']),
'w1-lcel':("Every feature is a chain: <code>prompt | llm | parser</code>. The same chain gets <code>.batch()</code> for many inputs and <code>.with_fallbacks()</code> for a backup model.",['kit-p2','kit-p5','proj-s4']),
'w1-apps':("Each use case here is a ready project idea: one template per task, the same chain shape for all; P5 shows how to route an input to the right template.",['kit-p2','kit-p5']),
'w1-params':("Set parameters per task: temperature 0 (or close to it) for extraction and classification, higher (≈0.7–0.8) for creative text or self-consistency votes — and leave <code>max_output_tokens</code> headroom.",['kit-p1','proj-s3','cmp-params']),
'w2-what':("Before coding, list the bricks your app really needs; most first projects need only a model, a prompt template and a parser.",['cmp-lc','kit-skills']),
'w2-models':("Create the model in one place (a factory), so a model swap or a backup model is a one-line change; read the answer with <code>.text</code>.",['kit-p1','kit-p4']),
'w2-prompts':("Use <code>ChatPromptTemplate</code> for all project prompts; add examples with <code>FewShotChatMessagePromptTemplate</code> and chat history with <code>MessagesPlaceholder</code>.",['proj-s2','kit-p6']),
'w2-parsers':("Never use raw model text in code: parse it into a dict or a Pydantic object and validate it first.",['kit-p3','proj-s4','cmp-parsers']),
'w2-docs':("This is the retrieval half of RAG (load → split → embed → store → retrieve). P8 adds the answer step with sources — your bridge to Course 2.",['kit-p8','adv-map']),
'w2-memory':("Chatbot: keep one history per user (<code>session_id</code>) and inject it with <code>MessagesPlaceholder</code>. Multi-step pipeline: pass one dict along and add keys with <code>.assign()</code>.",['kit-p6','kit-p5','cmp-legacy']),
'w2-agents':("Give the model tools only when it must fetch or compute something it cannot know. Start with one tool and <code>bind_tools</code>, and log every tool call.",['kit-p7','cmp-arch']),
'w3-llm':("Tokens are your cost and latency: check <code>usage_metadata</code>, keep prompts lean, and clean the text before it reaches the model (TenderYar first normalises Persian letters and digits).",['proj-s1','kit-p11']),
'w3-choose':("Never choose a model by reputation: run the same inputs through 2–3 models and compare accuracy, latency and cost in one table.",['kit-p9','proj-s5','kit-p4']),
'w3-tokens':("With chat models through LangChain (Gemini here) the provider adds these special tokens for you — you just send messages. Formats matter only when you prompt a raw open model yourself.",['cmp-formats']),
'w3-json':("The project recipe: ask for JSON → parse → validate with Pydantic → let code fix what code does better (dates, money).",['kit-p3','proj-s4']),
'w3-flask':("Wrap your chain in one POST endpoint (JSON in → JSON out) and test it from Python before you build any UI.",['kit-p10','proj-s6']),
}
BACK={'kit-p1':['0.2','1.10','2.2'],'kit-p2':['1.8','2.3','2.4'],'kit-p3':['2.4','3.4'],'kit-p4':['2.2','3.2'],'kit-p5':['1.8','1.6','2.6'],
 'kit-p6':['2.6','2.3'],'kit-p7':['2.7'],'kit-p8':['2.5','1.8'],'kit-p9':['3.2','1.10'],'kit-p10':['3.5','3.4'],'kit-p11':['1.8','2.2','3.1'],'proj-s1':['1.1','3.1']}
# lesson number -> (id,title)
NUM={}
for m in re.finditer(r'<article class="lesson"[^>]*id="([^"]+)"[^>]*><div class="secnum">(.*?)</div><h2>(.*?)</h2>',h,re.S):
    n=re.search(r'(?:Lesson|Start ·) (\d+\.\d+)',re.sub('<[^>]+>','',m.group(2)))
    if n: NUM[n.group(1)]=(m.group(1),H.escape(H.unescape(re.sub('<[^>]+>','',m.group(3))),quote=True))
for k in list(L)+[i for v in BACK.values() for i in []]: assert f'id="{k}"' in h, k
def lk(num): i,t=NUM[num]; return f'<a href="#{i}" title="{t}">{num}</a>'
def art(lid):
    m=re.search(rf'<article class="lesson"[^>]*id="{lid}".*?</article>',h,re.S); assert m, lid; return m.group(0)
# (a) core lessons: box at the end of the lesson
for lid,(s,ts) in CORE.items():
    a=art(lid); box=('<div class="apply"><b class="t">🏗 Use it in a project</b><p>'+s+'</p><p class="go">→ '+
        ' · '.join(f'<a href="#{t}">{L[t]}</a>' for t in ts)+'</p></div>')
    h=rep(h,a,a[:-len('</article>')]+box+'</article>')
# (b1) toolkit + proj-s1: "learn first" pill
for lid,nums in BACK.items():
    a=art(lid); i=a.find('<div class="meta">'); j=a.find('</div>',i); assert i>0 and j>i
    h=rep(h,a,a[:j]+'<span class="lf">📖 learn first: '+', '.join(lk(n) for n in nums)+'</span>'+a[j:])
# (b2) project pills "🧩 lessons 2.3, P3" -> clickable
for lid in ['proj-setup','proj-s2','proj-s3','proj-s4','proj-s5','proj-s6','proj-guard']:
    a=art(lid); m=re.search(r'<span>(🧩[^<]*)</span>',a); assert m, lid
    t=re.sub(r'(?<![\d.])(\d\.\d+)(?![\d.])',lambda x: lk(x.group(1)),m.group(1))
    t=re.sub(r'\bP(\d+)\b',lambda x: f'<a href="#kit-p{x.group(1)}">P{x.group(1)}</a>',t)
    h=rep(h,a,a.replace(m.group(0),'<span class="lf">'+t+'</span>',1))
# (c) tiny CSS
css=('.apply{margin:18px 0 4px;padding:10px 14px;border:1px solid var(--bd);border-left:4px solid var(--ac);border-radius:10px;background:var(--acS);font-size:.94em}'
     '.apply .t{display:block;margin-bottom:2px}.apply p{margin:3px 0}.apply .go a{font-weight:600;text-decoration:none}.apply .go a:hover{text-decoration:underline}'
     '.meta span.lf a{color:var(--ac);font-weight:600;text-decoration:none}.meta span.lf a:hover{text-decoration:underline}')
k=h.rfind('</style>',0,h.find('</head>')); assert k>0; h=h[:k]+css+h[k:]
# (d) one sentence in "How to use this guide"
i=h.find('<b class="t">How to use this guide</b><p>'); assert i>0 and h.count('<b class="t">How to use this guide</b>')==1
j=h.find('</p>',i); h=h[:j]+' At the end of each key lesson, a blue <b>🏗 Use it in a project</b> box links the idea to the Toolkit pattern and the TenderYar step that apply it; in those parts, <b>📖 learn first</b> tags link back to the lessons.'+h[j:]
save(dst,h); print('ok', len(h), 'apply boxes:',h.count('class="apply"'),'learn-first pills:',h.count('class="lf"'))
