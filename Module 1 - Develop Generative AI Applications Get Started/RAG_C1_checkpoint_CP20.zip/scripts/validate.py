# usage: python3 scripts/validate.py FILE.html  -> links / duplicate ids / tag balance / counts
import re,sys
from collections import Counter
from html.parser import HTMLParser
h=open(sys.argv[1],encoding='utf-8').read()
ids=re.findall(r'\bid="([^"]+)"',h); dup=[k for k,v in Counter(ids).items() if v>1]
miss=sorted(set(x for x in re.findall(r'href="#([^"]*)"',h) if x and x not in set(ids)))
VOID={'br','img','input','meta','link','hr','col','source','wbr','area','base','embed','param','track'}
class P(HTMLParser):
    def __init__(s): super().__init__(); s.st=[]; s.bad=0
    def handle_starttag(s,t,a):
        if t not in VOID: s.st.append(t)
    def handle_startendtag(s,t,a): pass
    def handle_endtag(s,t):
        if s.st and s.st[-1]==t: s.st.pop()
        elif t in s.st:
            while s.st[-1]!=t: s.st.pop(); s.bad+=1
            s.st.pop()
        else: s.bad+=1
p=P(); p.feed(h)
print(f'{sys.argv[1]}: bytes={len(h.encode())} ids={len(ids)} dup_ids={dup} missing_links={miss} tag_mismatch={p.bad} unclosed={p.st[-5:]}')
print(' lessons=',h.count('<article class="lesson"'),'svg=',h.count('<svg'),'deep=',h.count('<details class="deep">'),'pre=',h.count('<pre'),'tables=',h.count('<table'),'apply=',h.count('🏗 Use it in a project'))
