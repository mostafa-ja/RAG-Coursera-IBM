#!/bin/bash
# usage: bash scripts/make_cp.sh CPNAME   -> /data/work/out/RAG_C1_checkpoint_CPNAME.zip
# Zips everything needed to resume (CHECKPOINT.md, scripts, blocks, notes, LATEST version only).
set -e; cd /data/work; mkdir -p out
LATEST=$(ls -t versions/*.html | head -1)
rm -f out/RAG_C1_checkpoint_$1.zip
zip -q -r out/RAG_C1_checkpoint_$1.zip CHECKPOINT.md scripts blocks notes "$LATEST" -x '*__pycache__*'
echo "saved out/RAG_C1_checkpoint_$1.zip  (latest version: $LATEST)"; ls -la out/RAG_C1_checkpoint_$1.zip
