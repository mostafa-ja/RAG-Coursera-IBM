# usage: python3 add_deep.py IN.html OUT.html LESSON_ID BLOCK_FILE
# inserts BLOCK_FILE content right before "Key takeaways" of the lesson (unique anchor asserted)
import sys,re; sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
src,dst,lid,bf = sys.argv[1:5]
h=load(src); blk=load(bf).strip()+'\n'
m=re.search(rf'<article class="lesson"[^>]*id="{lid}".*?</article>',h,re.S); art=m.group(0)
anc='<div class="take"><h4>Key takeaways</h4>'; assert art.count(anc)==1, 'anchor'
assert blk.split('</summary>')[0] not in art, 'already inserted'
h=rep(h,art,art.replace(anc,blk+anc)); save(dst,h); print('ok',lid,len(h))
