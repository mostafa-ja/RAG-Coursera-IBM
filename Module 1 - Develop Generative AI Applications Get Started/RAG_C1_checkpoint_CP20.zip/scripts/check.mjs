// usage: node check.mjs file.html out_prefix selector1 [selector2...]
import { chromium } from 'playwright';
const [file, out, ...sels] = process.argv.slice(2);
const b = await chromium.launch({executablePath:'/usr/local/bin/chromium'}); const p = await b.newPage({viewport:{width:1280,height:900}});
const errs=[]; p.on('pageerror',e=>errs.push('pageerror: '+e.message)); p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text())});
await p.goto('file://'+file); await p.waitForTimeout(800);
let i=0; for (const s of sels){ const el=await p.$(s); if(!el){console.log('MISSING',s);continue;}
  await el.scrollIntoViewIfNeeded(); await el.screenshot({path:`${out}_${i++}.png`}); }
console.log('errors:',errs.length? errs.join('\n'):'none'); await b.close(); process.exit(0);
