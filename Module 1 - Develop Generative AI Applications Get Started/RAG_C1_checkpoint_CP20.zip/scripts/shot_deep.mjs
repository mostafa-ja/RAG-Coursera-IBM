// usage: node shot_deep.mjs file.html LESSON_ID out.png  -> opens the lesson's last deep block, screenshots it, prints JS errors
import { chromium } from 'playwright';
const [file, lid, out] = process.argv.slice(2);
const b = await chromium.launch({executablePath:'/usr/local/bin/chromium'}); const p = await b.newPage({viewport:{width:1280,height:900}});
const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await p.goto('file://'+file); await p.waitForTimeout(800);
const d = p.locator(`#${lid} details.deep`).last(); await d.evaluate(e=>e.open=true); await d.scrollIntoViewIfNeeded();
await d.screenshot({path:out}); console.log('errors:', errs.length?errs.join('\n'):'none'); await b.close(); process.exit(0);
