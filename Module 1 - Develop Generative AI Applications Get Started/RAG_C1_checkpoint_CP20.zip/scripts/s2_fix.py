# fix: tier-tag colours were overridden by a later generic .tag rule → scoped higher-specificity rules
import sys; sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
p='/data/work/versions/RAG_C1_Guide_v15_s2.html'; h=load(p)
css=''.join(f'{s} .tag.t-{c}{{background:var(--{v}S);color:var(--{v})}}' for s in ('.gh','.box','.secnum') for c,v in (('green','ok'),('orange','warn'),('purple','ac2')))
h=rep(h,'.secnum .tag{margin-left:8px;font-size:10.5px;vertical-align:1px}</style>','.secnum .tag{margin-left:8px;font-size:10.5px;vertical-align:1px}'+css+'</style>')
save(p,h); print('ok')
