import { chromium } from 'playwright';
const b = await chromium.launch({executablePath:'/usr/local/bin/chromium'}); const p = await b.newPage({viewport:{width:1280,height:900}});
const errs=[]; p.on('pageerror',e=>errs.push('pageerror: '+e.message)); p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text())});
await p.goto('file:///data/work/versions/RAG_C1_Guide_v16_r3.html'); await p.waitForTimeout(800);
const d = p.locator('#w1-lcel details.deep').nth(1); await d.evaluate(e=>e.open=true);
await d.scrollIntoViewIfNeeded(); await d.screenshot({path:'/tmp/r3.png'});
console.log('errors:',errs.length? errs.join('\n'):'none'); await b.close(); process.exit(0);
