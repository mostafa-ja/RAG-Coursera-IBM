# R4: insert blocks/r4_cmp-pairs.html into #cmp + sidebar link + start-map pointer.  v16_r3 -> v16_r4 (asserts; do NOT rerun on r4)
import re,sys; sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
h=load('versions/RAG_C1_Guide_v16_r3.html'); blk=load('blocks/r4_cmp-pairs.html').strip()
assert 'id="cmp-pairs"' not in h
anc1='<h3 id="cmp-prompt">Prompting techniques at a glance</h3>'
h=rep(h,anc1,blk+'\n'+anc1)
anc2='<a class="sub" href="#cmp-prompt">Prompting techniques at a glance</a>'
h=rep(h,anc2,'<a class="sub" href="#cmp-pairs">⚖ Don\'t mix these up (12 pairs)</a>'+anc2)
art=re.search(r'<article class="lesson"[^>]*id="start-map".*?</article>',h,re.S).group(0)
anc3='<a href="#w3-flask">3.5</a></td></tr></table></div>\n<div class="take"><h4>Key takeaways</h4>'
assert art.count(anc3)==1
ptr='<p><b>Two ideas look alike?</b> The table <a href="#cmp-pairs">⚖ Don\'t mix these up</a> puts 12 often-confused pairs side by side (LLM vs chat model, few-shot vs fine-tuning, memory vs RAG …), each with a rule for your project.</p>\n'
h=rep(h,art,art.replace(anc3,anc3.replace('\n<div class="take">','\n'+ptr+'<div class="take">')))
save('versions/RAG_C1_Guide_v16_r4.html',h)
ids=set(re.findall(r'id="([^"]+)"',h)); bad=[x for x in re.findall(r'href="#([^"]+)"',blk+ptr) if x not in ids]
print('ok; unresolved links in new parts:',bad,'| total links to #cmp-pairs:',h.count('href="#cmp-pairs"'))
