# fix2: sidebar tier tag on its own line above group title (in place on v15_s2)
import sys; sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
p='/data/work/versions/RAG_C1_Guide_v15_s2.html'; h=load(p)
h=rep(h,'.gh .tag{font-size:9.5px;padding:1px 6px;margin-right:6px;vertical-align:1px;letter-spacing:.03em}',
        '#side a.gh{display:block}.gh .tag{display:table;font-size:9.5px;padding:1px 6px;margin:0 0 3px;letter-spacing:.03em}')
save(p,h); print('ok')
