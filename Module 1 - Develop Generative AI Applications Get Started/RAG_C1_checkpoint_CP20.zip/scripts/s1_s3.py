# S1: hero stats + guide map + sidebar tier tags ; S3: key-lesson badges
import sys; sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
h = load('/data/work/versions/RAG_C1_Guide_v14.html')
# --- hero stats (real counts)
h = rep(h, '<span class="tag">Lessons</span><b>28</b><p>3 weeks + Part D (advanced RAG)</p>',
           '<span class="tag">Core lessons</span><b>24</b><p>Start + Weeks 1–3 · plus 30 optional (toolkit, project, Part D)</p>')
h = rep(h, '<span class="tag t-orange">Diagrams</span><b>20</b>', '<span class="tag t-orange">Diagrams</span><b>51</b>')
h = rep(h, '<p>86 glossary terms</p>', '<p>87 glossary terms</p>')
# --- guide map (before study plan)
MAP = ('<div class="box tip"><b class="t">🗺 Guide map: what to read, and when</b>'
 '<div class="tw"><table><tr><th>Tier</th><th>Parts</th><th>Read it when…</th></tr>'
 '<tr><td><span class="tag t-green">CORE</span></td><td><a href="#start">Start</a> + <a href="#w1">Week 1</a>, <a href="#w2">Week 2</a>, <a href="#w3">Week 3</a> (24 lessons)</td>'
 '<td>First, in order. These ideas are what the quizzes test and what every project uses. The 12 lessons tagged <span class="tag t-green">⭐ Key for projects</span> are the ones to understand deeply.</td></tr>'
 '<tr><td><span class="tag t-orange">APPLY</span></td><td><a href="#kit">Appendix B · Builder\'s toolkit</a> + <a href="#proj">Appendix C · TenderYar project</a></td>'
 '<td>After Week 3, when you start your own app. Copy a cell, run it, then adapt it.</td></tr>'
 '<tr><td><span class="tag t-purple">BONUS</span></td><td><a href="#adv">Part D · Advanced RAG</a></td>'
 '<td>Optional for Course 1. A preview of the retriever and vector-database work in the RAG courses.</td></tr>'
 '<tr><td><span class="tag">REFERENCE</span></td><td><a href="#cmp">Appendix A tables</a> · <a href="#gloss">Glossary</a> · <a href="#cheat">Cheat sheet</a> · <a href="#fcards">Flashcards</a> · <a href="#exam">Exam</a> · <a href="#ex">Exercises</a></td>'
 '<td>Any time: to look something up, or to revise before a quiz.</td></tr></table></div></div>\n')
h = rep(h, '<p class="planh">', MAP + '<p class="planh">')
# --- sidebar tier tags
T = {'start':('t-green','CORE'),'w1':('t-green','CORE'),'w2':('t-green','CORE'),'w3':('t-green','CORE'),
     'cmp':('','REF'),'kit':('t-orange','APPLY'),'proj':('t-orange','APPLY'),'adv':('t-purple','BONUS')}
for k,(c,l) in T.items():
    h = rep(h, f'<a class="gh" href="#{k}">', f'<a class="gh" href="#{k}"><span class="tag {c}">{l}</span>')
h = rep(h, '</head>', '<style>.gh .tag{font-size:9.5px;padding:1px 6px;margin-right:6px;vertical-align:1px;letter-spacing:.03em}.secnum .tag{margin-left:8px;font-size:10.5px;vertical-align:1px}</style></head>')
# --- S3 key-lesson badges
import re
KEY = ['w1-pe','w1-adv','w1-lcel','w1-params','w2-models','w2-prompts','w2-parsers','w2-docs','w2-memory','w2-agents','w3-json','w3-flask']
for k in KEY:
    m = re.search(rf'<article class="lesson"[^>]*id="{k}"[^>]*><div class="secnum">([^<]*)</div>', h)
    assert m, k
    old = m.group(0); new = old.replace('</div>', ' <span class="tag t-green">⭐ Key for projects</span></div>', 1)
    h = rep(h, old, new)
save('/data/work/versions/RAG_C1_Guide_v15_s1.html', h)
print('ok', len(h))
