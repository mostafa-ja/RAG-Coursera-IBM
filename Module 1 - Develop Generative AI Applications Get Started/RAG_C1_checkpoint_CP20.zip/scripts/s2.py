# S2: core-ideas table inside lesson 0.1 (#start-map)
import sys,re; sys.path.insert(0,'/data/work/scripts')
from edit import rep, load, save
h = load('/data/work/versions/RAG_C1_Guide_v15_s1.html')
L = lambda i,t: f'<a href="#{i}">{t}</a>'
rows = [
 ('Prompt = 4 elements', 'A prompt is a mini-spec: <b>instructions</b> (what to do), <b>context</b> (background), <b>input data</b> (the text to process) and an <b>output indicator</b> (where and how to answer).', 'Every LLM call. A missing element is the most common cause of vague answers.', L('w1-pe','1.4')),
 ('In-context learning', 'The model learns the task from examples <i>inside the prompt</i> (zero-, one-, few-shot). No training, and nothing is saved after the call.', 'Start zero-shot; add 2–5 examples when the labels or format drift.', L('w1-icl','1.5')+', '+L('w1-adv','1.6')),
 ('Chain-of-thought &amp; self-consistency', 'CoT: ask for the steps before the answer. Self-consistency: ask several times and keep the majority answer.', 'Multi-step maths or logic, or a field where one wrong answer is costly.', L('w1-adv','1.6')),
 ('Generation parameters', 'Knobs for how the next token is picked: <code>temperature</code>, <code>top_p</code>, <code>top_k</code> = how random; <code>max_tokens</code> = length cap.', 'Low temperature (0–0.3) for extraction and JSON; higher (0.7–1) for creative text.', L('w1-params','1.10')),
 ('Chat model + messages', 'The model reads a list of role-tagged messages: <b>System</b> (rules), <b>Human</b> (user), <b>AI</b> (earlier answers).', 'Put fixed rules in the System message; send the history as messages.', L('w2-models','2.2')),
 ('Prompt templates', 'A reusable prompt with <code>{placeholders}</code> that are filled at run time.', 'One template per task; never glue prompts together with string concatenation.', L('w1-tools','1.7')+', '+L('w2-prompts','2.3')),
 ('LCEL &amp; Runnables', '<code>prompt | llm | parser</code>: each step\'s output is the next step\'s input. Every step has <code>invoke</code>, <code>batch</code> and <code>stream</code>.', 'The backbone of every app in this course and in the RAG courses.', L('w1-lcel','1.8')),
 ('Output parsers', 'Turn the model\'s text into Python data: <code>str</code>, list, dict or a Pydantic object.', 'Whenever code, not a person, reads the answer (APIs, databases, UIs).', L('w2-parsers','2.4')+', '+L('w3-json','3.4')),
 ('Documents → chunks → embeddings → retriever', 'Split long text into chunks, turn each chunk into a vector, then fetch the chunks most similar to the question.', 'The “R” in RAG: answering from your own files.', L('w2-docs','2.5')),
 ('Memory', 'The model forgets everything between calls. “Memory” means <i>you</i> send the earlier messages again.', 'Chatbots and multi-turn assistants. Cap the history to save tokens.', L('w2-memory','2.6')),
 ('Agents &amp; tools', 'The LLM chooses which tool (a Python function) to call and with what input, reads the result, then decides the next step.', 'When the steps are not fixed in advance (search, calculate, query a database).', L('w2-agents','2.7')),
 ('Model choice + serving', 'Pick the smallest model that passes your own test questions, then wrap the chain in a Flask route that returns JSON.', 'Shipping: cost, speed, and a URL that other apps can call.', L('w3-choose','3.2')+', '+L('w3-flask','3.5')),
]
tr = ''.join(f'<tr><td><b>{i+1}. {a}</b></td><td>{b}</td><td>{c}</td><td>{d}</td></tr>' for i,(a,b,c,d) in enumerate(rows))
BLOCK = ('<h3>⭐ The 12 core ideas of Course 1, in plain words</h3>'
 '<p>Almost every app in this course follows one pattern: <b>template → chat model → parser</b>, then <b>serve it</b>. '
 'Ideas 1–8 make that pattern work well, ideas 9–11 extend it (your own data, conversation, tools), and idea 12 ships it. '
 'If you can explain each row in your own words, you are ready for the quizzes and for your first project.</p>'
 '<div class="tw"><table><tr><th>Idea</th><th>What it really is</th><th>Use it in a project when…</th><th>Lesson</th></tr>'+tr+'</table></div>\n')
m = re.search(r'<article class="lesson"[^>]*id="start-map".*?</article>', h, re.S); art = m.group(0)
anchor = '<div class="take"><h4>Key takeaways</h4>'
assert art.count(anchor)==1
new = art.replace(anchor, BLOCK+anchor).replace('<span>⏱ ~2 min</span>','<span>⏱ ~6 min</span>',1)
h = rep(h, art, new)
save('/data/work/versions/RAG_C1_Guide_v15_s2.html', h); print('ok',len(h))
