# Round 2 plan (decided at R1, 2026-10-15)
## Findings (R1 analysis of v16_s0 = round-1 output)
- 54 lessons; every core lesson already has the rich template (nutshell, objectives, plain words, SVG, code,
  deep look, try-it, quiz, takeaways, recall). Week intros ("Week at a glance") exist. Model names/API (.text)
  are consistent. => Do NOT add more general text; fix the real gaps below.
- GAP 1 (structure): the 24 core lessons have ZERO links to the Toolkit (kit-p1..p11), the TenderYar project
  (proj-*) or the comparison tables (cmp-*). Toolkit/Project lessons have ZERO clickable links back to lessons
  (proj meta pills say "🧩 lessons 2.3, 2.4" as plain text). Learn and Apply parts are disconnected.
- GAP 2 (depth): the most-used RAG idiom {"context": retriever, "question": RunnablePassthrough()} | prompt ...
  (dict step = RunnableParallel, RunnablePassthrough, .assign) is only shown in code (w1-lcel, w2-docs,
  w2-memory, kit-p5, kit-p8), never explained step by step. It is the core pattern of Course 2.
- GAP 3 (clarity): no single place that separates look-alike concepts (LLM vs chat model, PromptTemplate vs
  ChatPromptTemplate, few-shot vs fine-tuning, CoT vs self-consistency, temperature vs top_p, max tokens vs
  context window, parser vs with_structured_output, embedding model vs chat model, vector store vs retriever,
  chain vs agent, invoke/batch/stream). cmp section covers only some.
## Steps (one checkpoint each)
- R2  scripts/r2_apply.py : (a) "🏗 Use it in a project" box at the end of 22 core lessons (sentence + links to
      kit/proj/cmp); (b) "📖 learn first" linked pill in kit-p1..p11 + proj-s1; proj 🧩 pills made clickable;
      (c) tiny CSS .apply; (d) one sentence in "How to use this guide". Output v16_r2.html
- R3  blocks/r3_w1-lcel-dict.html : 2nd deep block in w1-lcel "The dict step: RunnablePassthrough, .assign and the
      RAG pattern" (fake retriever via RunnableLambda so it runs in week 1; trace table; .assign). Output v16_r3.html
- R4  "Don't mix these up" table (≈12 look-alike pairs: difference · project rule · lesson link) as first
      sub-section of #cmp (id cmp-pairs) + link from start-map. Output v16_r4.html
- R5  final validation (links/ids/tags/JS errors/screenshots), hero stats if affected -> RAG_C1_Guide_v16.html
## Not doing (decided): more deep blocks for conceptual lessons (w1-ai/nlp/guide), restyling, collapsing quizzes.
