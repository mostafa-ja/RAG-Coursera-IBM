# CHECKPOINT — RAG Course 1 HTML Guide Improvement
_Resume file. Read this first. ROUND 2 is COMPLETE (top). Round 1 history is kept at the bottom._

## ROUND 2 (started 2026-10-15) — COMPLETE (output: versions/RAG_C1_Guide_v16.html)
### Task (user, round 2)
Improve RAG_C1_Guide HTML again: better structure, deeper + clearer explanations of the important,
practical concepts of Course 1 so the learner understands deeply and can apply them in projects.
NO over-engineering, no confusing/complicated additions. Learner uses Google Colab (Gemini), not IBM lab.
Free account / token limits: work in very small steps, checkpoint (zip for download) BEFORE modifying
and AFTER every meaningful change. Every checkpoint must be usable on its own.

### Key facts found at start of round 2
- The attached "RAG_C1_Guide_v14.html" is BYTE-IDENTICAL (md5 7f7539a9...) to round-1 output v15.
  => Round 2 input = versions/RAG_C1_Guide_v16_s0.html (copy of v15). Round 2 output name = RAG_C1_Guide_v16.html
- New input this round: C1_TenderYar_v0_1.ipynb (project notebook, 32 cells: setup, Persian clean-up,
  rules baseline, zero/few-shot, CoT bond + self-consistency deadline, Pydantic+LCEL+fallback, model
  comparison, Flask POST /extract, Gradio RTL, Guard-the-Secret). Notebook inconsistency: cell 3 says
  "12 passed" but "Done when" says "pytest passes (5 tests)".
- Other inputs same as round 1 (3 Colab notebooks M1/M2/M3, slides PDF, lab-instruction.md). Originals are NOT
  in the zip (re-upload only if needed; work does not depend on them).

### Workspace layout (/data/work)
CHECKPOINT.md · scripts/ (helpers) · blocks/ (HTML snippets inserted) · notes/ · versions/ (latest html) · out/ (zips)
Helpers: scripts/lesson_text.py (lesson -> plain text), scripts/add_deep.py (insert block before Key takeaways),
scripts/edit.py (rep/load/save with unique-anchor assert), scripts/check.mjs + shot_deep.mjs (Chromium JS-error check +
screenshot; chromium at /usr/local/bin/chromium), scripts/make_cp.sh CPNAME (zip latest version + all notes).

### Round 2 status
- [x] R0: workspace restored from CP11 zip, inputs copied, v16_s0 created (no content change) -> CP12
- [x] R1: analysis done -> notes/round2_plan.md (READ IT: findings GAP1-3 + steps R2-R5)
- [x] R2: Learn<->Apply links DONE -> versions/RAG_C1_Guide_v16_r2.html (scripts/r2_apply.py; do NOT rerun on r2, it asserts)
- [x] R3: deep block w1-lcel 'dict step / RunnablePassthrough / RAG pattern' (blocks/r3_w1-lcel-dict.html -> add_deep.py) -> v16_r3
- [x] R4: 'Don't mix these up' table #cmp-pairs + link from start-map -> v16_r4
- [x] R5: final validation -> versions/RAG_C1_Guide_v16.html

### Round 2 log
- CP12: round 2 started. No HTML change yet. NEXT: R1 analysis -> notes/round2_plan.md.
- CP13: R1 analysis done (notes/round2_plan.md). R2 script written (scripts/r2_apply.py: 22 '🏗 Use it in a project' boxes at end of core lessons, '📖 learn first' pills in kit-p1..p11 + proj-s1, clickable 🧩 pills in proj-*, tiny CSS, 1 sentence in 'How to use this guide'). NOT yet run. NEXT: run it (command in Status), check output + screenshot, then CP14.
- CP14: R2 DONE. v16_r2.html: 22 apply boxes, 19 learn-first/linked pills, CSS added before last </style> in <head> (there is also a </style> inside <body> — never use rfind on whole file). Links resolve (only 4 JS template strings 'unresolved', same as round 1), no JS errors, screenshot OK. NEXT: R3 = write blocks/r3_w1-lcel-dict.html then: python3 scripts/add_deep.py versions/RAG_C1_Guide_v16_r2.html versions/RAG_C1_Guide_v16_r3.html w1-lcel blocks/r3_w1-lcel-dict.html
- CP15: NEW SESSION resumed from CP14 zip (attached v14 md5 7f7539a9 = round-1 v15, so round 2 continues). Workspace restored to /data/work, inputs copied to orig/. No HTML change. NEXT: R3 (see CP14 line).
- CP16: R3 block WRITTEN (blocks/r3_w1-lcel-dict.html: problem, 3-row dict/Passthrough/.assign table, runnable fake-retriever RAG code with tender notes, trace table, .assign with sources code, 3 mistakes, links #w2-docs #kit-p8). NOT inserted yet. Placement decision: insert right AFTER the existing deep block of w1-lcel (anchor "</details><div class=\"box try\">" inside the w1-lcel article), not before Key takeaways, so both deep looks sit together. NEXT: insert -> versions/RAG_C1_Guide_v16_r3.html, validate, CP17.
- CP17: R3 DONE -> versions/RAG_C1_Guide_v16_r3.html (inserted after 1st deep block of #w1-lcel; deep blocks 17->18; block tags balanced; no JS errors; screenshot OK via scripts/shot_r3.mjs). NEXT: R4 = write blocks/r4_cmp-pairs.html ("Don't mix these up" ~12 look-alike pairs: difference / project rule / lesson link) as first sub-section of #cmp with id cmp-pairs + 1 link line in #start-map; check existing #cmp sub-section markup first so it matches; input v16_r3 -> output v16_r4.
- CP18: R4 block WRITTEN (blocks/r4_cmp-pairs.html: h3#cmp-pairs + intro + 12-row table: LLM/chat model, PromptTemplate/ChatPromptTemplate(+system vs human rule), few-shot/fine-tuning, CoT/self-consistency, temperature/top_p, max_output_tokens/context window, parser/with_structured_output, chat/embedding model, vector store/retriever, memory/RAG, chain/agent, invoke/batch/stream). NOT inserted yet. Insert plan (3 anchors, input v16_r3 -> output v16_r4): (1) block right after the #cmp <h1>...</h1> (before <h3 id="cmp-prompt">); (2) sidebar: before '<a class="sub" href="#cmp-prompt">Prompting techniques at a glance</a>' add <a class="sub" href="#cmp-pairs">⚖ Don't mix these up (12 pairs)</a>; (3) #start-map: after the core-ideas table (ends '<a href="#w3-flask">3.5</a></td></tr></table></div>\n' before Key takeaways) add 1 <p> linking #cmp-pairs. NEXT: run the insert, validate, CP19.
- CP19: R4 DONE -> versions/RAG_C1_Guide_v16_r4.html via scripts/r4_apply.py (do NOT rerun on r4, it asserts). Inserted: h3#cmp-pairs table as 1st sub-section of #cmp, sidebar link (a.sub before cmp-prompt), 1 <p> pointer in #start-map after the core-ideas table. Fix applied in place (block + r4): first <th style="min-width:12em"> so code names do not break mid-word. Checks: new links resolve, no JS errors, screenshots OK (scripts/shot_r4.mjs). NEXT: R5 final validation on v16_r4: all internal #links resolve (4 JS template strings are known false positives), no duplicate ids, tag balance, JS errors, hero/start screenshot; update "How to use this guide"/hero stats only if needed; copy to versions/RAG_C1_Guide_v16.html + out/; tick R5; CP20 FINAL.
- CP20: R5 FINAL. scripts/validate.py on v16_r4: 211 ids, 0 duplicate ids, only the 4 known JS-template "missing" links, 0 tag mismatches; 54 lessons / 52 SVG unchanged; deep 17->18, pre 74->76, tables 75->78; no JS errors. Hero stats not affected (no new lessons/diagrams/quiz/flashcards). Delivered versions/RAG_C1_Guide_v16.html (= v16_r4, also out/). ROUND 2 COMPLETE. Nothing pending. If the user wants more later, ask first (decided NOT to do: more deep blocks for conceptual lessons, restyling, collapsing quizzes).

---------------------------------------------------------------------------------------------------
## ROUND 1 (complete) — original notes below

## Task (from user)
Improve the self-contained HTML revision guide: better structure, clearer explanations of
important/practical concepts, easy to read, deep understanding for applying in projects.
NO over-engineering / no complicated additions. Learner uses Google Colab (not IBM lab).
Work in small steps; checkpoint before/after each meaningful change.

## Inputs (copied to /data/work/orig/)
- RAG_C1_Guide_v14.html  (the guide to improve; user text said "C3_Guide_v1" but attached file is C1 v14 → working on attached C1 file)
- C01-M1-L1_Prompt_Engineering_PromptTemplates_Colab.ipynb
- C01-M2-L1_Build_Smarter_AI_Apps_LangChain_Colab.ipynb
- C01-M3-L1_Choosing_the_Right_Model_Flask_Colab.ipynb
- Develop Generative AI Applications Get Started.pdf (slides: GenAI basics, prompt eng, ICL, zero/one/few-shot, CoT, self-consistency, LangChain, LCEL, Runnables, chat models/messages, prompt templates, example selectors, output parsers, chains, memory, agents)
- lab-instruction.md

## Files
- Working copy: /data/work/versions/  (vNN = output versions)
- Output target: RAG_C1_Guide_v15.html

## Status
- [x] Step 0: checkpoint created, inputs copied
- [x] Step 1: analyzed HTML (see notes/structure_v14.txt, notes/lessons/*.txt = plain text per lesson)
- [x] Step 2: notebooks/lab headings reviewed (M1 prompting+LCEL, M2 LangChain components, M3 model choice+JSON+Flask; lab md = LLM primer, model choice, special tokens, JSON parser, Flask)
- [x] Step 3: plan written (below)
- [x] S1 structure: hero "guide map" (Core/Apply/Bonus/Reference tiers) + tier tags in sidebar group labels + fix hero stats
- [x] S2 core-ideas table added inside lesson 0.1 (#start-map): idea → plain explanation → project use → link
- [x] S3 "⭐ Core" badge in .secnum of key lessons
- [x] D1 deep block w1-pe   (4 elements → real template, before/after)
- [x] D2 deep block w1-params (how temp/top_k/top_p pick next token, numeric example, settings per task)
- [x] D3 deep block w2-parsers (format instructions → text → parse; why parsing fails + fixes)
- [x] D4 deep block w3-llm (token→embedding→attention→probabilities loop)
- [x] D5 deep block w3-flask (request lifecycle browser→route→chain→JSON)
- [x] D6 deep block w2-what (app problem → LangChain component)
- [x] Final: validate (HTML parse + headless Chromium JS console errors + screenshot), deliver v15

## Key findings (v14)
- 622 KB, 2881 lines, 54 <article class="lesson"> (24 core: start-*, w1-*, w2-*, w3-*), 52 SVGs, no base64 images.
- Sections: hero#top, #start, #w1, #w2, #w3, #cmp (App A tables), #kit (App B toolkit P1-P11), #proj (App C TenderYar), #adv (Part D advanced RAG), #cover, #exam, #gloss, #fcards, #cheat, #ex.
- Lesson template already rich: secnum, meta, obj(objl/objr), tldr/nut ("In a nutshell"), plain words, svgw diagram, pre code, box try/err/pit/why/rem, onq quiz, take (Key takeaways), recall.
- 11 lessons already have <details class="deep"><summary>🔍 Deeper look · …</summary><div class="dbody">…</div></details>
- Core lessons WITHOUT deep: start-map,start-colab,w1-ai,w1-nlp,w1-guide,w1-pe,w1-tools,w1-apps,w1-params,w2-what,w2-parsers,w3-llm,w3-flask
- Hero stats look stale ("Lessons 28", "Diagrams 20").
- Model names used in notebooks: gemini-3.8-flash (main), gemini-3.5-flash-lite, gemini-2.5-flash, gemini-embedding-2 → keep consistent.

## Decisions
- Do NOT rewrite/bloat. Keep existing content; add short, clear, project-oriented explanations only where core concepts lack depth.
- Reuse existing CSS classes (details.deep, .tw table, .box) → no new CSS unless tiny.
- Edit via small python scripts (str.replace on unique anchors, assert count==1) → save as new version file each step.

## How to resume (new account)
1. Upload the latest RAG_C1_checkpoint_CPn.zip (+ original inputs if you want; not strictly needed).
2. Unzip into /data/work (so /data/work/CHECKPOINT.md exists). Originals optional at /data/work/orig/.
3. Read Status + last Log line → do the NEXT step. Save new version as versions/RAG_C1_Guide_v15_<step>.html.
4. After each step: tick Status, add Log line, run `bash scripts/make_cp.sh CPn` and download the zip.
- Helper: `python3 scripts/lesson_text.py versions/<latest>.html <lesson-id>` prints a lesson as plain text
  (replaces notes/lessons/*.txt, which were not in the CP7 zip).

## Log
- CP0: started. No prior work existed.
- CP2: S1+S3 done via scripts/s1_s3.py (input versions/RAG_C1_Guide_v14.html → output versions/RAG_C1_Guide_v15_s1.html). Hero stats fixed, guide-map box before study plan, sidebar tier tags (CORE/REF/APPLY/BONUS), ⭐ "Key for projects" badge on 12 lessons: w1-pe,w1-adv,w1-lcel,w1-params,w2-models,w2-prompts,w2-parsers,w2-docs,w2-memory,w2-agents,w3-json,w3-flask. NEXT: S2 core-ideas table in #start-map (input v15_s1 → output v15_s2).
- CP3: S2 done via scripts/s2.py (v15_s1 → versions/RAG_C1_Guide_v15_s2.html): h3 "⭐ The 12 core ideas…" + 4-col table inserted before Key takeaways of #start-map; meta time 2→6 min. NEXT: quick screenshot check of hero/start, then D1 (w1-pe deep block), input v15_s2 → output v15_d1.
- CP3b: scripts/s2_fix.py applied in place to v15_s2 (scoped tag colour CSS). 
- CP3c: scripts/s2_fix2.py applied in place to v15_s2 (sidebar tag above title). NEXT: D1 w1-pe deep block (v15_s2 → v15_d1).
- CP4: D1 done: blocks/d1_w1-pe.html inserted via `python3 scripts/add_deep.py versions/RAG_C1_Guide_v15_s2.html versions/RAG_C1_Guide_v15_d1.html w1-pe blocks/d1_w1-pe.html`. Pattern for every D step: write blocks/dN_<id>.html → run add_deep.py (prev version → new version) → tick box. NEXT: D2 w1-params (input v15_d1 → output v15_d2); read notes/lessons/w1-params.txt first to avoid duplication.
- CP5: D2 done (blocks/d2_w1-params.html → versions/RAG_C1_Guide_v15_d2.html): temperature softmax worked example (logits 2/1/0 at T 0.5/1/2) + task presets table + max_output_tokens note. NEXT: D3 w2-parsers (v15_d2 → v15_d3); read notes/lessons/w2-parsers.txt first.
- CP6: D3 done (blocks/d3_w2-parsers.html → versions/RAG_C1_Guide_v15_d3.html): parser 2 jobs steps, parser choice table, failure→fix table, with_structured_output+try/except code. NEXT: D4 w3-llm (v15_d3 → v15_d4); read notes/lessons/w3-llm.txt first.
- CP7: D4 done (blocks/d4_w3-llm.html → versions/RAG_C1_Guide_v15_d4.html): 6 facts of next-token prediction → app consequence → action; usage_metadata + stream code (notebooks use msg.text). NEXT: D5 w3-flask (v15_d4 → v15_d5); read notes/lessons/w3-flask.txt first.
- CP8: NEW SESSION resumed from CP7 zip. Workspace restored to /data/work. Added scripts/make_cp.sh (packages checkpoint) + scripts/lesson_text.py. No HTML change. NEXT: D5 w3-flask (v15_d4 → v15_d5).
- CP9: D5 done (blocks/d5_w3-flask.html → versions/RAG_C1_Guide_v15_d5.html): 7-step request table (code + failure symptom), status code → layer, 3 layers/one contract (AIResponse keys), test inside-out code (model fn → Flask test_client → browser). Verified: no JS errors (scripts/shot_deep.mjs). NEXT: D6 w2-what (v15_d5 → v15_d6); run lesson_text.py on w2-what first.
- CP10: D6 done (blocks/d6_w2-what.html → versions/RAG_C1_Guide_v15_d6.html): problem → brick → lesson-link table (2.2–2.7, 1.8, 3.4), minimal prompt|llm|StrOutputParser code (model swap = 1 line), rule of thumb. No JS errors. NEXT: Final validation (all internal #links resolve, HTML well-formed, JS errors, hero/start screenshot) then rename to RAG_C1_Guide_v15.html and deliver.
- CP11: FINAL. Validation passed: 588 internal links resolve (4 'missing' are JS template strings), no duplicate ids, 0 tag mismatches, no JS errors; 54 lessons/52 SVG unchanged, deep blocks 11→17, code blocks 68→74. Added 1 sentence in 'How to use this guide' about 🔍 Deeper look boxes. Delivered versions/RAG_C1_Guide_v15.html (also out/). TASK COMPLETE. Optional future ideas (only if user asks): deep blocks for w1-ai/w1-nlp/w1-tools/w1-apps (low priority, conceptual only).
